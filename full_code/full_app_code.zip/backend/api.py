"""
Backend API for Databricks Data Profiler
Handles Databricks SQL execution and data transformation

Requirements:
    pip install databricks-sql-connector fastapi uvicorn python-dotenv
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from databricks import sql
from typing import List, Dict, Any
import os
from dotenv import load_dotenv
from pydantic import BaseModel

load_dotenv()

app = FastAPI(title="Databricks Data Profiler API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ProfilingQuery(BaseModel):
    fieldKey: str
    query: str
    description: str


class QueryRequest(BaseModel):
    queries: List[ProfilingQuery]


class CatalogTreeRequest(BaseModel):
    catalog: str = None
    schema: str = None


def get_databricks_connection():
    """Create and return a Databricks SQL connection"""
    return sql.connect(
        server_hostname=os.getenv("DATABRICKS_HOST"),
        http_path=os.getenv("DATABRICKS_HTTP_PATH"),
        access_token=os.getenv("DATABRICKS_TOKEN")
    )


@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Databricks Data Profiler API",
        "version": "1.0.0"
    }


@app.get("/api/catalog-tree")
async def get_catalog_tree():
    """
    Fetch the complete catalog structure including catalogs, schemas, and tables
    """
    try:
        conn = get_databricks_connection()
        cursor = conn.cursor()
        
        # Get all catalogs
        cursor.execute("SHOW CATALOGS")
        catalogs_raw = cursor.fetchall()
        catalogs = []
        
        for catalog_row in catalogs_raw:
            catalog_name = catalog_row[0]
            
            # Get schemas in this catalog
            cursor.execute(f"SHOW SCHEMAS IN {catalog_name}")
            schemas_raw = cursor.fetchall()
            schemas = []
            
            for schema_row in schemas_raw:
                schema_name = schema_row[0]
                
                # Skip information_schema
                if schema_name == "information_schema":
                    continue
                
                # Get tables in this schema
                try:
                    cursor.execute(f"SHOW TABLES IN {catalog_name}.{schema_name}")
                    tables_raw = cursor.fetchall()
                    tables = []
                    
                    for table_row in tables_raw:
                        table_name = table_row[1]  # Second column is table name
                        
                        # Get columns for this table
                        try:
                            cursor.execute(f"DESCRIBE TABLE {catalog_name}.{schema_name}.{table_name}")
                            columns_raw = cursor.fetchall()
                            fields = [
                                {
                                    "name": col[0],
                                    "type": col[1]
                                }
                                for col in columns_raw
                                if not col[0].startswith("#")  # Skip partition info
                            ]
                            
                            tables.append({
                                "name": table_name,
                                "fields": fields
                            })
                        except Exception as e:
                            print(f"Error fetching columns for {table_name}: {e}")
                            continue
                    
                    schemas.append({
                        "name": schema_name,
                        "tables": tables
                    })
                except Exception as e:
                    print(f"Error fetching tables for {schema_name}: {e}")
                    continue
            
            catalogs.append({
                "name": catalog_name,
                "schemas": schemas
            })
        
        cursor.close()
        conn.close()
        
        return {"catalogs": catalogs}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching catalog tree: {str(e)}")


@app.post("/api/databricks/execute")
async def execute_queries(request: QueryRequest):
    """
    Execute profiling queries against Databricks
    """
    try:
        conn = get_databricks_connection()
        cursor = conn.cursor()
        
        results = []
        
        for query_obj in request.queries:
            try:
                cursor.execute(query_obj.query)
                
                # Fetch results
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()
                
                # Transform to dictionary format
                query_results = []
                for row in rows:
                    result_dict = dict(zip(columns, row))
                    query_results.append(result_dict)
                
                results.append({
                    "fieldKey": query_obj.fieldKey,
                    "description": query_obj.description,
                    "data": query_results[0] if query_results else None,
                    "success": True
                })
                
            except Exception as e:
                results.append({
                    "fieldKey": query_obj.fieldKey,
                    "description": query_obj.description,
                    "error": str(e),
                    "success": False
                })
        
        cursor.close()
        conn.close()
        
        return {"results": results}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error executing queries: {str(e)}")


@app.get("/api/catalogs")
async def list_catalogs():
    """List all available catalogs"""
    try:
        conn = get_databricks_connection()
        cursor = conn.cursor()
        cursor.execute("SHOW CATALOGS")
        catalogs = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return {"catalogs": catalogs}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/schemas/{catalog}")
async def list_schemas(catalog: str):
    """List schemas in a catalog"""
    try:
        conn = get_databricks_connection()
        cursor = conn.cursor()
        cursor.execute(f"SHOW SCHEMAS IN {catalog}")
        schemas = [row[0] for row in cursor.fetchall() if row[0] != "information_schema"]
        cursor.close()
        conn.close()
        return {"schemas": schemas}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/tables/{catalog}/{schema}")
async def list_tables(catalog: str, schema: str):
    """List tables in a schema"""
    try:
        conn = get_databricks_connection()
        cursor = conn.cursor()
        cursor.execute(f"SHOW TABLES IN {catalog}.{schema}")
        tables = [row[1] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return {"tables": tables}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/columns/{catalog}/{schema}/{table}")
async def list_columns(catalog: str, schema: str, table: str):
    """List columns in a table"""
    try:
        conn = get_databricks_connection()
        cursor = conn.cursor()
        cursor.execute(f"DESCRIBE TABLE {catalog}.{schema}.{table}")
        columns = [
            {"name": row[0], "type": row[1]}
            for row in cursor.fetchall()
            if not row[0].startswith("#")
        ]
        cursor.close()
        conn.close()
        return {"columns": columns}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

