# Backend API for Databricks Data Profiler

This backend service handles communication between the React frontend and Databricks SQL.

## Setup

1. Install Python dependencies:
```bash
cd backend
pip install -r requirements.txt
```

2. Configure environment variables:
```bash
cp ../.env.example ../.env
# Edit .env with your Databricks credentials
```

3. Run the server:
```bash
python api.py
```

The API will be available at `http://localhost:8000`

## API Endpoints

### Health Check
```
GET /
```

### Get Catalog Tree
```
GET /api/catalog-tree
```
Returns complete hierarchy of catalogs, schemas, tables, and columns.

### Execute Profiling Queries
```
POST /api/databricks/execute
Content-Type: application/json

{
  "queries": [
    {
      "fieldKey": "main.schema.table.column",
      "query": "SELECT ...",
      "description": "Profiling query"
    }
  ]
}
```

### List Catalogs
```
GET /api/catalogs
```

### List Schemas
```
GET /api/schemas/{catalog}
```

### List Tables
```
GET /api/tables/{catalog}/{schema}
```

### List Columns
```
GET /api/columns/{catalog}/{schema}/{table}
```

## Development

Run with auto-reload:
```bash
uvicorn api:app --reload --port 8000
```

## Databricks Configuration

Make sure your Databricks workspace has:
1. SQL Warehouse running
2. Access token with appropriate permissions
3. Catalogs/schemas accessible to the token user

## Security Notes

- Never commit `.env` file
- Use service principals in production
- Implement rate limiting
- Add authentication/authorization as needed

