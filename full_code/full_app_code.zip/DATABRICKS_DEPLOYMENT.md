# Deploying Data Profiler to Databricks Apps

This guide shows how to deploy your data profiler as a Databricks App, following the architecture from the [official Databricks blog post](https://www.databricks.com/blog/building-databricks-apps-react-and-mosaic-ai-agents-enterprise-chat-solutions).

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     Databricks Apps                         │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  ui_app (FastAPI)                                    │  │
│  │                                                       │  │
│  │  ┌────────────────┐      ┌───────────────────────┐  │  │
│  │  │  /api/*        │      │  /* (React SPA)       │  │  │
│  │  │  API endpoints │      │  Static files         │  │  │
│  │  │  (api_app)     │      │  from client/build    │  │  │
│  │  └────────────────┘      └───────────────────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Unity Catalog                                       │  │
│  │  • Catalogs, Schemas, Tables                         │  │
│  │  • SQL Warehouse for queries                         │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 📁 Required File Structure

```
data_profiler_app/
├── databricks_app.py          # Main FastAPI app (ui_app + api_app)
├── app.yaml                    # Databricks Apps configuration
├── requirements.txt            # Python dependencies for Databricks
└── client/
    └── build/                  # React production build
        ├── index.html
        ├── static/
        │   ├── js/
        │   │   ├── main.[hash].js
        │   │   └── ...
        │   └── css/
        │       ├── main.[hash].css
        │       └── ...
        └── asset-manifest.json
```

## 🚀 Deployment Steps

### Step 1: Build the React Frontend

```bash
# Install dependencies
npm install

# Build for production
npm run build

# This creates optimized static files in client/build/
```

**Verify the build:**
```bash
ls -la client/build/
# Should see: index.html, static/, asset-manifest.json, etc.
```

### Step 2: Prepare Backend for Databricks

Update your frontend API calls to use the `/api` prefix:

**In your React app (services/profilingService.ts):**
```typescript
// Change from:
const response = await fetch('/api/catalog-tree');

// To (explicit /api prefix):
const response = await fetch('/api/catalog-tree');

// Or use environment variable:
const API_BASE = process.env.REACT_APP_API_BASE || '/api';
const response = await fetch(`${API_BASE}/catalog-tree`);
```

### Step 3: Configure Databricks Resources

Ensure you have:

1. **SQL Warehouse running** - For executing profiling queries
2. **Appropriate permissions** - Access to catalogs, schemas, and tables you want to profile
3. **Unity Catalog enabled** - For metadata access

### Step 4: Deploy to Databricks

#### Option A: Using Databricks CLI

```bash
# Install Databricks CLI if not already installed
pip install databricks-cli

# Authenticate
databricks configure --token

# Create the app
databricks apps create data-profiler

# Deploy the app
databricks apps deploy data-profiler \
  --source-code-path . \
  --requirements databricks_requirements.txt \
  --config app.yaml
```

#### Option B: Using Databricks UI

1. Navigate to **Databricks Workspace**
2. Click **Apps** in the left sidebar
3. Click **Create App**
4. Configure:
   - **Name**: `data-profiler`
   - **Source**: Upload folder or connect to Git
   - **Entry Point**: `databricks_app.py`
   - **Configuration**: `app.yaml`

5. Click **Deploy**

### Step 5: Configure SQL Warehouse

Before deploying, update `app.yaml` with your SQL Warehouse details:

1. **Find your SQL Warehouse ID:**
   - Go to Databricks UI → SQL Warehouses
   - Click on your warehouse
   - Go to "Connection Details" tab
   - Copy the HTTP Path (e.g., `/sql/1.0/warehouses/fc63b669d98bde08`)

2. **Update app.yaml:**
   ```yaml
   env:
     - name: 'DATABRICKS_HTTP_PATH'
       value: '/sql/1.0/warehouses/YOUR_WAREHOUSE_ID'  # ← Replace this
     - name: 'DATABRICKS_SERVER_HOSTNAME'
       value: 'YOUR_WORKSPACE.cloud.databricks.com'   # ← Replace this
   ```

### Step 6: Access Your App

After deployment completes:

```
Your app is available at:
https://<workspace-url>/apps/data-profiler
```

## 🔧 Configuration Details

### app.yaml Breakdown

```yaml
command: [
  "gunicorn",
  "databricks_app:app",
  "-w", "2",
  "-k", "uvicorn.workers.UvicornWorker",
  "--bind", "0.0.0.0:8000",
  "--timeout", "300"
]

env:
  - name: 'DATABRICKS_HTTP_PATH'
    value: '/sql/1.0/warehouses/YOUR_WAREHOUSE_ID'
  - name: 'DATABRICKS_SERVER_HOSTNAME'
    value: 'YOUR_WORKSPACE.cloud.databricks.com'
```

**Important:** Replace `YOUR_WAREHOUSE_ID` and `YOUR_WORKSPACE` with your actual values:
- Find your warehouse ID: Databricks UI → SQL Warehouses → Your Warehouse → Connection Details
- Your workspace hostname is your Databricks URL (without https://)

### Why Two FastAPI Apps?

Following the [Databricks blog pattern](https://www.databricks.com/blog/building-databricks-apps-react-and-mosaic-ai-agents-enterprise-chat-solutions):

1. **`api_app`** (FastAPI):
   - Handles backend logic
   - Defines API endpoints
   - Processes data and queries

2. **`ui_app`** (FastAPI):
   - Mounts `api_app` under `/api` prefix
   - Serves React static files at root `/`
   - Handles SPA routing with `html=True`

```python
# The pattern:
ui_app.mount("/api", api_app)  # All API calls go to /api/*
ui_app.mount("/", StaticFiles(directory="client/build", html=True))  # React SPA
```

## 🔍 Testing After Deployment

### 1. Health Check
```bash
curl https://<workspace-url>/apps/data-profiler/api/health
```

**Expected response:**
```json
{
  "status": "healthy",
  "databricks": "connected",
  "app": "data-profiler",
  "version": "1.0.0"
}
```

### 2. Test Catalog Tree
```bash
curl https://<workspace-url>/apps/data-profiler/api/catalog-tree
```

### 3. Access UI
Open in browser: `https://<workspace-url>/apps/data-profiler`

## 🐛 Troubleshooting

### Issue: "Failed to fetch catalog tree"

**Solution:**
```bash
# Check SQL Warehouse is running
databricks sql warehouses list

# Verify permissions
databricks unity-catalog catalogs list

# Check app logs
databricks apps logs data-profiler
```

### Issue: "404 Not Found" for React routes

**Cause**: Static files not mounted with `html=True`

**Solution**: Verify `databricks_app.py`:
```python
ui_app.mount(
    "/",
    StaticFiles(directory="client/build", html=True),  # ← html=True is crucial
    name="ui"
)
```

### Issue: API calls failing

**Cause**: Frontend not using `/api` prefix

**Solution**: Update all fetch calls:
```typescript
// Before
fetch('/catalog-tree')

// After
fetch('/api/catalog-tree')
```

### Issue: Long queries timeout

**Solution**: Increase timeout in `app.yaml`:
```yaml
command:
  - gunicorn
  - databricks_app:app
  - --timeout 600  # Increase to 10 minutes
```

## 📊 Monitoring

### View Logs
```bash
# Real-time logs
databricks apps logs data-profiler --follow

# Last 100 lines
databricks apps logs data-profiler --tail 100
```

### Check App Status
```bash
databricks apps get data-profiler
```

### Metrics
Monitor in Databricks UI:
- **Request count**
- **Response times**
- **Error rates**
- **SQL Warehouse usage**

## 🔄 Updating the App

### Update Code
```bash
# Make changes to databricks_app.py or rebuild React app

# Redeploy
databricks apps deploy data-profiler \
  --source-code-path . \
  --requirements databricks_requirements.txt \
  --config app.yaml
```

### Update Dependencies
```bash
# Edit databricks_requirements.txt

# Redeploy with new dependencies
databricks apps deploy data-profiler \
  --requirements databricks_requirements.txt
```

## 🔐 Security Considerations

### 1. Authentication
Databricks Apps automatically inherit workspace authentication:
- Users must be logged into Databricks
- Access tokens are managed by platform
- No additional auth needed

### 2. Authorization
Control access via Unity Catalog:
```sql
-- Grant access to specific catalogs
GRANT USE CATALOG main TO `data-profiler-app`;
GRANT SELECT ON CATALOG main TO `data-profiler-app`;

-- Grant access to SQL Warehouse
GRANT CAN_USE ON SQL WAREHOUSE <warehouse-id> TO `data-profiler-app`;
```

### 3. Data Governance
- All queries go through Unity Catalog
- Row-level security is enforced
- Column masking applies automatically
- Audit logs capture all access

## 📈 Performance Optimization

### 1. Worker Processes
Adjust based on usage:
```yaml
command:
  - -w 4  # Increase for high traffic (2 * CPU cores)
```

### 2. Connection Pooling
Implement in `databricks_app.py`:
```python
from sqlalchemy import create_engine
from sqlalchemy.pool import QueuePool

engine = create_engine(
    connection_string,
    poolclass=QueuePool,
    pool_size=5,
    max_overflow=10
)
```

### 3. Caching
Add caching for catalog tree:
```python
from functools import lru_cache
import time

@lru_cache(maxsize=1)
def get_catalog_tree_cached():
    return get_catalog_tree()

# Refresh every hour
last_refresh = time.time()
if time.time() - last_refresh > 3600:
    get_catalog_tree_cached.cache_clear()
```

## 🎯 Best Practices

1. **Always use `/api` prefix** for API endpoints
2. **Build React app before deployment** (`npm run build`)
3. **Use WorkspaceClient** for Databricks SDK operations
4. **Implement health checks** for monitoring
5. **Handle errors gracefully** with user-friendly messages
6. **Log important operations** for debugging
7. **Test locally first** using the development server
8. **Monitor resource usage** and adjust workers accordingly

## 📚 Additional Resources

- [Databricks Apps Documentation](https://docs.databricks.com/en/dev-tools/databricks-apps/)
- [Databricks SDK for Python](https://databricks-sdk-py.readthedocs.io/)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Official Blog Post](https://www.databricks.com/blog/building-databricks-apps-react-and-mosaic-ai-agents-enterprise-chat-solutions)

## 🆘 Support

- **Databricks Support**: Submit a ticket through Databricks UI
- **Community**: [Databricks Community Forum](https://community.databricks.com/)
- **Documentation**: Check `/api/docs` endpoint for API documentation

---

**Your data profiler is now deployed as a native Databricks App!** 🎉

All queries are secured, authenticated, and governed through Unity Catalog.

