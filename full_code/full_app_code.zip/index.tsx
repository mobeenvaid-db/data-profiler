/**
 * Main entry point for the Databricks Data Profiler App
 */
import React from 'react';
import ReactDOM from 'react-dom/client';
import DataProfilerApp from './app';
import './styles.css';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <DataProfilerApp />
  </React.StrictMode>
);

export default DataProfilerApp;

