# 🔄 Application Flow Guide

Visual guide to how the Databricks Data Profiler works.

## 📋 User Journey

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                    🚀 START APPLICATION                     │
│                                                             │
│              Frontend: http://localhost:3000                │
│              Backend:  http://localhost:8000                │
│                                                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│               📊 STEP 1: DATA SELECTION                     │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  DataSelector Component Loads                     │    │
│  │                                                    │    │
│  │  • Backend fetches catalog tree from Databricks   │    │
│  │  • Displays hierarchical browser:                 │    │
│  │    ├── 📁 Catalogs                               │    │
│  │    │   └── 📁 Schemas                            │    │
│  │    │       └── 📁 Tables                         │    │
│  │    │           └── ☑️ Fields                     │    │
│  │                                                    │    │
│  │  User Actions:                                    │    │
│  │  1. Expand catalog (e.g., "main")                │    │
│  │  2. Expand schema (e.g., "healthcare")           │    │
│  │  3. Expand table (e.g., "h_mbr_rel")             │    │
│  │  4. Check individual fields OR "Select All"      │    │
│  │  5. Can select from multiple tables!             │    │
│  │                                                    │    │
│  │  Selected: 14 fields                              │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │   [Profile Selected Fields (14)]  ← Button        │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼ User clicks Profile
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              ⚙️ STEP 2: QUERY GENERATION                    │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  sqlProfiler.ts generates optimized queries       │    │
│  │                                                    │    │
│  │  For each selected field:                         │    │
│  │                                                    │    │
│  │  WITH base_stats AS (                             │    │
│  │    SELECT COUNT(*) as total_rows,                 │    │
│  │           COUNT(field) as non_null,               │    │
│  │           COUNT(DISTINCT field) as unique         │    │
│  │  ),                                                │    │
│  │  value_frequencies AS (                           │    │
│  │    SELECT field, COUNT(*) as freq                 │    │
│  │    ORDER BY freq DESC LIMIT 10                    │    │
│  │  ),                                                │    │
│  │  type_inference AS (...)                          │    │
│  │  SELECT * FROM all_stats;                         │    │
│  │                                                    │    │
│  │  ✅ 14 queries generated                          │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              🔄 STEP 3: PROFILING EXECUTION                 │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  Loading Screen Shows:                            │    │
│  │  ⏳ Profiling Data...                             │    │
│  │  Analyzing 14 fields across 1 table(s)           │    │
│  │  [═══════════════════════════▓▓▓▓▓▓] 60%        │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
│  Backend Process:                                          │
│  1. POST /api/databricks/execute with queries             │
│  2. Backend connects to Databricks SQL Warehouse           │
│  3. Executes each query in sequence/parallel               │
│  4. Collects results                                       │
│  5. Transforms to ProfileResult format                     │
│  6. Returns to frontend                                    │
│                                                             │
│  ⏱️ Typical time: 10-30 seconds                            │
│                                                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼ Results ready
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              📊 STEP 4: RESULTS DASHBOARD                   │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  🎯 EXECUTIVE SUMMARY (8 Cards)                   │    │
│  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐           │    │
│  │  │ 14   │ │30.7M │ │  3   │ │ 98%  │           │    │
│  │  │Cols  │ │Rows  │ │Issues│ │Done  │   ...     │    │
│  │  └──────┘ └──────┘ └──────┘ └──────┘           │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  📈 TYPE DISTRIBUTION CHART                       │    │
│  │  Integer  ████████████░░░░░░░░░░ 57.1%          │    │
│  │  String   ███████░░░░░░░░░░░░░░░ 35.7%          │    │
│  │  Date     ██░░░░░░░░░░░░░░░░░░░░  7.1%          │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  🎨 QUALITY OVERVIEW                              │    │
│  │  ┌────────────┐                                   │    │
│  │  │ Excellent  │  11 columns                       │    │
│  │  │   ✅ 95%+  │  95-100% quality                 │    │
│  │  └────────────┘                                   │    │
│  │  ┌────────────┐                                   │    │
│  │  │   Good     │   2 columns                       │    │
│  │  │   ⚠️ 80%+  │  80-94% quality                  │    │
│  │  └────────────┘                                   │    │
│  │  ┌────────────┐                                   │    │
│  │  │   Needs    │   1 column                        │    │
│  │  │ Attention  │  Below 80% quality                │    │
│  │  │    ❌      │                                    │    │
│  │  └────────────┘                                   │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  🔍 FILTERS & SEARCH                              │    │
│  │  🔎 [Search columns...]                           │    │
│  │  [All] [Issues] [Dates] [Strings] [Numbers]      │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  📋 COLUMNS TABLE                                 │    │
│  │  ┌────────┬──────┬────────┬──────┬─────────┐    │    │
│  │  │ Column │ Type │ Unique │ Null │ Quality │    │    │
│  │  ├────────┼──────┼────────┼──────┼─────────┤    │    │
│  │  │MBR_SK  │Int(9)│  99.97%│  0%  │   100   │    │    │
│  │  │        │      │████████│██████│   ✅    │    │    │
│  │  ├────────┼──────┼────────┼──────┼─────────┤    │    │
│  │  │PAY_IND │Fixed │   0.01%│100%  │    60   │    │    │
│  │  │ ⚠️High │String│        │██████│   ❌    │    │    │
│  │  │ Nulls  │      │        │      │         │    │    │
│  │  └────────┴──────┴────────┴──────┴─────────┘    │    │
│  │                                                    │    │
│  │  Click [👁️ Details] on any row for deep dive     │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼ User clicks Details
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              🔬 STEP 5: COLUMN DETAIL MODAL                 │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  Column: MBR_REL_SK                     [✕ Close] │    │
│  │  ─────────────────────────────────────────────     │    │
│  │  [Overview] [Statistics] [Patterns] [Quality]     │    │
│  │                                                    │    │
│  │  📋 OVERVIEW TAB                                  │    │
│  │  ┌────────────────┬─────────────────┐            │    │
│  │  │ Inferred Type  │ Documented Type │            │    │
│  │  │ Integer(9)     │ number(38)      │            │    │
│  │  │ 100% confident │ Schema type     │            │    │
│  │  └────────────────┴─────────────────┘            │    │
│  │                                                    │    │
│  │  ┌─────────┬─────────┬────────────┐             │    │
│  │  │ Unique  │  Nulls  │ Avg Length │             │    │
│  │  │30.6M    │    0    │     8      │             │    │
│  │  │99.97%   │   0%    │  chars     │             │    │
│  │  └─────────┴─────────┴────────────┘             │    │
│  │                                                    │    │
│  │  📊 Value Range:                                  │    │
│  │  Min: 10000001  ───────────────  Max: 99999999   │    │
│  │                                                    │    │
│  ├───────────────────────────────────────────────────┤    │
│  │  📊 STATISTICS TAB                                │    │
│  │  • Cardinality Analysis                           │    │
│  │  • Completeness Metrics                           │    │
│  │  • Top 3 Values:                                  │    │
│  │    1. Multiple      (99.9%)                       │    │
│  │    2. ...                                          │    │
│  │                                                    │    │
│  ├───────────────────────────────────────────────────┤    │
│  │  🔍 PATTERNS TAB                                  │    │
│  │  Detected Patterns:                               │    │
│  │  • ########  (8-digit numbers)                    │    │
│  │                                                    │    │
│  │  Legend:                                           │    │
│  │  # = digit, A = letter, _ = separator             │    │
│  │                                                    │    │
│  ├───────────────────────────────────────────────────┤    │
│  │  ✅ QUALITY TAB                                   │    │
│  │  Overall Score:        100 / 100                  │    │
│  │                                                    │    │
│  │  Quality Factors:                                 │    │
│  │  Completeness:    100% ████████████              │    │
│  │  Type Match:      Yes  ✅                        │    │
│  │  Consistency:     100% ████████████              │    │
│  │                                                    │    │
│  │  Assessment: Excellent quality with minimal       │    │
│  │  issues. Meets all quality standards.             │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼ User clicks Export
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              📥 STEP 6: EXPORT REPORTS                      │
│                                                             │
│  ┌───────────────────────────────────────────────────┐    │
│  │  Click [📥 Export Report] button                  │    │
│  └───────────────────────────────────────────────────┘    │
│                                                             │
│  Downloads 4 CSV Files:                                    │
│                                                             │
│  1️⃣  Profile_H_MBR_REL_Summary_2024-01-05.csv            │
│      • Total columns, rows, issues                         │
│      • Average completeness, quality                       │
│      • High-level statistics                               │
│                                                             │
│  2️⃣  Profile_H_MBR_REL_Detailed_2024-01-05.csv           │
│      • Column-by-column analysis                           │
│      • All metrics (nulls, unique, types, etc.)            │
│      • Quality scores                                      │
│      • Top values                                          │
│                                                             │
│  3️⃣  Profile_H_MBR_REL_Patterns_2024-01-05.csv           │
│      • Detected patterns per column                        │
│      • Sample values                                       │
│      • Pattern types                                       │
│                                                             │
│  4️⃣  Profile_H_MBR_REL_Quality_2024-01-05.csv            │
│      • Quality scores per column                           │
│      • Issues summary                                      │
│      • Completeness percentages                            │
│      • Type match indicators                               │
│                                                             │
│  📁 All files ready for Excel or data analysis tools!      │
│                                                             │
└─────────────────────────────────────────────────────────────┘

```

## 🔄 State Transitions

```
App States:

┌──────────┐    User Selects Fields      ┌──────────┐
│          │ ──────────────────────────▶ │          │
│Selection │                              │Selection │
│  (idle)  │ ◀────────────────────────── │ (active) │
│          │    Deselects All Fields     │          │
└──────────┘                              └──────────┘
     │                                         │
     │ Clicks "Profile Selected Fields"       │
     ▼                                         ▼
┌──────────┐                              ┌──────────┐
│          │    Profiling Complete        │          │
│Profiling │ ──────────────────────────▶ │ Results  │
│          │                              │          │
└──────────┘                              └──────────┘
     ▲                                         │
     │                                         │
     │          Clicks "Re-Profile"            │
     └─────────────────────────────────────────┘
                                               │
                                               │ Clicks "Back to Selection"
                                               ▼
                                          ┌──────────┐
                                          │          │
                                          │Selection │
                                          │          │
                                          └──────────┘
```

## 📡 API Communication Flow

```
Frontend                          Backend                     Databricks
   │                                │                              │
   │  1. Load Catalog Tree          │                              │
   ├────────GET /api/catalog-tree──▶│                              │
   │                                ├───SHOW CATALOGS─────────────▶│
   │                                ├───SHOW SCHEMAS──────────────▶│
   │                                ├───SHOW TABLES───────────────▶│
   │                                ├───DESCRIBE TABLE────────────▶│
   │                                │◀─────Results─────────────────┤
   │◀──────JSON catalog tree────────┤                              │
   │                                │                              │
   │  2. Profile Data               │                              │
   ├───POST /api/databricks/execute─▶│                              │
   │   {queries: [...]}             │                              │
   │                                ├───Execute Query 1───────────▶│
   │                                │◀─────Results 1───────────────┤
   │                                ├───Execute Query 2───────────▶│
   │                                │◀─────Results 2───────────────┤
   │                                │  ...                          │
   │                                ├───Transform Results          │
   │◀──────Profile Results──────────┤                              │
   │                                │                              │
   │  3. Display Dashboard          │                              │
   │  (All processing client-side)  │                              │
   │                                │                              │
```

## 🎬 Typical Session Timeline

```
0:00  │ User opens http://localhost:3000
0:01  │ DataSelector loads
0:02  │ Catalog tree fetched from backend
0:03  │ User browses catalogs/schemas
0:05  │ User selects 14 fields across tables
0:06  │ User clicks "Profile Selected Fields"
0:06  │ Loading screen appears
0:07  │ Backend generates 14 SQL queries
0:08  │ Queries executing on Databricks
0:18  │ All queries complete (10 seconds)
0:19  │ Results transformed & returned
0:20  │ Dashboard displays with all metrics
0:21  │ User explores executive summary
0:23  │ User filters for "Issues"
0:25  │ User clicks "Details" on problematic column
0:26  │ Modal opens with 4-tab deep dive
0:30  │ User reviews patterns and quality
0:32  │ User clicks "Export Report"
0:33  │ 4 CSV files downloaded
0:35  │ User reviews exports in Excel
```

## 🏃 Performance Characteristics

### Fast Operations (< 1 second)
- UI interactions (filters, search)
- Catalog tree navigation
- Modal opening/closing
- Dashboard rendering

### Medium Operations (1-5 seconds)
- Catalog tree loading (metadata fetch)
- Small table profiling (< 1M rows)
- CSV export generation

### Slow Operations (5-30 seconds)
- Large table profiling (10M+ rows)
- Multi-table profiling (10+ fields)
- Complex pattern detection

### Very Slow Operations (30+ seconds)
- Massive tables (100M+ rows)
- 50+ fields profiling
- Cross-database queries

**💡 Tip**: For very large tables, enable sampling in sqlProfiler.ts!

## 🎯 Key Decision Points

### For Users

```
Decision: How many fields to profile?
├─ 1-10 fields     → Fast (~10-20 sec)
├─ 10-20 fields    → Medium (~20-40 sec)
└─ 20+ fields      → Consider batching

Decision: Single or multi-table?
├─ Single table    → Simpler queries, faster
└─ Multi-table     → Cross-table comparison

Decision: Full scan or sample?
├─ Small tables    → Full scan
└─ Large tables    → Enable sampling
```

### For Developers

```
Decision: Modify SQL queries?
└─ Edit: utils/sqlProfiler.ts

Decision: Change UI components?
└─ Edit: components/ and data_profiling_ui.tsx

Decision: Add new metrics?
├─ Backend: Add to query generation
├─ Transform: Update profilingService.ts
└─ Display: Update dashboard UI

Decision: Deploy to production?
└─ Follow: DEPLOYMENT.md guide
```

## 🎓 Learning Path

### Beginner (Day 1)
1. Read QUICKSTART.md
2. Follow setup steps
3. Profile your first table
4. Export a report

### Intermediate (Week 1)
1. Read full README.md
2. Profile multiple tables
3. Understand quality scoring
4. Explore all modal tabs

### Advanced (Month 1)
1. Read ARCHITECTURE.md
2. Customize SQL queries
3. Add new metrics
4. Deploy to staging

### Expert (Month 3)
1. Read DEPLOYMENT.md
2. Production deployment
3. Performance optimization
4. Custom feature development

---

**Ready to start profiling? Open QUICKSTART.md!** 🚀

