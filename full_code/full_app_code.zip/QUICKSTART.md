# Quick Start Guide

Get the Databricks Data Profiler up and running in 5 minutes!

## 🚀 Quick Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Databricks Connection

Create a `.env` file in the root directory:

```env
DATABRICKS_HOST=your-workspace.cloud.databricks.com
DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/your-warehouse-id
DATABRICKS_TOKEN=dapi1234567890abcdef
VITE_API_BASE_URL=http://localhost:8000
```

**Where to find these values:**
- `DATABRICKS_HOST`: Your workspace URL (without https://)
- `DATABRICKS_HTTP_PATH`: SQL Warehouse → Connection Details → HTTP Path
- `DATABRICKS_TOKEN`: User Settings → Access Tokens → Generate New Token

### 3. Start the Backend API

```bash
cd backend
pip install -r requirements.txt
python api.py
```

Backend will run on `http://localhost:8000`

### 4. Start the Frontend

In a new terminal:

```bash
npm run dev
```

Frontend will run on `http://localhost:3000`

## 🎯 First Profile

1. **Navigate to** `http://localhost:3000`

2. **Select your data:**
   - Expand a catalog (e.g., `main`)
   - Expand a schema (e.g., `healthcare`)
   - Expand a table (e.g., `h_mbr_rel`)
   - Check the fields you want to profile

3. **Click "Profile Selected Fields"**
   - The app will execute profiling queries
   - Results will display in ~10-30 seconds

4. **Explore the results:**
   - View executive summary metrics
   - Browse the column table
   - Click "Details" on any column for deep dive
   - Use filters to find specific column types or issues

5. **Export the report:**
   - Click "Export Report" to download CSV files
   - Four files will be generated:
     - Summary
     - Detailed analysis
     - Pattern detection
     - Quality assessment

## 📊 What Gets Profiled?

For each selected field, the profiler analyzes:

✅ **Completeness**: Null counts and percentages  
✅ **Uniqueness**: Distinct value counts and cardinality  
✅ **Type Inference**: Actual vs documented data types  
✅ **Patterns**: Data format patterns (dates, emails, etc.)  
✅ **Value Distribution**: Top occurring values  
✅ **Min/Max Values**: Value ranges  
✅ **Quality Score**: Overall data quality rating (0-100)

## 🔍 Example Use Cases

### Use Case 1: Validate New Data Source
```
Goal: Ensure a newly loaded table has good data quality
Action: 
1. Select all fields from the table
2. Profile them
3. Look for columns with quality score < 80
4. Review issues and address them
```

### Use Case 2: Find Columns with High Nulls
```
Goal: Identify incomplete data
Action:
1. Profile relevant tables
2. Click "Issues" filter
3. Sort by "Nulls" column
4. Export for stakeholder review
```

### Use Case 3: Cross-Table Profiling
```
Goal: Profile related fields across multiple tables
Action:
1. Select `member_id` from `members` table
2. Select `member_id` from `claims` table
3. Select `member_id` from `enrollments` table
4. Profile all at once
5. Compare uniqueness and cardinality
```

## ⚡ Performance Tips

### For Large Tables (> 10M rows)
Modify the query to include sampling:

```typescript
// In utils/sqlProfiler.ts, add TABLESAMPLE
FROM ${fullTableName} TABLESAMPLE (10 PERCENT)
```

### Batch Processing
- Profile 10-20 fields at a time for optimal performance
- Very large tables may take 1-2 minutes per field

### Optimize Queries
- Use partitioned tables when available
- Profile during off-peak hours
- Consider materialized views for frequently profiled data

## 🐛 Troubleshooting

### Backend won't start
```bash
# Check Python version (need 3.8+)
python --version

# Reinstall dependencies
pip install -r backend/requirements.txt --force-reinstall
```

### Frontend won't connect to backend
```bash
# Verify backend is running
curl http://localhost:8000

# Check .env file has correct VITE_API_BASE_URL
cat .env | grep VITE_API_BASE_URL
```

### Databricks connection error
```bash
# Test connection manually
python -c "
from databricks import sql
import os
from dotenv import load_dotenv
load_dotenv()
conn = sql.connect(
    server_hostname=os.getenv('DATABRICKS_HOST'),
    http_path=os.getenv('DATABRICKS_HTTP_PATH'),
    access_token=os.getenv('DATABRICKS_TOKEN')
)
print('Connection successful!')
conn.close()
"
```

### Queries timing out
- Reduce number of fields being profiled
- Add sampling to queries
- Increase SQL Warehouse size
- Check for long-running queries in Databricks SQL

## 📝 Next Steps

- Read the [full README](README.md) for comprehensive documentation
- Explore [SQL query customization](utils/sqlProfiler.ts)
- Set up scheduled profiling jobs
- Integrate with your data catalog
- Add custom quality rules

## 💡 Pro Tips

1. **Save Your Selections**: The app remembers your field selections during the session

2. **Export Formats**: The multi-sheet export creates separate CSVs that can be opened in Excel

3. **Quality Scoring**: Use the quality score to prioritize data cleanup efforts

4. **Pattern Detection**: Use patterns to identify standardization opportunities

5. **Historical Tracking**: Export and save reports regularly to track quality trends

## 🆘 Need Help?

- Check the [README](README.md) for detailed documentation
- Review the [Backend API docs](backend/README.md)
- Open an issue on GitHub
- Contact your data engineering team

---

Happy Profiling! 🎉

