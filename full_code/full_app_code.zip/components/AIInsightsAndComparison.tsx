/**
 * AI Insights and Profile Comparison Components
 */

import React, { useState, useEffect } from 'react';
import { Sparkles, Loader2, ArrowLeftRight, Save, TrendingUp, TrendingDown, Minus, Trash2 } from 'lucide-react';

// ============================================================================
// AI Insights Component
// ============================================================================

interface AIInsightsProps {
  columnData: any;
}

export const AIInsights: React.FC<AIInsightsProps> = ({ columnData }) => {
  const [insights, setInsights] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [isFallback, setIsFallback] = useState<boolean>(false);

  useEffect(() => {
    generateInsights();
  }, [columnData]);

  const generateInsights = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch('/api/ai/generate-insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ columnData })
      });

      if (response.ok) {
        const data = await response.json();
        setInsights(data.insights);
        setIsFallback(data.fallback || false);
      } else {
        setError('Failed to generate insights');
      }
    } catch (err) {
      setError('Error connecting to AI service');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-purple-50 to-indigo-50 p-12 rounded-xl border-2 border-purple-200 text-center">
        <Loader2 className="w-12 h-12 mx-auto text-purple-600 animate-spin mb-4" />
        <p className="text-purple-900 font-semibold">🤖 Analyzing column with AI...</p>
        <p className="text-sm text-purple-600 mt-2">Generating actionable insights</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 p-6 rounded-xl border-2 border-red-200">
        <p className="text-red-800 font-semibold">⚠️ {error}</p>
        <button 
          onClick={generateInsights}
          className="mt-3 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-purple-50 to-indigo-50 p-6 rounded-xl border-2 border-purple-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-600" />
          AI-Powered Insights
        </h3>
        {isFallback && (
          <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded">
            Rule-based Analysis
          </span>
        )}
      </div>

      <div className="bg-white p-6 rounded-lg border border-purple-200">
        <div className="prose prose-sm max-w-none">
          {insights.split('\n').map((line, idx) => {
            if (line.trim() === '') return null;
            
            // Check if line starts with a number (numbered list)
            const isNumbered = /^\d+\./.test(line.trim());
            
            return (
              <div key={idx} className="mb-3 last:mb-0">
                {isNumbered ? (
                  <div className="flex gap-3 items-start p-3 bg-purple-50 rounded-lg border border-purple-100">
                    <span className="text-purple-900 whitespace-pre-wrap leading-relaxed">{line.trim()}</span>
                  </div>
                ) : (
                  <p className="text-slate-700 whitespace-pre-wrap leading-relaxed">{line}</p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <button 
        onClick={generateInsights}
        className="mt-4 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2"
      >
        <Sparkles className="w-4 h-4" />
        Regenerate Insights
      </button>
    </div>
  );
};

// ============================================================================
// Snapshot Manager Component
// ============================================================================

interface SnapshotManagerProps {
  profileData: any;
  onCompare: (snapshot1: string, snapshot2: string) => void;
  comparing?: boolean;
}

export const SnapshotManager: React.FC<SnapshotManagerProps> = ({ profileData, onCompare, comparing = false }) => {
  const [snapshots, setSnapshots] = useState<any[]>([]);
  const [snapshotName, setSnapshotName] = useState<string>('');
  const [saving, setSaving] = useState<boolean>(false);
  const [selectedSnapshot1, setSelectedSnapshot1] = useState<string>('');
  const [selectedSnapshot2, setSelectedSnapshot2] = useState<string>('');

  useEffect(() => {
    loadSnapshots();
  }, []);

  const loadSnapshots = async () => {
    try {
      console.log('📋 Loading snapshots from API...');
      const response = await fetch('/api/snapshots/list');
      if (response.ok) {
        const data = await response.json();
        console.log('✅ Received snapshots from API:', data.snapshots);
        console.log(`   Count: ${data.snapshots?.length || 0}`);
        setSnapshots(data.snapshots || []);
      } else {
        console.error('❌ Failed to load snapshots:', response.status, response.statusText);
      }
    } catch (err) {
      console.error('❌ Error loading snapshots:', err);
    }
  };

  const saveSnapshot = async () => {
    if (!snapshotName.trim()) {
      alert('Please enter a snapshot name');
      return;
    }

    setSaving(true);
    try {
      const timestamp = new Date().toISOString();
      console.log('💾 Saving snapshot:', snapshotName);
      console.log('   Timestamp:', timestamp);
      console.log('   Data columns:', profileData?.columns?.length || 0);
      
      const response = await fetch('/api/snapshots/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: snapshotName,
          profileData: profileData,
          timestamp: timestamp
        })
      });

      if (response.ok) {
        const result = await response.json();
        console.log('✅ Snapshot saved successfully:', result);
        setSnapshotName('');
        await loadSnapshots(); // Wait for reload to complete
        alert('Snapshot saved successfully!');
      } else {
        console.error('❌ Failed to save snapshot:', response.status, response.statusText);
        alert('Error saving snapshot');
      }
    } catch (err) {
      console.error('❌ Error saving snapshot:', err);
      alert('Error saving snapshot');
    } finally {
      setSaving(false);
    }
  };

  const deleteSnapshot = async (snapshotId: string, snapshotName: string) => {
    if (!confirm(`Are you sure you want to delete snapshot "${snapshotName}"?`)) {
      return;
    }

    try {
      const response = await fetch(`/api/snapshots/${snapshotId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        // Clear selected snapshots if they were deleted
        if (selectedSnapshot1 === snapshotId) setSelectedSnapshot1('');
        if (selectedSnapshot2 === snapshotId) setSelectedSnapshot2('');
        
        loadSnapshots();
        alert('Snapshot deleted successfully!');
      } else {
        alert('Error deleting snapshot');
      }
    } catch (err) {
      console.error('Error deleting snapshot:', err);
      alert('Error deleting snapshot');
    }
  };

  const handleCompare = () => {
    if (!selectedSnapshot1 || !selectedSnapshot2) {
      alert('Please select two snapshots to compare');
      return;
    }
    onCompare(selectedSnapshot1, selectedSnapshot2);
  };

  return (
    <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl border-2 border-green-200">
      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
        <Save className="w-5 h-5 text-green-600" />
        Profile Snapshots
      </h3>

      {/* Save New Snapshot */}
      <div className="bg-white p-4 rounded-lg border border-green-200 mb-6">
        <p className="text-sm font-semibold text-slate-700 mb-3">Save Current Profile</p>
        <div className="flex gap-2">
          <input
            type="text"
            value={snapshotName}
            onChange={(e) => setSnapshotName(e.target.value)}
            placeholder="Enter snapshot name..."
            className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <button
            onClick={saveSnapshot}
            disabled={saving}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save
          </button>
        </div>
      </div>

      {/* Snapshot List */}
      {snapshots.length > 0 && (
        <>
          <div className="bg-white p-4 rounded-lg border border-green-200 mb-6">
            <p className="text-sm font-semibold text-slate-700 mb-3">Saved Snapshots ({snapshots.length})</p>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {snapshots.map((snap) => (
                <div key={snap.id} className="p-3 bg-green-50 rounded-lg border border-green-100 flex items-center justify-between hover:bg-green-100 transition-colors">
                  <div className="flex-1">
                    <div className="font-semibold text-slate-900">{snap.name}</div>
                    <div className="text-xs text-slate-600">
                      {new Date(snap.timestamp).toLocaleString()} • {snap.columnCount} columns
                    </div>
                  </div>
                  <button
                    onClick={() => deleteSnapshot(snap.id, snap.name)}
                    className="ml-3 p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                    title="Delete snapshot"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Comparison Tool */}
          <div className="bg-white p-4 rounded-lg border border-green-200">
            <p className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
              <ArrowLeftRight className="w-4 h-4" />
              Compare Snapshots
            </p>
            <div className="space-y-3">
              <select
                value={selectedSnapshot1}
                onChange={(e) => setSelectedSnapshot1(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="">Select first snapshot...</option>
                {snapshots.map((snap) => (
                  <option key={snap.id} value={snap.id}>{snap.name} ({new Date(snap.timestamp).toLocaleDateString()})</option>
                ))}
              </select>
              <select
                value={selectedSnapshot2}
                onChange={(e) => setSelectedSnapshot2(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="">Select second snapshot...</option>
                {snapshots.map((snap) => (
                  <option key={snap.id} value={snap.id}>{snap.name} ({new Date(snap.timestamp).toLocaleDateString()})</option>
                ))}
              </select>
              <button
                onClick={handleCompare}
                disabled={comparing}
                className={`w-full px-4 py-2 rounded-lg transition-colors flex items-center justify-center gap-2 ${
                  comparing 
                    ? 'bg-gray-400 cursor-not-allowed' 
                    : 'bg-green-600 text-white hover:bg-green-700'
                }`}
              >
                {comparing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Comparing...
                  </>
                ) : (
                  <>
                    <ArrowLeftRight className="w-4 h-4" />
                    Compare
                  </>
                )}
              </button>
            </div>
          </div>
        </>
      )}

      {snapshots.length === 0 && (
        <div className="bg-white p-8 rounded-lg border border-green-200 text-center text-slate-600">
          <Save className="w-12 h-12 mx-auto text-slate-400 mb-3" />
          <p>No snapshots saved yet.</p>
          <p className="text-sm mt-1">Save your first profile snapshot above.</p>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// Profile Comparison Display Component
// ============================================================================

interface ProfileComparisonProps {
  comparison: {
    snapshot1: { name: string; timestamp: string };
    snapshot2: { name: string; timestamp: string };
    columns: Array<{
      columnName: string;
      status: 'changed' | 'added' | 'removed';
      changes?: any;
    }>;
  };
  onClose: () => void;
}

export const ProfileComparison: React.FC<ProfileComparisonProps> = ({ comparison, onClose }) => {
  const changedColumns = comparison.columns.filter(c => c.status === 'changed');
  const addedColumns = comparison.columns.filter(c => c.status === 'added');
  const removedColumns = comparison.columns.filter(c => c.status === 'removed');

  const getDeltaIcon = (delta: number) => {
    if (delta > 0) return <TrendingUp className="w-4 h-4 text-red-600" />;
    if (delta < 0) return <TrendingDown className="w-4 h-4 text-green-600" />;
    return <Minus className="w-4 h-4 text-slate-400" />;
  };

  const getDeltaColor = (delta: number, metricName: string) => {
    // For nulls, increasing is bad
    if (metricName === 'nulls') {
      if (delta > 5) return 'text-red-600 font-bold';
      if (delta < -5) return 'text-green-600 font-bold';
    }
    // For quality, increasing is good
    if (metricName === 'quality') {
      if (delta > 5) return 'text-green-600 font-bold';
      if (delta < -5) return 'text-red-600 font-bold';
    }
    return 'text-slate-600';
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-2">Profile Comparison</h2>
              <div className="flex items-center gap-4 text-sm">
                <span className="bg-white bg-opacity-20 px-3 py-1 rounded">
                  📊 {comparison.snapshot1.name} ({new Date(comparison.snapshot1.timestamp).toLocaleDateString()})
                </span>
                <ArrowLeftRight className="w-4 h-4" />
                <span className="bg-white bg-opacity-20 px-3 py-1 rounded">
                  📊 {comparison.snapshot2.name} ({new Date(comparison.snapshot2.timestamp).toLocaleDateString()})
                </span>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white hover:bg-opacity-20 rounded-full p-2 transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Summary */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 text-center">
              <div className="text-3xl font-bold text-blue-900">{changedColumns.length}</div>
              <div className="text-sm text-blue-600">Changed</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg border border-green-200 text-center">
              <div className="text-3xl font-bold text-green-900">{addedColumns.length}</div>
              <div className="text-sm text-green-600">Added</div>
            </div>
            <div className="bg-red-50 p-4 rounded-lg border border-red-200 text-center">
              <div className="text-3xl font-bold text-red-900">{removedColumns.length}</div>
              <div className="text-sm text-red-600">Removed</div>
            </div>
          </div>

          {/* Changed Columns */}
          {changedColumns.length > 0 && (
            <div>
              <h3 className="text-lg font-bold text-slate-900 mb-3">Changed Columns</h3>
              <div className="space-y-3">
                {changedColumns.map((col, idx) => (
                  <div key={idx} className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                    <div className="font-semibold text-slate-900 mb-3">{col.columnName}</div>
                    <div className="grid grid-cols-3 gap-4">
                      {col.changes?.nulls && (
                        <div className="text-center p-3 bg-white rounded border border-slate-200">
                          <div className="text-xs text-slate-600 mb-1">Null %</div>
                          <div className="flex items-center justify-center gap-2">
                            {getDeltaIcon(col.changes.nulls.delta)}
                            <span className={getDeltaColor(col.changes.nulls.delta, 'nulls')}>
                              {col.changes.nulls.before.toFixed(2)}% → {col.changes.nulls.after.toFixed(2)}%
                            </span>
                          </div>
                        </div>
                      )}
                      {col.changes?.uniqueness && (
                        <div className="text-center p-3 bg-white rounded border border-slate-200">
                          <div className="text-xs text-slate-600 mb-1">Uniqueness %</div>
                          <div className="flex items-center justify-center gap-2">
                            {getDeltaIcon(col.changes.uniqueness.delta)}
                            <span className="text-slate-600">
                              {col.changes.uniqueness.before.toFixed(2)}% → {col.changes.uniqueness.after.toFixed(2)}%
                            </span>
                          </div>
                        </div>
                      )}
                      {col.changes?.quality && (
                        <div className="text-center p-3 bg-white rounded border border-slate-200">
                          <div className="text-xs text-slate-600 mb-1">Quality Score</div>
                          <div className="flex items-center justify-center gap-2">
                            {getDeltaIcon(col.changes.quality.delta)}
                            <span className={getDeltaColor(col.changes.quality.delta, 'quality')}>
                              {col.changes.quality.before} → {col.changes.quality.after}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Added Columns */}
          {addedColumns.length > 0 && (
            <div>
              <h3 className="text-lg font-bold text-slate-900 mb-3">Added Columns</h3>
              <div className="flex flex-wrap gap-2">
                {addedColumns.map((col, idx) => (
                  <span key={idx} className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                    + {col.columnName}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Removed Columns */}
          {removedColumns.length > 0 && (
            <div>
              <h3 className="text-lg font-bold text-slate-900 mb-3">Removed Columns</h3>
              <div className="flex flex-wrap gap-2">
                {removedColumns.map((col, idx) => (
                  <span key={idx} className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-semibold">
                    - {col.columnName}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default {
  AIInsights,
  SnapshotManager,
  ProfileComparison
};

