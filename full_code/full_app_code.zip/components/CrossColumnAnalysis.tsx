/**
 * Cross-Column Analysis Components
 * Includes: Correlation Matrix, Composite Keys, Conditional Profiling
 */

import React from 'react';
import { Network, Key, BarChart3, TrendingUp, CheckCircle } from 'lucide-react';

// ============================================================================
// Correlation Heatmap Component
// ============================================================================

interface CorrelationHeatmapProps {
  correlations: Array<{
    field1: string;
    field2: string;
    correlation: number;
    strength: string;
  }>;
}

export const CorrelationHeatmap: React.FC<CorrelationHeatmapProps> = ({ correlations }) => {
  if (!correlations || correlations.length === 0) {
    return (
      <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 text-center">
        <Network className="w-12 h-12 mx-auto text-slate-400 mb-3" />
        <p className="text-slate-600">No correlations available. Need at least 2 numeric columns.</p>
      </div>
    );
  }

  const getCorrelationColor = (corr: number) => {
    const absCorr = Math.abs(corr);
    if (absCorr >= 0.8) return corr > 0 ? 'bg-green-600' : 'bg-red-600';
    if (absCorr >= 0.6) return corr > 0 ? 'bg-green-500' : 'bg-red-500';
    if (absCorr >= 0.4) return corr > 0 ? 'bg-green-400' : 'bg-red-400';
    if (absCorr >= 0.2) return corr > 0 ? 'bg-green-300' : 'bg-red-300';
    return 'bg-slate-300';
  };

  const getCorrelationTextColor = (corr: number) => {
    const absCorr = Math.abs(corr);
    return absCorr >= 0.4 ? 'text-white' : 'text-slate-900';
  };

  // Find strong correlations (>= 0.6)
  const strongCorrelations = correlations.filter(c => Math.abs(c.correlation) >= 0.6);

  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl border-2 border-blue-200">
      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
        <Network className="w-5 h-5 text-blue-600" />
        Correlation Matrix
      </h3>

      {/* Strong Correlations Summary */}
      {strongCorrelations.length > 0 && (
        <div className="bg-blue-100 border border-blue-300 p-4 rounded-lg mb-6">
          <p className="text-sm font-semibold text-blue-900 mb-2">
            🔗 {strongCorrelations.length} Strong Correlation{strongCorrelations.length !== 1 ? 's' : ''} Detected
          </p>
          <div className="space-y-1">
            {strongCorrelations.map((corr, idx) => (
              <div key={idx} className="text-xs text-blue-800">
                <span className="font-semibold">{corr.field1}</span> ↔ <span className="font-semibold">{corr.field2}</span>: {corr.correlation.toFixed(3)} ({corr.strength})
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Correlation Grid */}
      <div className="bg-white p-6 rounded-lg border border-blue-200 overflow-x-auto">
        <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${correlations.length}, minmax(150px, 1fr))` }}>
          {correlations.map((corr, idx) => (
            <div key={idx} className="text-center">
              <div className={`p-4 rounded-lg ${getCorrelationColor(corr.correlation)} transition-all hover:scale-105`}>
                <div className={`text-xs font-semibold mb-1 ${getCorrelationTextColor(corr.correlation)}`}>
                  {corr.field1} × {corr.field2}
                </div>
                <div className={`text-2xl font-bold ${getCorrelationTextColor(corr.correlation)}`}>
                  {corr.correlation.toFixed(3)}
                </div>
                <div className={`text-xs ${getCorrelationTextColor(corr.correlation)}`}>
                  {corr.strength}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="mt-6 flex items-center justify-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-600 rounded"></div>
            <span>Positive</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-600 rounded"></div>
            <span>Negative</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-slate-300 rounded"></div>
            <span>Weak</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// Composite Key Detection Component
// ============================================================================

interface CompositeKeyProps {
  compositeKeys: Array<{
    columns: string[];
    uniqueCount: number;
    totalRows: number;
    uniquenessPct: number;
    isPotentialKey: boolean;
  }>;
}

export const CompositeKeyDetection: React.FC<CompositeKeyProps> = ({ compositeKeys }) => {
  if (!compositeKeys || compositeKeys.length === 0) {
    return (
      <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 text-center">
        <Key className="w-12 h-12 mx-auto text-slate-400 mb-3" />
        <p className="text-slate-600">No composite key candidates found.</p>
      </div>
    );
  }

  const potentialKeys = compositeKeys.filter(ck => ck.isPotentialKey);

  return (
    <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl border-2 border-purple-200">
      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
        <Key className="w-5 h-5 text-purple-600" />
        Composite Key Candidates
      </h3>

      {/* Summary */}
      {potentialKeys.length > 0 && (
        <div className="bg-purple-100 border border-purple-300 p-4 rounded-lg mb-6">
          <p className="text-sm font-semibold text-purple-900 mb-2">
            🔑 {potentialKeys.length} Potential Composite Key{potentialKeys.length !== 1 ? 's' : ''} Found
          </p>
          <p className="text-xs text-purple-700">
            These column combinations have ≥99.9% uniqueness and could serve as primary keys.
          </p>
        </div>
      )}

      {/* Composite Key List */}
      <div className="bg-white p-6 rounded-lg border border-purple-200 space-y-3">
        {compositeKeys.map((ck, idx) => (
          <div 
            key={idx} 
            className={`p-4 rounded-lg border-2 ${ck.isPotentialKey ? 'border-green-500 bg-green-50' : 'border-purple-200 bg-purple-50'}`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {ck.isPotentialKey && <CheckCircle className="w-4 h-4 text-green-600" />}
                <span className="font-semibold text-slate-900">
                  {ck.columns.join(' + ')}
                </span>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${ck.isPotentialKey ? 'bg-green-600 text-white' : 'bg-purple-200 text-purple-900'}`}>
                {ck.uniquenessPct.toFixed(2)}% unique
              </span>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-600">
              <span>{ck.uniqueCount.toLocaleString()} unique combinations</span>
              <span>•</span>
              <span>{ck.totalRows.toLocaleString()} total rows</span>
            </div>
            {ck.isPotentialKey && (
              <div className="mt-2 text-xs text-green-700 font-semibold">
                ✓ Recommended for use as composite primary key
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// Conditional Profiling Component
// ============================================================================

interface ConditionalProfilingProps {
  stats: Array<{
    category: string;
    count: number;
    mean: number;
    stddev: number;
    min: number;
    max: number;
    median: number;
  }>;
  numericField: string;
  categoricalField: string;
}

export const ConditionalProfiling: React.FC<ConditionalProfilingProps> = ({ stats, numericField, categoricalField }) => {
  if (!stats || stats.length === 0) {
    return (
      <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 text-center">
        <BarChart3 className="w-12 h-12 mx-auto text-slate-400 mb-3" />
        <p className="text-slate-600">No conditional profiling data available.</p>
      </div>
    );
  }

  const maxMean = Math.max(...stats.map(s => s.mean));
  const minMean = Math.min(...stats.map(s => s.mean));
  const avgMean = stats.reduce((sum, s) => sum + s.mean, 0) / stats.length;

  return (
    <div className="bg-gradient-to-br from-orange-50 to-amber-50 p-6 rounded-xl border-2 border-orange-200">
      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
        <TrendingUp className="w-5 h-5 text-orange-600" />
        Conditional Profiling: {numericField} by {categoricalField}
      </h3>

      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg border border-orange-200 text-center">
          <div className="text-xs text-orange-600 mb-1">Highest Mean</div>
          <div className="text-2xl font-bold text-orange-900">{maxMean.toFixed(2)}</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-orange-200 text-center">
          <div className="text-xs text-orange-600 mb-1">Average Mean</div>
          <div className="text-2xl font-bold text-orange-900">{avgMean.toFixed(2)}</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-orange-200 text-center">
          <div className="text-xs text-orange-600 mb-1">Lowest Mean</div>
          <div className="text-2xl font-bold text-orange-900">{minMean.toFixed(2)}</div>
        </div>
      </div>

      {/* Category Stats */}
      <div className="bg-white p-6 rounded-lg border border-orange-200 space-y-4">
        {stats.map((stat, idx) => (
          <div key={idx} className="border-b border-slate-200 pb-4 last:border-0">
            <div className="flex items-center justify-between mb-3">
              <span className="font-semibold text-slate-900 text-lg">{stat.category}</span>
              <span className="text-sm text-slate-600">{stat.count.toLocaleString()} records</span>
            </div>
            <div className="grid grid-cols-5 gap-3">
              <div className="text-center">
                <div className="text-xs text-slate-600 mb-1">Mean</div>
                <div className="text-sm font-bold text-blue-700">{stat.mean.toFixed(2)}</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-slate-600 mb-1">Median</div>
                <div className="text-sm font-bold text-green-700">{stat.median.toFixed(2)}</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-slate-600 mb-1">Std Dev</div>
                <div className="text-sm font-bold text-purple-700">{stat.stddev.toFixed(2)}</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-slate-600 mb-1">Min</div>
                <div className="text-sm font-bold text-slate-700">{stat.min.toFixed(2)}</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-slate-600 mb-1">Max</div>
                <div className="text-sm font-bold text-slate-700">{stat.max.toFixed(2)}</div>
              </div>
            </div>
            {/* Visual bar for mean comparison */}
            <div className="mt-2">
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-orange-500 to-orange-600 h-2 rounded-full"
                  style={{ width: `${((stat.mean - minMean) / (maxMean - minMean)) * 100}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default {
  CorrelationHeatmap,
  CompositeKeyDetection,
  ConditionalProfiling
};

