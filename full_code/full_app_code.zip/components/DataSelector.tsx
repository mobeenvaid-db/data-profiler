import React, { useState, useEffect } from 'react';
import { Database, Table, Columns, ChevronDown, ChevronRight, Check, Loader2, AlertCircle } from 'lucide-react';

interface DataSelectorProps {
  onSelectionChange: (selection: SelectedFields[]) => void;
  onProfile: () => void;
  isLoading?: boolean;
}

export interface SelectedFields {
  catalog: string;
  schema: string;
  table: string;
  fields: Array<{name: string; type: string}>;
}

interface Catalog {
  name: string;
  schemas?: Schema[];
}

interface Schema {
  name: string;
  tables?: TableItem[];
}

interface TableItem {
  name: string;
  columns?: Column[];
}

interface Column {
  name: string;
  type: string;
}

const DataSelector: React.FC<DataSelectorProps> = ({ onSelectionChange, onProfile, isLoading }) => {
  const [catalogs, setCatalogs] = useState<Catalog[]>([]);
  const [expandedCatalogs, setExpandedCatalogs] = useState<Set<string>>(new Set());
  const [expandedSchemas, setExpandedSchemas] = useState<Set<string>>(new Set());
  const [expandedTables, setExpandedTables] = useState<Set<string>>(new Set());
  const [selectedFields, setSelectedFields] = useState<Map<string, Set<string>>>(new Map());
  const [loadingState, setLoadingState] = useState<'idle' | 'loading' | 'error' | 'success'>('idle');
  const [loadingItems, setLoadingItems] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadCatalogs();
  }, []);

  useEffect(() => {
    // Convert selectedFields map to array format for parent with field types
    const selection: SelectedFields[] = [];
    selectedFields.forEach((fieldNames, tableKey) => {
      const [catalogName, schemaName, tableName] = tableKey.split('.');
      if (fieldNames.size > 0) {
        // Look up field types from catalogs state
        const catalog = catalogs.find(c => c.name === catalogName);
        const schema = catalog?.schemas?.find(s => s.name === schemaName);
        const table = schema?.tables?.find(t => t.name === tableName);
        
        const fieldsWithTypes = Array.from(fieldNames).map(fieldName => {
          const column = table?.columns?.find(c => c.name === fieldName);
          return {
            name: fieldName,
            type: column?.type || 'string' // default to string if type not found
          };
        });
        
        selection.push({
          catalog: catalogName,
          schema: schemaName,
          table: tableName,
          fields: fieldsWithTypes
        });
      }
    });
    onSelectionChange(selection);
  }, [selectedFields, catalogs, onSelectionChange]);

  const loadCatalogs = async () => {
    setLoadingState('loading');
    try {
      const response = await fetch('/api/catalogs');
      if (!response.ok) throw new Error('Failed to load catalogs');
      
      const data = await response.json();
      setCatalogs(data.catalogs);
      setLoadingState('success');
    } catch (error) {
      console.error('Error loading catalogs:', error);
      setLoadingState('error');
    }
  };

  const loadSchemas = async (catalogName: string) => {
    const loadKey = `catalog-${catalogName}`;
    setLoadingItems(prev => new Set(prev).add(loadKey));
    
    try {
      const response = await fetch(`/api/schemas?catalog=${encodeURIComponent(catalogName)}`);
      if (!response.ok) throw new Error('Failed to load schemas');
      
      const data = await response.json();
      
      // Update the catalog with schemas
      setCatalogs(prev => prev.map(cat => 
        cat.name === catalogName 
          ? { ...cat, schemas: data.schemas }
          : cat
      ));
    } catch (error) {
      console.error(`Error loading schemas for ${catalogName}:`, error);
    } finally {
      setLoadingItems(prev => {
        const next = new Set(prev);
        next.delete(loadKey);
        return next;
      });
    }
  };

  const loadTables = async (catalogName: string, schemaName: string) => {
    const loadKey = `schema-${catalogName}.${schemaName}`;
    setLoadingItems(prev => new Set(prev).add(loadKey));
    
    try {
      const response = await fetch(`/api/tables?catalog=${encodeURIComponent(catalogName)}&schema=${encodeURIComponent(schemaName)}`);
      if (!response.ok) throw new Error('Failed to load tables');
      
      const data = await response.json();
      
      // Update the schema with tables
      setCatalogs(prev => prev.map(cat => 
        cat.name === catalogName && cat.schemas
          ? {
              ...cat,
              schemas: cat.schemas.map(sch =>
                sch.name === schemaName
                  ? { ...sch, tables: data.tables }
                  : sch
              )
            }
          : cat
      ));
    } catch (error) {
      console.error(`Error loading tables for ${catalogName}.${schemaName}:`, error);
    } finally {
      setLoadingItems(prev => {
        const next = new Set(prev);
        next.delete(loadKey);
        return next;
      });
    }
  };

  const loadColumns = async (catalogName: string, schemaName: string, tableName: string) => {
    const loadKey = `table-${catalogName}.${schemaName}.${tableName}`;
    setLoadingItems(prev => new Set(prev).add(loadKey));
    
    try {
      const response = await fetch(`/api/columns?catalog=${encodeURIComponent(catalogName)}&schema=${encodeURIComponent(schemaName)}&table=${encodeURIComponent(tableName)}`);
      if (!response.ok) throw new Error('Failed to load columns');
      
      const data = await response.json();
      
      // Update the table with columns
      setCatalogs(prev => prev.map(cat => 
        cat.name === catalogName && cat.schemas
          ? {
              ...cat,
              schemas: cat.schemas.map(sch =>
                sch.name === schemaName && sch.tables
                  ? {
                      ...sch,
                      tables: sch.tables.map(tbl =>
                        tbl.name === tableName
                          ? { ...tbl, columns: data.columns }
                          : tbl
                      )
                    }
                  : sch
              )
            }
          : cat
      ));
    } catch (error) {
      console.error(`Error loading columns for ${catalogName}.${schemaName}.${tableName}:`, error);
    } finally {
      setLoadingItems(prev => {
        const next = new Set(prev);
        next.delete(loadKey);
        return next;
      });
    }
  };

  const toggleCatalog = (catalogName: string) => {
    const newExpanded = new Set(expandedCatalogs);
    if (newExpanded.has(catalogName)) {
      newExpanded.delete(catalogName);
    } else {
      newExpanded.add(catalogName);
      // Load schemas if not already loaded
      const catalog = catalogs.find(c => c.name === catalogName);
      if (!catalog?.schemas) {
        loadSchemas(catalogName);
      }
    }
    setExpandedCatalogs(newExpanded);
  };

  const toggleSchema = (catalogName: string, schemaName: string) => {
    const key = `${catalogName}.${schemaName}`;
    const newExpanded = new Set(expandedSchemas);
    if (newExpanded.has(key)) {
      newExpanded.delete(key);
    } else {
      newExpanded.add(key);
      // Load tables if not already loaded
      const catalog = catalogs.find(c => c.name === catalogName);
      const schema = catalog?.schemas?.find(s => s.name === schemaName);
      if (!schema?.tables) {
        loadTables(catalogName, schemaName);
      }
    }
    setExpandedSchemas(newExpanded);
  };

  const toggleTable = (catalogName: string, schemaName: string, tableName: string) => {
    const key = `${catalogName}.${schemaName}.${tableName}`;
    const newExpanded = new Set(expandedTables);
    if (newExpanded.has(key)) {
      newExpanded.delete(key);
    } else {
      newExpanded.add(key);
      // Load columns if not already loaded
      const catalog = catalogs.find(c => c.name === catalogName);
      const schema = catalog?.schemas?.find(s => s.name === schemaName);
      const table = schema?.tables?.find(t => t.name === tableName);
      if (!table?.columns) {
        loadColumns(catalogName, schemaName, tableName);
      }
    }
    setExpandedTables(newExpanded);
  };

  const toggleFieldSelection = (catalog: string, schema: string, table: string, field: string) => {
    const tableKey = `${catalog}.${schema}.${table}`;
    const newSelected = new Map(selectedFields);
    const tableFields = newSelected.get(tableKey) || new Set<string>();
    
    if (tableFields.has(field)) {
      tableFields.delete(field);
    } else {
      tableFields.add(field);
    }
    
    if (tableFields.size === 0) {
      newSelected.delete(tableKey);
    } else {
      newSelected.set(tableKey, tableFields);
    }
    
    setSelectedFields(newSelected);
  };

  const toggleAllFieldsInTable = (catalog: string, schema: string, table: string, allFields: string[]) => {
    const tableKey = `${catalog}.${schema}.${table}`;
    const newSelected = new Map(selectedFields);
    const currentFields = newSelected.get(tableKey) || new Set<string>();
    
    if (currentFields.size === allFields.length) {
      // Deselect all
      newSelected.delete(tableKey);
    } else {
      // Select all
      newSelected.set(tableKey, new Set(allFields));
    }
    
    setSelectedFields(newSelected);
  };

  const getSelectedCount = () => {
    let count = 0;
    selectedFields.forEach(fields => count += fields.size);
    return count;
  };

  if (loadingState === 'loading' && catalogs.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-8 mb-6">
        <div className="flex items-center justify-center">
          <Loader2 className="animate-spin mr-3" size={24} />
          <span className="text-gray-600">Loading catalog structure...</span>
        </div>
      </div>
    );
  }

  if (loadingState === 'error') {
    return (
      <div className="bg-white rounded-lg shadow-lg p-8 mb-6">
        <div className="flex items-center justify-center text-red-600">
          <AlertCircle className="mr-3" size={24} />
          <span>Error loading catalogs. Please check your connection and permissions.</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Select Data to Profile</h2>
        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-600">
            {getSelectedCount()} field{getSelectedCount() !== 1 ? 's' : ''} selected
          </span>
          <button
            onClick={onProfile}
            disabled={getSelectedCount() === 0 || isLoading}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              getSelectedCount() === 0 || isLoading
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {isLoading ? (
              <span className="flex items-center">
                <Loader2 className="animate-spin mr-2" size={16} />
                Profiling...
              </span>
            ) : (
              'Run Profile'
            )}
          </button>
        </div>
      </div>

      <div className="border rounded-lg max-h-96 overflow-y-auto">
        {catalogs.map(catalog => {
          const isExpanded = expandedCatalogs.has(catalog.name);
          const isLoading = loadingItems.has(`catalog-${catalog.name}`);
          
          return (
            <div key={catalog.name} className="border-b last:border-b-0">
              <div
                className="flex items-center p-3 hover:bg-gray-50 cursor-pointer"
                onClick={() => toggleCatalog(catalog.name)}
              >
                {isLoading ? (
                  <Loader2 className="animate-spin mr-2" size={16} />
                ) : isExpanded ? (
                  <ChevronDown size={16} className="mr-2" />
                ) : (
                  <ChevronRight size={16} className="mr-2" />
                )}
                <Database size={16} className="mr-2 text-blue-600" />
                <span className="font-medium">{catalog.name}</span>
              </div>

              {isExpanded && catalog.schemas && (
                <div className="ml-6">
                  {catalog.schemas.map(schema => {
                    const schemaKey = `${catalog.name}.${schema.name}`;
                    const isSchemaExpanded = expandedSchemas.has(schemaKey);
                    const isSchemaLoading = loadingItems.has(`schema-${schemaKey}`);

                    return (
                      <div key={schemaKey} className="border-b last:border-b-0">
                        <div
                          className="flex items-center p-3 hover:bg-gray-50 cursor-pointer"
                          onClick={() => toggleSchema(catalog.name, schema.name)}
                        >
                          {isSchemaLoading ? (
                            <Loader2 className="animate-spin mr-2" size={16} />
                          ) : isSchemaExpanded ? (
                            <ChevronDown size={16} className="mr-2" />
                          ) : (
                            <ChevronRight size={16} className="mr-2" />
                          )}
                          <Database size={16} className="mr-2 text-green-600" />
                          <span>{schema.name}</span>
                        </div>

                        {isSchemaExpanded && schema.tables && (
                          <div className="ml-6">
                            {schema.tables.map(table => {
                              const tableKey = `${catalog.name}.${schema.name}.${table.name}`;
                              const isTableExpanded = expandedTables.has(tableKey);
                              const isTableLoading = loadingItems.has(`table-${tableKey}`);
                              const selectedTableFields = selectedFields.get(tableKey);

                              return (
                                <div key={tableKey} className="border-b last:border-b-0">
                                  <div
                                    className="flex items-center p-3 hover:bg-gray-50 cursor-pointer"
                                    onClick={() => toggleTable(catalog.name, schema.name, table.name)}
                                  >
                                    {isTableLoading ? (
                                      <Loader2 className="animate-spin mr-2" size={16} />
                                    ) : isTableExpanded ? (
                                      <ChevronDown size={16} className="mr-2" />
                                    ) : (
                                      <ChevronRight size={16} className="mr-2" />
                                    )}
                                    <Table size={16} className="mr-2 text-purple-600" />
                                    <span>{table.name}</span>
                                    {selectedTableFields && selectedTableFields.size > 0 && (
                                      <span className="ml-2 px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-full">
                                        {selectedTableFields.size}
                                      </span>
                                    )}
                                  </div>

                                  {isTableExpanded && table.columns && (
                                    <div className="ml-6 bg-gray-50">
                                      <div className="p-2 border-b">
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            toggleAllFieldsInTable(
                                              catalog.name,
                                              schema.name,
                                              table.name,
                                              table.columns?.map(c => c.name) || []
                                            );
                                          }}
                                          className="text-xs text-blue-600 hover:text-blue-800"
                                        >
                                          {selectedTableFields?.size === table.columns.length
                                            ? 'Deselect All'
                                            : 'Select All'}
                                        </button>
                                      </div>
                                      {table.columns.map(column => {
                                        const isSelected = selectedTableFields?.has(column.name);

                                        return (
                                          <div
                                            key={column.name}
                                            className="flex items-center p-2 hover:bg-gray-100 cursor-pointer"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              toggleFieldSelection(
                                                catalog.name,
                                                schema.name,
                                                table.name,
                                                column.name
                                              );
                                            }}
                                          >
                                            <div
                                              className={`w-4 h-4 mr-2 border-2 rounded flex items-center justify-center ${
                                                isSelected
                                                  ? 'bg-blue-600 border-blue-600'
                                                  : 'border-gray-300'
                                              }`}
                                            >
                                              {isSelected && <Check size={12} className="text-white" />}
                                            </div>
                                            <Columns size={14} className="mr-2 text-gray-500" />
                                            <span className="text-sm">{column.name}</span>
                                            <span className="ml-auto text-xs text-gray-500">
                                              {column.type}
                                            </span>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default DataSelector;
