/**
 * Advanced Visualization Components for Data Profiling
 * Includes: Box Plots, Word Clouds, Time Series, Heatmaps
 */

import React, { useState, useEffect } from 'react';
import {
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  LineChart,
  Line,
  Legend,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import ReactWordcloud from 'react-wordcloud';
import { BarChart3, Cloud, Calendar, Clock, Loader2 } from 'lucide-react';

// ============================================================================
// Box Plot Component
// ============================================================================

interface BoxPlotProps {
  data: {
    min: number;
    q25: number;
    median: number;
    q75: number;
    max: number;
    mean: number;
    outliers?: number[];
  };
  columnName: string;
}

export const BoxPlot: React.FC<BoxPlotProps> = ({ data }) => {
  const { min, q25, median, q75, max, mean, outliers = [] } = data;
  
  // Calculate box plot dimensions
  const range = max - min;
  const scale = 100 / range;
  
  const minPos = 0;
  const q25Pos = (q25 - min) * scale;
  const q75Pos = (q75 - min) * scale;
  const maxPos = 100;
  const meanPos = (mean - min) * scale;
  
  // IQR for outlier detection
  const iqr = q75 - q25;
  const lowerFence = q25 - 1.5 * iqr;
  const upperFence = q75 + 1.5 * iqr;
  
  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl border-2 border-blue-200">
      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
        <BarChart3 className="w-5 h-5 text-blue-600" />
        Box Plot - Distribution Analysis
      </h3>
      
      <div className="bg-white p-6 rounded-lg border border-blue-200">
        {/* Visual Box Plot */}
        <div className="relative h-32 mb-8">
          {/* Whisker line */}
          <div 
            className="absolute top-1/2 h-0.5 bg-slate-400"
            style={{ left: `${minPos}%`, width: `${maxPos - minPos}%` }}
          />
          
          {/* Min marker */}
          <div 
            className="absolute top-1/2 transform -translate-y-1/2"
            style={{ left: `${minPos}%` }}
          >
            <div className="w-0.5 h-12 bg-slate-600" />
            <div className="text-xs text-slate-600 mt-1 -ml-4">Min</div>
          </div>
          
          {/* Box (IQR) */}
          <div 
            className="absolute top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-blue-400 to-blue-500 border-2 border-blue-600 rounded"
            style={{ 
              left: `${q25Pos}%`, 
              width: `${q75Pos - q25Pos}%`,
              height: '60px'
            }}
          >
            {/* Median line */}
            <div 
              className="absolute top-0 bottom-0 w-1 bg-red-600"
              style={{ left: `${((median - q25) / (q75 - q25)) * 100}%` }}
            />
          </div>
          
          {/* Mean marker (diamond) */}
          <div 
            className="absolute top-1/2 transform -translate-y-1/2 -translate-x-1/2"
            style={{ left: `${meanPos}%` }}
          >
            <div className="w-3 h-3 bg-green-500 border-2 border-green-700 rotate-45" />
          </div>
          
          {/* Max marker */}
          <div 
            className="absolute top-1/2 transform -translate-y-1/2"
            style={{ left: `${maxPos}%` }}
          >
            <div className="w-0.5 h-12 bg-slate-600" />
            <div className="text-xs text-slate-600 mt-1 -ml-3">Max</div>
          </div>
          
          {/* Outliers */}
          {outliers.map((value, idx) => {
            const pos = ((value - min) / range) * 100;
            return (
              <div 
                key={idx}
                className="absolute top-1/2 transform -translate-y-1/2 -translate-x-1/2"
                style={{ left: `${pos}%` }}
                title={`Outlier: ${value}`}
              >
                <div className="w-2 h-2 bg-red-500 rounded-full border border-red-700" />
              </div>
            );
          })}
        </div>
        
        {/* Statistics Table */}
        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="text-center p-3 bg-slate-50 rounded border border-slate-200">
            <div className="text-xs text-slate-600 mb-1">Minimum</div>
            <div className="text-lg font-bold text-slate-900">{min.toFixed(2)}</div>
          </div>
          <div className="text-center p-3 bg-blue-50 rounded border border-blue-200">
            <div className="text-xs text-blue-600 mb-1">Q1 (25%)</div>
            <div className="text-lg font-bold text-blue-900">{q25.toFixed(2)}</div>
          </div>
          <div className="text-center p-3 bg-red-50 rounded border border-red-200">
            <div className="text-xs text-red-600 mb-1">Median</div>
            <div className="text-lg font-bold text-red-900">{median.toFixed(2)}</div>
          </div>
          <div className="text-center p-3 bg-green-50 rounded border border-green-200">
            <div className="text-xs text-green-600 mb-1">Mean</div>
            <div className="text-lg font-bold text-green-900">{mean.toFixed(2)}</div>
          </div>
          <div className="text-center p-3 bg-blue-50 rounded border border-blue-200">
            <div className="text-xs text-blue-600 mb-1">Q3 (75%)</div>
            <div className="text-lg font-bold text-blue-900">{q75.toFixed(2)}</div>
          </div>
          <div className="text-center p-3 bg-slate-50 rounded border border-slate-200">
            <div className="text-xs text-slate-600 mb-1">Maximum</div>
            <div className="text-lg font-bold text-slate-900">{max.toFixed(2)}</div>
          </div>
        </div>
        
        {/* IQR and Range Info */}
        <div className="mt-6 grid grid-cols-2 gap-4">
          <div className="bg-purple-50 p-3 rounded border border-purple-200">
            <div className="text-sm font-semibold text-purple-900">
              IQR (Interquartile Range)
            </div>
            <div className="text-2xl font-bold text-purple-700">{iqr.toFixed(2)}</div>
            <div className="text-xs text-purple-600 mt-1">Q3 - Q1</div>
          </div>
          <div className="bg-orange-50 p-3 rounded border border-orange-200">
            <div className="text-sm font-semibold text-orange-900">
              Range (Max - Min)
            </div>
            <div className="text-2xl font-bold text-orange-700">{range.toFixed(2)}</div>
            <div className="text-xs text-orange-600 mt-1">Full data spread</div>
          </div>
        </div>
        
        {/* Outlier Info */}
        {outliers.length > 0 && (
          <div className="mt-4 bg-red-50 border border-red-200 p-3 rounded">
            <div className="text-sm font-semibold text-red-900 mb-2">
              ⚠️ Outliers Detected: {outliers.length} values
            </div>
            <div className="text-xs text-red-700">
              Values outside [{lowerFence.toFixed(2)}, {upperFence.toFixed(2)}] range
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// Word Cloud Component
// ============================================================================

interface WordCloudProps {
  values: Array<{ value: string; count: number }>;
  columnName: string;
}

export const WordCloudVisualization: React.FC<WordCloudProps> = ({ values }) => {
  // Filter to short words only (1-2 words, each word <= 15 chars)
  const filteredValues = values.filter(item => {
    const words = String(item.value).trim().split(/\s+/);
    return words.length <= 2 && words.every(w => w.length <= 15);
  });
  
  if (filteredValues.length === 0) {
    return (
      <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 text-center">
        <Cloud className="w-12 h-12 mx-auto text-slate-400 mb-3" />
        <p className="text-slate-600">
          Word cloud not available. Column contains values too long for visualization.
        </p>
        <p className="text-xs text-slate-500 mt-2">
          (Best for short text: 1-2 words, max 15 characters each)
        </p>
      </div>
    );
  }
  
  // Transform data for react-wordcloud
  const words = filteredValues.map(item => ({
    text: String(item.value),
    value: item.count
  }));
  
  const options = {
    rotations: 2,
    rotationAngles: [0, 90] as [number, number],
    fontSizes: [16, 80] as [number, number],
    padding: 4,
    spiral: 'rectangular' as const,
    scale: 'log' as const,
    transitionDuration: 500,
  };
  
  const callbacks = {
    getWordColor: () => {
      const colors = [
        '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', 
        '#10b981', '#06b6d4', '#6366f1', '#ef4444'
      ];
      return colors[Math.floor(Math.random() * colors.length)];
    },
  };
  
  return (
    <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl border-2 border-purple-200">
      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
        <Cloud className="w-5 h-5 text-purple-600" />
        Word Cloud - Value Frequency
      </h3>
      
      <div className="bg-white p-6 rounded-lg border border-purple-200" style={{ height: '400px' }}>
        <ReactWordcloud
          words={words}
          options={options}
          callbacks={callbacks}
        />
      </div>
      
      <div className="mt-4 text-xs text-slate-600 text-center">
        Size indicates frequency • {words.length} unique values displayed
      </div>
    </div>
  );
};

// ============================================================================
// Time Series Component with Day-of-Week and Hour-of-Day Analysis
// ============================================================================

interface TimeSeriesProps {
  data: Array<{ date: string; count: number }>;
  columnName: string;
  catalog: string;
  schema: string;
  table: string;
}

export const TimeSeriesChart: React.FC<TimeSeriesProps> = ({ data, columnName, catalog, schema, table }) => {
  const [temporalData, setTemporalData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTemporalAnalysis();
  }, [columnName]);

  const fetchTemporalAnalysis = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/temporal/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          catalog,
          schema,
          table,
          column: columnName // columnName is already just the column name
        })
      });

      if (response.ok) {
        const result = await response.json();
        setTemporalData(result);
      }
    } catch (error) {
      console.error('Error fetching temporal analysis:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!data || data.length === 0) {
    return (
      <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 text-center">
        <Calendar className="w-12 h-12 mx-auto text-slate-400 mb-3" />
        <p className="text-slate-600">No temporal data available for time series visualization.</p>
      </div>
    );
  }
  
  // Sort by date for line chart
  const sortedData = [...data].sort((a, b) => 
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  // Define day order for proper sorting
  const dayOrder = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayColors = ['#ef4444', '#f97316', '#f59e0b', '#10b981', '#06b6d4', '#3b82f6', '#8b5cf6'];
  
  return (
    <div className="space-y-6">
      {/* Original Time Series Line Chart */}
      <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl border-2 border-green-200">
        <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-green-600" />
          Time Series - Temporal Distribution
        </h3>
        
        <div className="bg-white p-6 rounded-lg border border-green-200">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={sortedData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#ffffff', 
                  border: '1px solid #cbd5e1',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="count" 
                stroke="#10b981" 
                strokeWidth={3}
                dot={{ fill: '#059669', r: 4 }}
                activeDot={{ r: 6 }}
                name="Record Count"
              />
            </LineChart>
          </ResponsiveContainer>
          
          <div className="mt-4 grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-green-50 rounded border border-green-200">
              <div className="text-xs text-green-600 mb-1">Data Points</div>
              <div className="text-lg font-bold text-green-900">{sortedData.length}</div>
            </div>
            <div className="text-center p-3 bg-green-50 rounded border border-green-200">
              <div className="text-xs text-green-600 mb-1">Date Range</div>
              <div className="text-sm font-bold text-green-900">
                {sortedData.length > 0 ? `${sortedData[0].date} → ${sortedData[sortedData.length - 1].date}` : 'N/A'}
              </div>
            </div>
            <div className="text-center p-3 bg-green-50 rounded border border-green-200">
              <div className="text-xs text-green-600 mb-1">Total Records</div>
              <div className="text-lg font-bold text-green-900">
                {sortedData.reduce((sum, d) => sum + d.count, 0).toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Day of Week Histogram */}
      {loading ? (
        <div className="bg-blue-50 p-12 rounded-xl border-2 border-blue-200 text-center">
          <Loader2 className="w-12 h-12 mx-auto text-blue-600 animate-spin mb-4" />
          <p className="text-blue-900 font-semibold">Analyzing temporal patterns...</p>
        </div>
      ) : temporalData?.dayOfWeek && temporalData.dayOfWeek.length > 0 ? (
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl border-2 border-blue-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            Day of Week Distribution
          </h3>
          
          <div className="bg-white p-6 rounded-lg border border-blue-200">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={temporalData.dayOfWeek}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis 
                  dataKey="day" 
                  tick={{ fontSize: 12 }}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#ffffff', 
                    border: '1px solid #cbd5e1',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Bar dataKey="count" name="Record Count" radius={[8, 8, 0, 0]}>
                  {temporalData.dayOfWeek.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={dayColors[dayOrder.indexOf(entry.day)] || '#3b82f6'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>

            <div className="mt-4 grid grid-cols-7 gap-2">
              {temporalData.dayOfWeek.map((day: any, idx: number) => {
                const pct = (day.count / temporalData.dayOfWeek.reduce((sum: number, d: any) => sum + d.count, 0) * 100);
                return (
                  <div key={idx} className="text-center p-2 bg-blue-50 rounded border border-blue-200">
                    <div className="text-xs text-blue-600 mb-1 font-semibold">{day.day.substring(0, 3)}</div>
                    <div className="text-sm font-bold text-blue-900">{day.count.toLocaleString()}</div>
                    <div className="text-xs text-blue-600">({pct.toFixed(1)}%)</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : null}

      {/* Hour of Day Chart */}
      {!loading && temporalData?.hourOfDay && temporalData.hourOfDay.length > 0 && (
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl border-2 border-purple-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-purple-600" />
            Hour of Day Distribution (24-Hour Pattern)
          </h3>
          
          <div className="bg-white p-6 rounded-lg border border-purple-200">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={temporalData.hourOfDay}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis 
                  dataKey="hour" 
                  tick={{ fontSize: 12 }}
                  label={{ value: 'Hour (0-23)', position: 'insideBottom', offset: -5 }}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#ffffff', 
                    border: '1px solid #cbd5e1',
                    borderRadius: '8px'
                  }}
                  formatter={(value: any) => {
                    return [value.toLocaleString(), 'Records'];
                  }}
                  labelFormatter={(hour: number) => `${hour}:00 - ${hour}:59`}
                />
                <Legend />
                <Bar 
                  dataKey="count" 
                  name="Record Count"
                  fill="#8b5cf6"
                  radius={[8, 8, 0, 0]}
                >
                  {temporalData.hourOfDay.map((entry: any, index: number) => {
                    // Color code by time of day
                    let color = '#8b5cf6'; // Default purple
                    if (entry.hour >= 6 && entry.hour < 12) color = '#f59e0b'; // Morning (orange)
                    else if (entry.hour >= 12 && entry.hour < 18) color = '#10b981'; // Afternoon (green)
                    else if (entry.hour >= 18 && entry.hour < 22) color = '#3b82f6'; // Evening (blue)
                    else color = '#6366f1'; // Night (indigo)
                    
                    return <Cell key={`cell-${index}`} fill={color} />;
                  })}
                </Bar>
              </BarChart>
            </ResponsiveContainer>

            <div className="mt-4 grid grid-cols-4 gap-3">
              {[
                { label: 'Night (22-6)', color: '#6366f1', hours: [22, 23, 0, 1, 2, 3, 4, 5] },
                { label: 'Morning (6-12)', color: '#f59e0b', hours: [6, 7, 8, 9, 10, 11] },
                { label: 'Afternoon (12-18)', color: '#10b981', hours: [12, 13, 14, 15, 16, 17] },
                { label: 'Evening (18-22)', color: '#3b82f6', hours: [18, 19, 20, 21] }
              ].map((period, idx) => {
                const periodCount = temporalData.hourOfDay
                  .filter((h: any) => period.hours.includes(h.hour))
                  .reduce((sum: number, h: any) => sum + h.count, 0);
                const pct = (periodCount / temporalData.hourOfDay.reduce((sum: number, h: any) => sum + h.count, 0) * 100);
                
                return (
                  <div key={idx} className="text-center p-3 bg-purple-50 rounded border border-purple-200">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: period.color }} />
                      <div className="text-xs text-purple-600 font-semibold">{period.label}</div>
                    </div>
                    <div className="text-lg font-bold text-purple-900">{periodCount.toLocaleString()}</div>
                    <div className="text-xs text-purple-600">({pct.toFixed(1)}%)</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default {
  BoxPlot,
  WordCloudVisualization,
  TimeSeriesChart
};

