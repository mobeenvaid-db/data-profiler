# Quick Deployment Guide

## 🚀 Deploy in 2 Steps (No Build Required!)

> **✨ Pre-Built & Ready**: The `client/build/` directory is committed to the repository with pre-compiled React assets. Deploy immediately without installing Node.js, npm, or any frontend dependencies!

### Prerequisites
- Databricks CLI configured (`databricks auth login`)
- That's it! No Node.js or Python needed locally.

### Step 1: Deploy to Databricks Workspace
```bash
# Create temp deployment directory
mkdir -p deploy_tmp/client

# Copy required files
cp databricks_app.py app.yaml requirements.txt deploy_tmp/
cp -r client/build deploy_tmp/client/

# Upload to workspace
databricks workspace import-dir deploy_tmp /Workspace/Users/<your.email@company.com>/data-profiling-app --overwrite

# Clean up
rm -rf deploy_tmp

echo "✅ Deployed successfully!"
```

### Step 2: Create/Update Databricks App

**First Time Setup:**
1. Go to Databricks workspace UI
2. Click **Apps** in the left sidebar
3. Click **Create App**
4. **Source path**: `/Workspace/Users/<your.email@company.com>/data-profiling-app`
5. **SQL Warehouse**: Select your SQL warehouse
6. Click **Create**

**Subsequent Updates:**
The app will automatically redeploy when you run Step 1. Just refresh your browser.

---

## 🔨 Building from Source (Optional)

**Only needed if you modify the frontend code!**

If you make changes to React components, you'll need to rebuild:

```bash
cd <your-local-path>/data_profiler_app

# Install dependencies (first time only)
npm install

# Build the frontend
npm run build
```

**Expected Output**:
```
✓ 1363 modules transformed.
client/build/index.html                         0.63 kB
client/build/assets/index-*.css                 51.78 kB
client/build/assets/icons-*.js                  10.35 kB
client/build/assets/index-*.js                  59.22 kB
client/build/assets/react-vendor-*.js          140.92 kB
✓ built in 10.06s
```

Then deploy using Step 1 above.

---

## 📝 Required Files

These 3 files + the `client/build` directory are all you need:

```
deploy_tmp/
├── databricks_app.py    # FastAPI backend
├── app.yaml             # Databricks Apps config
├── requirements.txt     # Python dependencies
└── client/
    └── build/           # Compiled React app
        ├── index.html
        └── assets/
```

---

## ⚡ One-Line Deploy Command

```bash
cd <your-local-path>/data_profiler_app && \
mkdir -p deploy_tmp/client && \
cp databricks_app.py app.yaml requirements.txt deploy_tmp/ && \
cp -r client/build deploy_tmp/client/ && \
databricks workspace import-dir deploy_tmp /Workspace/Users/<your.email@company.com>/data-profiling-app --overwrite && \
rm -rf deploy_tmp && \
echo "✅ Deployed to Databricks!"
```

---

## 🔧 Configuration

### app.yaml
```yaml
command: ["uvicorn", "databricks_app:api_app", "--host", "0.0.0.0", "--port", "8000"]

resources:
  - name: main_sql_warehouse
    description: SQL warehouse for profiling queries
    sql_warehouse:
      permission: CAN_USE

env:
  - name: SQL_WAREHOUSE_ID
    value: "{{resources.main_sql_warehouse.id}}"
```

### No Manual Environment Variables Needed!
The app automatically:
- Gets SQL Warehouse ID from `app.yaml` resources
- Uses Databricks Apps OAuth tokens
- Configures CORS for the app domain

---

## ✅ Verification Checklist

After deployment, verify:

- [ ] App shows "Running" status in Databricks Apps UI
- [ ] App URL loads without 500 errors
- [ ] Catalogs load in the dropdown (not "Loading...")
- [ ] Can expand schemas and tables
- [ ] Can select fields and click "Run Profile"
- [ ] Profiling completes and shows results
- [ ] Can click "Details" on any column
- [ ] Export Excel button works

---

## 🐛 Troubleshooting

### Build Fails
```bash
# Clear cache and rebuild
rm -rf node_modules client/build
npm install
npm run build
```

### Deploy Fails
```bash
# Check Databricks CLI is configured
databricks auth login --host https://your-workspace.cloud.databricks.com

# Verify path is correct
databricks workspace list /Workspace/Users/<your.email@company.com>/
```

### App Crashes on Startup
Check app logs in Databricks Apps console for:
- `ImportError`: Missing Python dependencies (check requirements.txt)
- `ModuleNotFoundError`: File paths incorrect
- `Permission denied`: SQL Warehouse access issues

### App Loads But Shows Errors
- **Catalogs won't load**: Check SQL Warehouse is running and accessible
- **500 errors in console**: Check app logs for Python tracebacks
- **Blank screen**: Check browser console for JavaScript errors

---

## 📊 App Logs Location

In Databricks workspace:
1. Go to **Apps**
2. Click your app name
3. Click **Logs** tab
4. Filter by time range

Look for:
- `[ERROR]` entries for crashes
- `✅` entries for successful operations
- `🔍` entries for debugging info

---

## 🔄 Deployment Workflow

### Quick Deploy (Pre-Built Files)
```
┌─────────────────┐
│  Clone Repo     │  ← Get the code (client/build/ included!)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Deploy Command │  ← Uploads files to workspace
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  App Starts     │  ← Databricks runs the app
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Open in Browser│  ← Start profiling!
└─────────────────┘
```

### Development Workflow (Modifying Code)
```
┌─────────────────┐
│  Edit Code      │  ← Modify React/Python files
│  (locally)      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  npm run build  │  ← Only if you changed frontend
│  (optional)     │     Skip for Python-only changes
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Deploy Command │  ← Uploads files to workspace
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  App Auto-      │  ← Databricks detects changes
│  Redeploys      │     and restarts the app
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Refresh Browser│  ← See your changes live
└─────────────────┘
```

---

## 💡 Pro Tips

1. **✨ Pre-Built & Ready**: Users can deploy directly from the repo without Node.js!
2. **No Need to Rebuild Frontend** if only changing Python code
3. **Snapshots Persist** across deploys (stored in `/tmp/`)
4. **Multiple Workers** are handled automatically
5. **Real-Time Logs** available in Databricks Apps console
6. **Browser Cache**: Hard refresh (Cmd+Shift+R) if UI doesn't update

---

**Need help?** Check the main README.md for detailed documentation.

