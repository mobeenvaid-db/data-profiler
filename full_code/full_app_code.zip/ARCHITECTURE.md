# Architecture Documentation

## System Overview

The Databricks Data Profiler is a full-stack application with a React frontend and Python backend that connects to Databricks SQL for data profiling operations.

```
┌─────────────────────────────────────────────────────────────────┐
│                         User Browser                            │
│                                                                 │
│  ┌───────────────────────────────────────────────────────┐    │
│  │           React Frontend (Port 3000)                  │    │
│  │                                                        │    │
│  │  • DataSelector Component                             │    │
│  │  • DataProfilingDashboard Component                   │    │
│  │  • SQL Query Generator (sqlProfiler.ts)               │    │
│  │  • Profiling Service (profilingService.ts)            │    │
│  └────────────────────┬──────────────────────────────────┘    │
└────────────────────────┼──────────────────────────────────────┘
                         │ HTTP/REST API
                         │
┌────────────────────────┼──────────────────────────────────────┐
│                        │                                       │
│  ┌────────────────────▼──────────────────────────────────┐   │
│  │      Python Backend API (Port 8000)                   │   │
│  │                                                        │   │
│  │  • FastAPI Server                                     │   │
│  │  • Databricks SQL Connector                           │   │
│  │  • Query Execution Engine                             │   │
│  │  • Result Transformation                              │   │
│  └────────────────────┬──────────────────────────────────┘   │
│                 Python Backend Server                         │
└────────────────────────┼──────────────────────────────────────┘
                         │ Databricks SQL Protocol
                         │
┌────────────────────────▼──────────────────────────────────────┐
│                  Databricks Workspace                          │
│                                                                │
│  ┌──────────────────────────────────────────────────────┐    │
│  │              SQL Warehouse                           │    │
│  │                                                       │    │
│  │  • Query Execution                                   │    │
│  │  • Data Access                                       │    │
│  │  • Result Caching                                    │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                                │
│  ┌──────────────────────────────────────────────────────┐    │
│  │              Unity Catalog                           │    │
│  │                                                       │    │
│  │  • Catalogs                                          │    │
│  │  • Schemas                                           │    │
│  │  • Tables                                            │    │
│  │  • Metadata                                          │    │
│  └──────────────────────────────────────────────────────┘    │
└────────────────────────────────────────────────────────────────┘
```

## Component Architecture

### Frontend Architecture

```
app.tsx (Main Application)
├── State Management
│   ├── appState: 'selection' | 'profiling' | 'results'
│   ├── selectedFields: SelectedFields[]
│   ├── profileResult: ProfileResult
│   └── error: string
├── Components
│   ├── DataSelector
│   │   ├── Catalog Tree Browser
│   │   ├── Field Selection Logic
│   │   └── Selection Summary
│   └── DataProfilingDashboard
│       ├── Executive Summary
│       ├── Type Distribution Chart
│       ├── Quality Overview
│       ├── Column Table
│       └── Column Detail Modal
└── Services
    ├── profilingService.ts
    │   ├── executeProfilingQueries()
    │   ├── exportToCSV()
    │   └── downloadMultiSheetExport()
    └── sqlProfiler.ts
        ├── generateProfilingQueries()
        ├── calculateQualityScore()
        └── inferDataType()
```

### Backend Architecture

```
api.py (FastAPI Server)
├── Endpoints
│   ├── GET / (Health Check)
│   ├── GET /api/catalog-tree (Metadata Discovery)
│   ├── POST /api/databricks/execute (Query Execution)
│   ├── GET /api/catalogs (List Catalogs)
│   ├── GET /api/schemas/{catalog} (List Schemas)
│   ├── GET /api/tables/{catalog}/{schema} (List Tables)
│   └── GET /api/columns/{catalog}/{schema}/{table} (List Columns)
├── Connection Management
│   └── get_databricks_connection()
└── Error Handling
    └── HTTPException with status codes
```

## Data Flow

### 1. Selection Phase

```
User Action → DataSelector Component
  ↓
Catalog Tree Loading
  ↓
GET /api/catalog-tree
  ↓
Backend: SHOW CATALOGS
Backend: SHOW SCHEMAS IN {catalog}
Backend: SHOW TABLES IN {catalog}.{schema}
Backend: DESCRIBE TABLE {catalog}.{schema}.{table}
  ↓
Return JSON tree structure
  ↓
User selects fields
  ↓
selectedFields state updated
```

### 2. Profiling Phase

```
User clicks "Profile Selected Fields"
  ↓
app.tsx: handleStartProfiling()
  ↓
profilingService.executeProfilingQueries(selections)
  ↓
Generate SQL queries for each field
  ↓
POST /api/databricks/execute with queries array
  ↓
Backend: Execute each query via Databricks SQL
  ↓
Fetch and transform results
  ↓
Return ProfileResult object
  ↓
Display in DataProfilingDashboard
```

### 3. Export Phase

```
User clicks "Export Report"
  ↓
app.tsx: handleExport()
  ↓
profilingService.downloadMultiSheetExport(profileResult)
  ↓
Generate CSV content for each sheet:
  - Summary
  - Detailed
  - Patterns
  - Quality
  ↓
Create Blob objects
  ↓
Trigger browser downloads
```

## SQL Query Architecture

### Query Generation Strategy

Each profiled field gets a comprehensive query with multiple CTEs:

```sql
WITH base_stats AS (
  -- Core metrics: totals, nulls, uniques
  SELECT COUNT(*), COUNT(field), COUNT(DISTINCT field)
),
value_frequencies AS (
  -- Top 10 most frequent values
  SELECT field, COUNT(*) as frequency
  GROUP BY field ORDER BY frequency DESC LIMIT 10
),
pattern_analysis AS (
  -- Pattern detection using REGEXP_LIKE
  SELECT CASE 
    WHEN field REGEXP ... THEN 'PATTERN_TYPE'
  END as pattern_type
),
type_inference AS (
  -- Infer actual data type
  SELECT inferred_type, COUNT(*) as type_count
  GROUP BY inferred_type
)
SELECT * FROM base_stats 
CROSS JOIN value_frequencies
CROSS JOIN type_inference;
```

### Query Optimization Techniques

1. **CTEs for Clarity**: Breaking complex logic into readable steps
2. **Window Functions**: Using ROW_NUMBER() for ranking
3. **COLLECT_LIST**: Aggregating multiple results efficiently
4. **Limit Clauses**: Preventing excessive data transfer
5. **Sampling**: Optional TABLESAMPLE for large tables

## State Management

### Application States

```typescript
type AppState = 'selection' | 'profiling' | 'results';

'selection': User selecting catalogs/schemas/tables/fields
'profiling': Executing queries, showing loading indicator
'results': Displaying profiling dashboard with data
```

### Data Models

```typescript
interface SelectedFields {
  catalog: string;
  schema: string;
  table: string;
  fields: string[];
}

interface ColumnProfile {
  name: string;
  uniqueValues: number;
  uniquePct: number;
  nulls: number;
  nullPct: number;
  inferredType: string;
  inferredPct: number;
  documentedType: string;
  minValue: string;
  maxValue: string;
  avgLength: number;
  patterns: string[];
  frequency: { top3: Array<{value: string; count: number}> };
}

interface ProfileResult {
  profileName: string;
  totalRows: number;
  columns: ColumnProfile[];
  // ... other metadata
}
```

## Quality Scoring Algorithm

```
Initial Score: 100

Penalties:
1. Completeness: -min(nullPct * 0.4, 40)
   Example: 50% nulls = -20 points

2. Low Uniqueness: -min((100 - uniquePct) * 0.15, 15)
   Only if uniqueCount > 10
   Example: 30% unique = -10.5 points

3. Type Consistency: -min((100 - typeConsistency) * 0.25, 25)
   Example: 80% consistent = -5 points

4. Schema Mismatch: -20 points
   If inferred type ≠ documented type

Final Score: max(0, 100 - total_penalties)

Categories:
95-100: Excellent (Green)
80-94:  Good (Yellow)
0-79:   Needs Attention (Red)
```

## Performance Considerations

### Frontend Optimizations

1. **React.memo**: Memoize column rows to prevent unnecessary re-renders
2. **Virtual Scrolling**: For tables with many columns (future enhancement)
3. **Lazy Loading**: Load catalog tree incrementally
4. **Debounced Search**: Prevent excessive filtering operations

### Backend Optimizations

1. **Connection Pooling**: Reuse Databricks connections
2. **Query Batching**: Execute multiple queries in parallel
3. **Result Caching**: Cache catalog metadata
4. **Async Processing**: Non-blocking query execution

### Database Optimizations

1. **Sampling**: Use TABLESAMPLE for large tables
2. **Predicate Pushdown**: Leverage partitioned tables
3. **Result Limits**: Fetch only necessary data
4. **Indexed Lookups**: Ensure proper indexing

## Security Architecture

### Authentication Flow

```
Frontend → Backend API
  ↓
Backend validates request
  ↓
Backend uses stored Databricks token
  ↓
Databricks validates token
  ↓
Execute query with user's permissions
  ↓
Return results
```

### Security Best Practices

1. **Token Storage**: Environment variables, never in code
2. **HTTPS Only**: All production traffic encrypted
3. **CORS**: Restrict allowed origins
4. **Rate Limiting**: Prevent abuse (future enhancement)
5. **Input Validation**: Sanitize all user inputs
6. **SQL Injection Prevention**: Use parameterized queries

## Error Handling

### Error Categories

1. **Network Errors**: Connection failures, timeouts
2. **Authentication Errors**: Invalid tokens, expired credentials
3. **Permission Errors**: Unauthorized access to catalogs/tables
4. **Query Errors**: Invalid SQL, runtime errors
5. **Data Errors**: Unexpected data formats

### Error Handling Strategy

```typescript
try {
  const result = await executeQuery();
  return result;
} catch (error) {
  if (error.code === 'TIMEOUT') {
    // Suggest sampling
  } else if (error.code === 'PERMISSION_DENIED') {
    // Show permission error
  } else {
    // Generic error message
  }
  logError(error);
  showUserFriendlyMessage(error);
}
```

## Deployment Architecture

### Development Environment

```
Frontend: Vite Dev Server (localhost:3000)
Backend: Python/Uvicorn (localhost:8000)
Databricks: Development Workspace
```

### Production Environment

```
Frontend: Static files on CDN/S3
Backend: Container/VM with Python API
Databricks: Production Workspace
Load Balancer: HTTPS termination
```

## Scalability Considerations

### Horizontal Scaling

- **Backend**: Multiple API instances behind load balancer
- **Databricks**: Auto-scaling SQL Warehouse
- **Caching**: Redis for catalog metadata

### Vertical Scaling

- **SQL Warehouse**: Increase cluster size
- **API Server**: Increase memory/CPU
- **Connection Pool**: Adjust pool size

## Monitoring & Observability

### Metrics to Track

1. **Query Performance**: Execution time per field
2. **Error Rates**: Failed queries percentage
3. **API Latency**: Request/response times
4. **User Activity**: Profiling sessions per hour
5. **Resource Usage**: SQL Warehouse utilization

### Logging Strategy

```python
# Backend logging
logger.info(f"Profiling {len(queries)} fields")
logger.error(f"Query failed: {error}", extra={"query": query})

# Frontend logging
console.log('Profiling started', { fieldCount, tables });
console.error('API error', { endpoint, error });
```

## Future Enhancements

1. **Incremental Profiling**: Profile only changed data
2. **Scheduled Jobs**: Automated profiling runs
3. **Alerting**: Notify on quality degradation
4. **ML Insights**: Anomaly detection, trend analysis
5. **Custom Rules**: User-defined quality checks
6. **Data Lineage**: Track data flow and dependencies
7. **Collaborative Features**: Share profiles, comments
8. **Historical Tracking**: Compare profiles over time

---

For implementation details, see the [README](README.md) and source code documentation.

