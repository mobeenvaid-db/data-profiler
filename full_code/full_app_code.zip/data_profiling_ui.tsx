import React, { useState } from 'react';
import { Search, Filter, Download, AlertCircle, CheckCircle, Info, TrendingUp, TrendingDown, Database, FileText, BarChart3, PieChart, Activity, Calendar, Hash, Type, Percent, Eye, ChevronRight, Settings, RefreshCw, Shuffle, Binary, Text, Network, Loader2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { BoxPlot, WordCloudVisualization, TimeSeriesChart } from './components/AdvancedVisualizations';
import { CorrelationHeatmap, CompositeKeyDetection, ConditionalProfiling } from './components/CrossColumnAnalysis';
import { AIInsights, SnapshotManager, ProfileComparison } from './components/AIInsightsAndComparison';

interface ProfileData {
  profileName: string;
  filterName: string;
  samplingPolicy: string;
  sourceName: string;
  totalRows: number;
  profileDate: string;
  dataSource: string;
  schema: string;
}

interface ColumnData {
  name: string;
  uniqueValues: number;
  uniquePct: number;
  nulls: number;
  nullPct: number;
  inferredType: string;
  inferredPct: number;
  documentedType: string;
  minValue: string;
  maxValue: string;
  avgLength: number;
  // String length analysis (ydata-profiling style)
  minLength?: number;
  maxLength?: number;
  medianLength?: number;
  patterns?: string[];
  frequency: {
    top3: Array<{ value: string; count: number; percentage?: number; frequency_pct?: number }>;
    all?: Array<{ value: string; count: number; percentage?: number; frequency_pct?: number }>; // For categorical
  };
  catalog?: string;
  schema?: string;
  table?: string;
  // Enhanced profiling data
  isCategorical?: boolean;
  cardinalityPct?: number;
  // Numerical statistics
  mean?: number;
  median?: number;
  stddev?: number;
  p25?: number;
  p75?: number;
  p95?: number;
  p99?: number;
  // Special value counts for numeric fields
  zerosCount?: number;
  negativesCount?: number;
  infiniteCount?: number;
  // Extreme values (Phase 3)
  smallestValues?: number[];
  largestValues?: number[];
  // Sample values (Phase 3)
  firstSamples?: string[];
  randomSamples?: string[];
  // Value arrays for charts
  allValues?: Array<{ value: string; count: number; frequency_pct?: number }>;
  topValues?: Array<{ value: string; count: number; frequency_pct?: number }>;
  isNumeric?: boolean;
  isDate?: boolean;
  isString?: boolean;
}

interface DashboardProps {
  profileData?: ProfileData;
  columns?: ColumnData[];
  onExport?: () => void;
  onReProfile?: () => void;
}

const DataProfilingDashboard: React.FC<DashboardProps> = ({ 
  profileData: propProfileData, 
  columns: propColumns,
  onExport,
  onReProfile
}) => {
  const [selectedColumn, setSelectedColumn] = useState<ColumnData | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [activeTab, setActiveTab] = useState('overview');
  const [showColumnSelector, setShowColumnSelector] = useState(false);
  const [showCrossColumn, setShowCrossColumn] = useState(false);
  const [crossColumnData, setCrossColumnData] = useState<any>(null);
  const [crossColumnLoading, setCrossColumnLoading] = useState(false);
  const [crossColumnProgress, setCrossColumnProgress] = useState<string>('');
  const [conditionalProfilingLoading, setConditionalProfilingLoading] = useState(false);
  const [conditionalProfilingProgress, setConditionalProfilingProgress] = useState<string>('');
  const [comparisonLoading, setComparisonLoading] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  const [comparisonData, setComparisonData] = useState<any>(null);
  
  // Column management state
  const defaultColumns = {
    name: { visible: true, minWidth: 280, width: undefined },
    dataType: { visible: true, minWidth: 180, width: undefined },
    valuePreview: { visible: true, minWidth: 220, width: undefined },
    statistics: { visible: true, minWidth: 180, width: undefined },
    uniqueValues: { visible: true, minWidth: 140, width: undefined },
    nulls: { visible: true, minWidth: 110, width: undefined },
    completeness: { visible: true, minWidth: 160, width: undefined },
    quality: { visible: true, minWidth: 110, width: undefined },
    actions: { visible: true, minWidth: 130, width: undefined }
  };
  
  const [columnConfig, setColumnConfig] = useState(() => {
    const saved = localStorage.getItem('profileColumnConfig');
    return saved ? JSON.parse(saved) : defaultColumns;
  });
  
  const [resizing, setResizing] = useState<{ column: string; startX: number; startWidth: number } | null>(null);
  
  // Save column config to localStorage
  React.useEffect(() => {
    localStorage.setItem('profileColumnConfig', JSON.stringify(columnConfig));
  }, [columnConfig]);
  
  // Handle column resize
  const handleResizeStart = (e: React.MouseEvent, columnKey: string) => {
    e.preventDefault();
    e.stopPropagation();
    const config = columnConfig[columnKey as keyof typeof defaultColumns];
    // Use current width if set, otherwise use minWidth as starting point
    const startWidth = config.width || config.minWidth || 100;
    setResizing({
      column: columnKey,
      startX: e.clientX,
      startWidth: startWidth
    });
  };
  
  React.useEffect(() => {
    if (!resizing) return;
    
    const handleMouseMove = (e: MouseEvent) => {
      if (!resizing) return;
      const diff = e.clientX - resizing.startX;
      const newWidth = Math.max(80, resizing.startWidth + diff);
      setColumnConfig((prev: typeof defaultColumns) => {
        const currentCol = prev[resizing.column as keyof typeof defaultColumns];
        return {
          ...prev,
          [resizing.column]: { 
            ...currentCol, 
            width: newWidth // Set explicit width when manually resizing
          }
        };
      });
    };
    
    const handleMouseUp = () => {
      setResizing(null);
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [resizing]);
  
  const toggleColumnVisibility = (columnKey: string) => {
    setColumnConfig((prev: typeof defaultColumns) => {
      const currentCol = prev[columnKey as keyof typeof defaultColumns];
      return {
        ...prev,
        [columnKey]: { 
          ...currentCol, 
          visible: !currentCol.visible 
        }
      };
    });
  };

  const defaultProfileData: ProfileData = {
    profileName: 'Profile_H_MBR_REL',
    filterName: 'DEL_CURR',
    samplingPolicy: 'Full Scan',
    sourceName: 'H_MBR_REL',
    totalRows: 30678394,
    profileDate: '2024-12-10',
    dataSource: 'Oracle Database',
    schema: 'PROD_DW'
  };

  const mockColumns: ColumnData[] = [
    { 
      name: 'MBR_REL_SK', 
      uniqueValues: 30642091, 
      uniquePct: 99.97, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'Integer(9)', 
      inferredPct: 100.0, 
      documentedType: 'number(38)', 
      minValue: '10000001', 
      maxValue: '99999999',
      avgLength: 8,
      patterns: ['########'],
      frequency: { top3: [{ value: 'Multiple', count: 1 }] }
    },
    { 
      name: 'RSLT_MBR_KEY', 
      uniqueValues: 25122349, 
      uniquePct: 95.02, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'Integer(9)', 
      inferredPct: 100.0, 
      documentedType: 'number(38)', 
      minValue: '10000001', 
      maxValue: '99999999',
      avgLength: 8,
      patterns: ['########'],
      frequency: { top3: [{ value: 'Multiple', count: 1 }] }
    },
    { 
      name: 'TO_MBR_KEY', 
      uniqueValues: 14945056, 
      uniquePct: 46.74, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'Integer(9)', 
      inferredPct: 100.0, 
      documentedType: 'number(38)', 
      minValue: '-1', 
      maxValue: '99999999',
      avgLength: 7.8,
      patterns: ['########', '-#'],
      frequency: { top3: [{ value: '-1', count: 15732338 }, { value: 'Multiple', count: 1 }] }
    },
    { 
      name: 'MBR_REL_TYP_ITSC_NM', 
      uniqueValues: 1, 
      uniquePct: 0.01, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'Fixed Length String(0)', 
      inferredPct: 100.0, 
      documentedType: 'varchar2(1)', 
      minValue: '', 
      maxValue: '',
      avgLength: 0,
      patterns: ['Empty'],
      frequency: { top3: [{ value: '(Empty)', count: 30678394 }] }
    },
    { 
      name: 'MBR_REL_TYP_CD', 
      uniqueValues: 2, 
      uniquePct: 0.01, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'Integer(2)', 
      inferredPct: 100.0, 
      documentedType: 'varchar2(10)', 
      minValue: '03', 
      maxValue: '18',
      avgLength: 2,
      patterns: ['##'],
      frequency: { top3: [{ value: '18', count: 15732338 }, { value: '03', count: 14946056 }] }
    },
    { 
      name: 'MBR_REL_TYP_NM', 
      uniqueValues: 2, 
      uniquePct: 0.01, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'String(23)', 
      inferredPct: 100.0, 
      documentedType: 'varchar2(100)', 
      minValue: 'Dependent to Subscriber', 
      maxValue: 'SELF',
      avgLength: 19,
      patterns: ['Mixed Case Text'],
      frequency: { top3: [{ value: 'SELF', count: 15732338 }, { value: 'Dependent to Subscriber', count: 14946056 }] }
    },
    { 
      name: 'MBR_REL_TYP_CHLD_CD', 
      uniqueValues: 11, 
      uniquePct: 0.01, 
      nulls: 2, 
      nullPct: 0.01, 
      inferredType: 'String(10)', 
      inferredPct: 100.0, 
      documentedType: 'varchar2(10)', 
      minValue: '03_ADU_DEP', 
      maxValue: 'UNK',
      avgLength: 6.3,
      patterns: ['##_AAA_AAA', 'AAA'],
      frequency: { top3: [{ value: '18_SELF', count: 15732338 }, { value: '03_DEP_CHD', count: 8234567 }, { value: '03_ADU_DEP', count: 4123456 }] }
    },
    { 
      name: 'MBR_REL_TYP_CHLD_NM', 
      uniqueValues: 11, 
      uniquePct: 0.01, 
      nulls: 2, 
      nullPct: 0.01, 
      inferredType: 'String(47)', 
      inferredPct: 100.0, 
      documentedType: 'varchar2(100)', 
      minValue: 'Adult Dependent', 
      maxValue: 'Unknown',
      avgLength: 23.5,
      patterns: ['Mixed Case Text'],
      frequency: { top3: [{ value: 'SELF', count: 15732338 }, { value: 'Dependent Child', count: 8234567 }, { value: 'Adult Dependent', count: 4123456 }] }
    },
    { 
      name: 'PAY_REL_IND', 
      uniqueValues: 1, 
      uniquePct: 0.01, 
      nulls: 30648229, 
      nullPct: 100.00, 
      inferredType: 'Fixed Length String(1)', 
      inferredPct: 100.0, 
      documentedType: 'char(1)', 
      minValue: '', 
      maxValue: '',
      avgLength: 0,
      patterns: ['Null'],
      frequency: { top3: [{ value: '(Null)', count: 30648229 }] }
    },
    { 
      name: 'PRMN_RSN_CD', 
      uniqueValues: 2, 
      uniquePct: 0.01, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'Fixed Length String(3)', 
      inferredPct: 100.0, 
      documentedType: 'varchar2(10)', 
      minValue: 'NAP', 
      maxValue: 'NAP',
      avgLength: 3,
      patterns: ['AAA'],
      frequency: { top3: [{ value: 'NAP', count: 30678394 }] }
    },
    { 
      name: 'PRMN_RSN_IND', 
      uniqueValues: 2, 
      uniquePct: 0.01, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'String(14)', 
      inferredPct: 100.0, 
      documentedType: 'varchar2(255)', 
      minValue: 'Not Applicable', 
      maxValue: 'Not Applicable',
      avgLength: 14,
      patterns: ['Mixed Case Text'],
      frequency: { top3: [{ value: 'Not Applicable', count: 30678394 }] }
    },
    { 
      name: 'EFCTV_DT', 
      uniqueValues: 35338, 
      uniquePct: 0.11, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'Date Time', 
      inferredPct: 99.99, 
      documentedType: 'date(19)', 
      minValue: '01/01/1990 00:00:00', 
      maxValue: '12/31/2024 00:00:00',
      avgLength: 19,
      patterns: ['MM/DD/YYYY HH:MM:SS'],
      frequency: { top3: [{ value: '01/01/2020 00:00:00', count: 1234567 }, { value: '01/01/2021 00:00:00', count: 987654 }] }
    },
    { 
      name: 'MBR_REL_END_DT', 
      uniqueValues: 86401, 
      uniquePct: 0.28, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'Fixed Length String(19)', 
      inferredPct: 100.0, 
      documentedType: 'date(19)', 
      minValue: '01/01/1990 00:00:00', 
      maxValue: '12/31/9999 00:00:00',
      avgLength: 19,
      patterns: ['MM/DD/YYYY HH:MM:SS'],
      frequency: { top3: [{ value: '12/31/9999 00:00:00', count: 15000000 }, { value: '12/31/2023 00:00:00', count: 2345678 }] }
    },
    { 
      name: 'SRC_SYS_CD', 
      uniqueValues: 8, 
      uniquePct: 0.01, 
      nulls: 0, 
      nullPct: 0, 
      inferredType: 'String(6)', 
      inferredPct: 100.0, 
      documentedType: 'varchar2(25)', 
      minValue: 'MDM', 
      maxValue: 'MEMMMS',
      avgLength: 5.2,
      patterns: ['AAA-AAAAAA'],
      frequency: { top3: [{ value: 'MDM', count: 18456789 }, { value: 'MEMMMS', count: 8765432 }, { value: 'LEGACY', count: 3456173 }] }
    }
  ];

  // Use props or fall back to default data
  const profileData = propProfileData || defaultProfileData;
  const columns = propColumns || mockColumns;

  const filteredColumns = columns.filter(col => {
    const matchesSearch = col.name.toLowerCase().includes(searchTerm.toLowerCase());
    const typeUpper = col.inferredType.toUpperCase();
    
    const matchesFilter = filterType === 'all' || 
      (filterType === 'issues' && (col.nullPct > 0 || col.inferredType !== col.documentedType)) ||
      (filterType === 'dates' && (typeUpper.includes('DATE') || typeUpper.includes('TIMESTAMP') || typeUpper.includes('TIME'))) ||
      (filterType === 'strings' && (typeUpper.includes('STRING') || typeUpper.includes('VARCHAR') || typeUpper.includes('TEXT') || typeUpper.includes('CHAR'))) ||
      (filterType === 'numbers' && (
        typeUpper.includes('INT') || 
        typeUpper.includes('LONG') || 
        typeUpper.includes('BIGINT') || 
        typeUpper.includes('DECIMAL') || 
        typeUpper.includes('DOUBLE') || 
        typeUpper.includes('FLOAT') || 
        typeUpper.includes('NUMBER') ||
        typeUpper.includes('NUMERIC')
      ));
    return matchesSearch && matchesFilter;
  });

  const getQualityScore = (col: ColumnData) => {
    let score = 100;
    if (col.nullPct > 0) score -= Math.min(col.nullPct, 30);
    if (col.uniquePct < 1 && col.uniqueValues > 10) score -= 5;
    if (col.inferredType !== col.documentedType) score -= 10;
    return Math.max(0, Math.round(score));
  };

  const getQualityColor = (score: number) => {
    if (score >= 95) return 'text-green-600';
    if (score >= 80) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getTypeIcon = (dataType: string) => {
    const type = dataType.toUpperCase();
    if (type.includes('INT') || type.includes('LONG') || type.includes('DECIMAL') || type.includes('DOUBLE') || type.includes('FLOAT')) {
      return <Hash className="w-4 h-4 text-blue-500" />;
    }
    if (type.includes('STRING') || type.includes('VARCHAR') || type.includes('TEXT')) {
      return <Text className="w-4 h-4 text-green-500" />;
    }
    if (type.includes('DATE') || type.includes('TIMESTAMP')) {
      return <Calendar className="w-4 h-4 text-purple-500" />;
    }
    if (type.includes('BOOLEAN') || type.includes('BOOL')) {
      return <Binary className="w-4 h-4 text-orange-500" />;
    }
    return <Type className="w-4 h-4 text-slate-400" />;
  };

  // Cross-column analysis handlers
  const handleCrossColumnAnalysis = async () => {
    if (!propColumns || propColumns.length === 0) return;
    
    // Set loading state
    setCrossColumnLoading(true);
    setShowCrossColumn(true);
    setCrossColumnProgress('Initializing cross-column analysis...');
    
    // Get numeric fields for correlation
    const numericFields = propColumns
      .filter(col => {
        const type = col.inferredType.toUpperCase();
        return type.includes('INT') || type.includes('LONG') || type.includes('DECIMAL') || 
               type.includes('DOUBLE') || type.includes('FLOAT') || type.includes('NUMBER');
      })
      .map(col => col.name);
    
    // Get all fields for composite key detection
    const allFields = propColumns.map(col => col.name);
    
    // Get catalog/schema/table from first column's properties (all columns from same table)
    const firstCol = propColumns[0];
    if (!firstCol) {
      setCrossColumnLoading(false);
      return;
    }
    
    const catalog = firstCol.catalog || '';
    const schema = firstCol.schema || '';
    const table = firstCol.table || '';
    
    try {
      // Fetch correlations
      setCrossColumnProgress(`Calculating correlations for ${numericFields.length} numerical columns...`);
      const corrResponse = await fetch('/api/cross-column/correlations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ catalog, schema, table, numericFields: numericFields.map(f => f.split('.').pop()) })
      });
      const corrData = await corrResponse.json();
      
      // Fetch composite keys
      setCrossColumnProgress(`Detecting composite key candidates from ${allFields.length} columns...`);
      const keyResponse = await fetch('/api/cross-column/composite-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ catalog, schema, table, fields: allFields.map(f => f.split('.').pop()) })
      });
      const keyData = await keyResponse.json();
      
      setCrossColumnProgress('Finalizing analysis results...');
      
      setCrossColumnData({
        correlations: corrData.correlations || [],
        compositeKeys: keyData.compositeKeys || [],
        catalog,
        schema,
        table,
        numericFields: numericFields.map(f => f.split('.').pop()),
        categoricalFields: propColumns
          .filter(col => col.inferredType.toUpperCase().includes('STRING'))
          .map(col => col.name.split('.').pop())
      });
      
      setCrossColumnProgress('');
      setCrossColumnLoading(false);
    } catch (error) {
      console.error('Error fetching cross-column analysis:', error);
      setCrossColumnProgress('Error: Failed to complete cross-column analysis');
      setCrossColumnLoading(false);
    }
  };
  
  const handleConditionalProfiling = async (numericField: string, categoricalField: string) => {
    if (!propColumns || propColumns.length === 0) return;
    
    const firstCol = propColumns[0];
    if (!firstCol) return;
    
    // Set loading state
    setConditionalProfilingLoading(true);
    setConditionalProfilingProgress(`Analyzing ${numericField} segmented by ${categoricalField}...`);
    
    // Use the column's stored catalog/schema/table properties
    const catalog = firstCol.catalog || '';
    const schema = firstCol.schema || '';
    const table = firstCol.table || '';
    
    try {
      const response = await fetch('/api/cross-column/conditional-profiling', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ catalog, schema, table, numericField, categoricalField })
      });
      const data = await response.json();
      
      setConditionalProfilingProgress('Calculating statistics for each category...');
      
      setCrossColumnData((prev: any) => ({
        ...prev,
        conditionalStats: data.conditionalStats || [],
        lastConditionalNumeric: numericField,
        lastConditionalCategorical: categoricalField
      }));
      
      setConditionalProfilingProgress('');
      setConditionalProfilingLoading(false);
    } catch (error) {
      console.error('Error fetching conditional profiling:', error);
      setConditionalProfilingProgress('Error: Failed to complete conditional profiling');
      setConditionalProfilingLoading(false);
    }
  };
  
  const handleSnapshotComparison = async (snapshot1Id: string, snapshot2Id: string) => {
    setComparisonLoading(true);
    
    try {
      console.log('Comparing snapshots:', { snapshot1Id, snapshot2Id });
      
      const response = await fetch('/api/snapshots/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ snapshotId1: snapshot1Id, snapshotId2: snapshot2Id })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Comparison API error:', errorText);
        alert(`Error comparing snapshots: ${response.status} ${response.statusText}`);
        setComparisonLoading(false);
        return;
      }
      
      const data = await response.json();
      console.log('Comparison data received:', data);
      
      setComparisonData(data.comparison || data);
      setShowComparison(true);
      setComparisonLoading(false);
    } catch (error) {
      console.error('Error comparing snapshots:', error);
      alert('Error comparing snapshots. Please check console for details.');
      setComparisonLoading(false);
    }
  };

  const stats = {
    totalColumns: columns.length,
    totalRows: profileData.totalRows,
    issuesFound: columns.filter(c => c.nullPct > 0 || getQualityScore(c) < 95).length,
    avgCompleteness: Math.round(columns.reduce((acc, c) => acc + (100 - c.nullPct), 0) / columns.length),
    avgQuality: Math.round(columns.reduce((acc, c) => acc + getQualityScore(c), 0) / columns.length),
    highCardinality: columns.filter(c => c.uniquePct > 90).length,
    dateColumns: columns.filter(c => {
      const type = c.inferredType.toUpperCase();
      return type.includes('DATE') || type.includes('TIMESTAMP') || type.includes('TIME');
    }).length,
    emptyColumns: columns.filter(c => c.nullPct === 100).length
  };

  const typeDistribution = {
    'Integer': columns.filter(c => {
      const type = c.inferredType.toUpperCase();
      return type.includes('INT') || type.includes('LONG') || type.includes('BIGINT') ||
             type.includes('DECIMAL') || type.includes('DOUBLE') || type.includes('FLOAT') ||
             type.includes('NUMBER') || type.includes('NUMERIC');
    }).length,
    'String': columns.filter(c => {
      const type = c.inferredType.toUpperCase();
      return type.includes('STRING') || type.includes('VARCHAR') || type.includes('TEXT') || type.includes('CHAR');
    }).length,
    'Date': columns.filter(c => {
      const type = c.inferredType.toUpperCase();
      return type.includes('DATE') || type.includes('TIMESTAMP') || type.includes('TIME');
    }).length,
    'Other': columns.filter(c => {
      const type = c.inferredType.toUpperCase();
      return !type.includes('INT') && !type.includes('LONG') && !type.includes('BIGINT') &&
             !type.includes('DECIMAL') && !type.includes('DOUBLE') && !type.includes('FLOAT') &&
             !type.includes('NUMBER') && !type.includes('NUMERIC') &&
             !type.includes('STRING') && !type.includes('VARCHAR') && !type.includes('TEXT') && !type.includes('CHAR') &&
             !type.includes('DATE') && !type.includes('TIMESTAMP') && !type.includes('TIME');
    }).length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      {/* Header */}
      <div className="bg-white shadow-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-3 rounded-xl shadow-lg">
                <Database className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Data Profiling Dashboard</h1>
                <p className="text-sm text-slate-600 mt-1">
                  <span className="font-semibold">{profileData.profileName}</span> • {profileData.sourceName} • Last profiled: {profileData.profileDate}
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              {onReProfile && (
                <button 
                  onClick={onReProfile}
                  className="flex items-center gap-2 bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-lg hover:bg-slate-50 transition-colors shadow-sm"
                >
                <RefreshCw className="w-4 h-4" />
                Re-Profile
              </button>
              )}
              <button 
                onClick={onExport}
                className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-colors shadow-md"
              >
                <Download className="w-4 h-4" />
                Export Excel
              </button>
              <button 
                onClick={handleCrossColumnAnalysis}
                disabled={crossColumnLoading}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors shadow-md ${
                  crossColumnLoading 
                    ? 'bg-gray-400 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:from-purple-700 hover:to-purple-800'
                }`}
              >
                {crossColumnLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Network className="w-4 h-4" />
                    Cross-Column Analysis
                  </>
                )}
              </button>
            </div>
          </div>
          
          {/* Cross-Column Analysis Loading Progress */}
          {crossColumnLoading && (
            <div className="mt-6 bg-white rounded-xl shadow-lg p-8 border-2 border-purple-200">
              <div className="flex flex-col items-center">
                <Loader2 className="w-12 h-12 text-purple-600 animate-spin mb-4" />
                <h3 className="text-xl font-bold text-slate-900 mb-2">Running Cross-Column Analysis</h3>
                <p className="text-slate-600 text-center mb-6">
                  {crossColumnProgress || 'Processing your data...'}
                </p>
                <div className="w-full max-w-md">
                  <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                    <div className="bg-gradient-to-r from-purple-500 to-purple-600 h-full rounded-full animate-pulse" style={{ width: '60%' }} />
                  </div>
                </div>
                <p className="text-xs text-slate-500 mt-4 text-center">
                  ⏱️ This may take a few moments depending on data volume and number of columns
                </p>
              </div>
            </div>
          )}
          
          {/* Cross-Column Analysis Section */}
          {showCrossColumn && !crossColumnLoading && crossColumnData && (
            <div className="mt-6 space-y-6">
              {crossColumnData.correlations && crossColumnData.correlations.length > 0 && (
                <CorrelationHeatmap correlations={crossColumnData.correlations} />
              )}
              
              {crossColumnData.compositeKeys && crossColumnData.compositeKeys.length > 0 && (
                <CompositeKeyDetection compositeKeys={crossColumnData.compositeKeys} />
              )}
              
              {/* Conditional Profiling Controls */}
              {crossColumnData.numericFields && crossColumnData.numericFields.length > 0 && 
               crossColumnData.categoricalFields && crossColumnData.categoricalFields.length > 0 && (
                <div className="bg-white p-6 rounded-xl border-2 border-slate-200">
                  <h3 className="text-lg font-bold text-slate-900 mb-4">Conditional Profiling</h3>
                  <div className="flex gap-4 items-end">
                    <div className="flex-1">
                      <label className="text-sm font-semibold text-slate-700 mb-2 block">Numeric Field</label>
                      <select 
                        id="numeric-field-select"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select numeric field...</option>
                        {crossColumnData.numericFields.map((field: string) => (
                          <option key={field} value={field}>{field}</option>
                        ))}
                      </select>
                    </div>
                    <div className="flex-1">
                      <label className="text-sm font-semibold text-slate-700 mb-2 block">Categorical Field</label>
                      <select 
                        id="categorical-field-select"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select categorical field...</option>
                        {crossColumnData.categoricalFields.map((field: string) => (
                          <option key={field} value={field}>{field}</option>
                        ))}
                      </select>
                    </div>
                    <button
                      onClick={() => {
                        const numField = (document.getElementById('numeric-field-select') as HTMLSelectElement)?.value;
                        const catField = (document.getElementById('categorical-field-select') as HTMLSelectElement)?.value;
                        if (numField && catField) {
                          handleConditionalProfiling(numField, catField);
                        }
                      }}
                      disabled={conditionalProfilingLoading}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                        conditionalProfilingLoading 
                          ? 'bg-gray-400 cursor-not-allowed' 
                          : 'bg-blue-600 text-white hover:bg-blue-700'
                      }`}
                    >
                      {conditionalProfilingLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        'Analyze'
                      )}
                    </button>
                  </div>
                </div>
              )}
              
              {/* Conditional Profiling Loading Progress */}
              {conditionalProfilingLoading && (
                <div className="bg-white rounded-xl shadow-lg p-8 border-2 border-orange-200">
                  <div className="flex flex-col items-center">
                    <Loader2 className="w-12 h-12 text-orange-600 animate-spin mb-4" />
                    <h3 className="text-xl font-bold text-slate-900 mb-2">Running Conditional Profiling</h3>
                    <p className="text-slate-600 text-center mb-6">
                      {conditionalProfilingProgress || 'Processing segmented statistics...'}
                    </p>
                    <div className="w-full max-w-md">
                      <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                        <div className="bg-gradient-to-r from-orange-500 to-orange-600 h-full rounded-full animate-pulse" style={{ width: '70%' }} />
                      </div>
                    </div>
                    <p className="text-xs text-slate-500 mt-4 text-center">
                      ⏱️ Calculating statistics for each category...
                    </p>
                  </div>
                </div>
              )}
              
              {/* Conditional Profiling Results */}
              {!conditionalProfilingLoading && crossColumnData.conditionalStats && crossColumnData.conditionalStats.length > 0 && (
                <ConditionalProfiling 
                  stats={crossColumnData.conditionalStats}
                  numericField={crossColumnData.lastConditionalNumeric || ''}
                  categoricalField={crossColumnData.lastConditionalCategorical || ''}
                />
              )}
            </div>
          )}
          
          {/* Snapshot Manager */}
          <div className="mt-6">
            <SnapshotManager 
              profileData={{ columns, totalRows: profileData.totalRows }}
              onCompare={handleSnapshotComparison}
              comparing={comparisonLoading}
            />
          </div>
          
          {/* Profile Comparison Modal */}
          {showComparison && comparisonData && (
            <ProfileComparison 
              comparison={comparisonData}
              onClose={() => setShowComparison(false)}
            />
          )}

          {/* Profile Metadata */}
          <div className="flex gap-6 text-sm bg-slate-50 p-4 rounded-lg border border-slate-200">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-slate-500" />
              <span className="text-slate-600">Source:</span>
              <span className="font-semibold text-slate-900">{profileData.dataSource}</span>
            </div>
            <div className="flex items-center gap-2">
              <Settings className="w-4 h-4 text-slate-500" />
              <span className="text-slate-600">Schema:</span>
              <span className="font-semibold text-slate-900">{profileData.schema}</span>
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-500" />
              <span className="text-slate-600">Filter:</span>
              <span className="font-semibold text-slate-900">{profileData.filterName}</span>
            </div>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-slate-500" />
              <span className="text-slate-600">Sampling:</span>
              <span className="font-semibold text-slate-900">{profileData.samplingPolicy}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow-md p-4 border border-slate-200 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <span className="text-2xl font-bold text-slate-900">{stats.totalColumns}</span>
            </div>
            <p className="text-xs text-slate-600 font-medium">Total Columns</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-4 border border-slate-200 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <Hash className="w-5 h-5 text-purple-600" />
              <span className="text-2xl font-bold text-slate-900">
                {stats.totalRows >= 1000000 
                  ? `${(stats.totalRows / 1000000).toFixed(1)}M`
                  : stats.totalRows >= 1000
                  ? `${(stats.totalRows / 1000).toFixed(1)}K`
                  : stats.totalRows.toLocaleString()}
              </span>
            </div>
            <p className="text-xs text-slate-600 font-medium">Total Rows</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-4 border border-slate-200 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <AlertCircle className="w-5 h-5 text-amber-600" />
              <span className="text-2xl font-bold text-slate-900">{stats.issuesFound}</span>
            </div>
            <p className="text-xs text-slate-600 font-medium">Issues Found</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-4 border border-slate-200 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <span className="text-2xl font-bold text-slate-900">{stats.avgCompleteness}%</span>
            </div>
            <p className="text-xs text-slate-600 font-medium">Completeness</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-4 border border-slate-200 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
              <span className="text-2xl font-bold text-slate-900">{stats.avgQuality}%</span>
            </div>
            <p className="text-xs text-slate-600 font-medium">Quality Score</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-4 border border-slate-200 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <BarChart3 className="w-5 h-5 text-cyan-600" />
              <span className="text-2xl font-bold text-slate-900">{stats.highCardinality}</span>
            </div>
            <p className="text-xs text-slate-600 font-medium">High Cardinality</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-4 border border-slate-200 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <Calendar className="w-5 h-5 text-rose-600" />
              <span className="text-2xl font-bold text-slate-900">{stats.dateColumns}</span>
            </div>
            <p className="text-xs text-slate-600 font-medium">Date Columns</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-4 border border-slate-200 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <span className="text-2xl font-bold text-slate-900">{stats.emptyColumns}</span>
            </div>
            <p className="text-xs text-slate-600 font-medium">Empty Columns</p>
          </div>
        </div>

        {/* Type Distribution Chart */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="lg:col-span-2 bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
              <PieChart className="w-5 h-5 text-blue-600" />
              Data Type Distribution
            </h3>
            <div className="space-y-3">
              {Object.entries(typeDistribution).map(([type, count]) => {
                const percentage = (count / stats.totalColumns * 100).toFixed(1);
                const colors: Record<string, string> = {
                  'Integer': 'bg-blue-500',
                  'String': 'bg-green-500',
                  'Date': 'bg-purple-500',
                  'Other': 'bg-gray-500'
                };
                return (
                  <div key={type}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-slate-700">{type}</span>
                      <span className="text-sm text-slate-600">{count} columns ({percentage}%)</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                      <div 
                        className={`${colors[type]} h-full rounded-full transition-all duration-500`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-600" />
              Quality Overview
            </h3>
            <div className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-semibold text-green-900">Excellent</span>
                </div>
                <p className="text-2xl font-bold text-green-700">
                  {columns.filter(c => getQualityScore(c) >= 95).length}
                </p>
                <p className="text-xs text-green-600 mt-1">95-100% quality</p>
              </div>
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-1">
                  <Info className="w-4 h-4 text-yellow-600" />
                  <span className="text-sm font-semibold text-yellow-900">Good</span>
                </div>
                <p className="text-2xl font-bold text-yellow-700">
                  {columns.filter(c => getQualityScore(c) >= 80 && getQualityScore(c) < 95).length}
                </p>
                <p className="text-xs text-yellow-600 mt-1">80-94% quality</p>
              </div>
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-1">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                  <span className="text-sm font-semibold text-red-900">Needs Attention</span>
                </div>
                <p className="text-2xl font-bold text-red-700">
                  {columns.filter(c => getQualityScore(c) < 80).length}
                </p>
                <p className="text-xs text-red-600 mt-1">Below 80% quality</p>
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-xl shadow-md p-5 mb-6 border border-slate-200">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search columns by name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              {['all', 'issues', 'dates', 'strings', 'numbers'].map(type => (
                <button
                  key={type}
                  onClick={() => setFilterType(type)}
                  className={`px-4 py-2.5 rounded-lg font-medium transition-all ${
                    filterType === type 
                      ? 'bg-blue-600 text-white shadow-md' 
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </button>
              ))}
              
              {/* Column Visibility Control */}
              <div className="relative ml-2">
                <button 
                  onClick={() => setShowColumnSelector(!showColumnSelector)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-lg font-medium transition-all bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300"
                >
                  <Settings className="w-4 h-4" />
                  <span>Columns</span>
                </button>
                
                {showColumnSelector && (
                  <div className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-xl shadow-2xl z-50">
                    <div className="p-4 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white">
                      <h3 className="font-bold text-slate-900 flex items-center gap-2">
                        <Settings className="w-4 h-4" />
                        Manage Column Visibility
                      </h3>
                      <p className="text-xs text-slate-600 mt-1">Show or hide columns in the table below</p>
            </div>
                    <div className="p-2 max-h-96 overflow-y-auto">
                      {Object.entries(columnConfig).map(([key, config]) => {
                        const colConfig = config as { visible: boolean; minWidth: number; width?: number };
                        return (
                          <label key={key} className="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors">
                            <input 
                              type="checkbox" 
                              checked={colConfig.visible}
                              onChange={() => toggleColumnVisibility(key)}
                              className="rounded text-blue-600 w-4 h-4"
                            />
                            <span className="text-sm text-slate-700 font-medium capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                          </label>
                        );
                      })}
                    </div>
                    <div className="p-3 border-t border-slate-200 flex gap-2 bg-slate-50">
                      <button 
                        onClick={() => setColumnConfig(defaultColumns)}
                        className="flex-1 text-sm px-3 py-2 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg font-medium text-slate-700 transition-colors"
                      >
                        Reset to Default
                      </button>
                      <button 
                        onClick={() => setShowColumnSelector(false)}
                        className="flex-1 text-sm px-3 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg font-medium transition-colors"
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Columns Table */}
        <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full" style={{ tableLayout: 'fixed' }}>
              <thead className="bg-gradient-to-r from-slate-100 to-slate-50 border-b-2 border-slate-300">
                <tr>
                  {columnConfig.name.visible && (
                    <th style={{ width: columnConfig.name.width || columnConfig.name.minWidth }} className="px-6 py-4 text-left text-xs font-bold text-slate-700 uppercase tracking-wider relative group">
                      Column Name
                      <div 
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group-hover:bg-blue-300"
                        onMouseDown={(e) => handleResizeStart(e, 'name')}
                      />
                    </th>
                  )}
                  {columnConfig.dataType.visible && (
                    <th style={{ width: columnConfig.dataType.width || columnConfig.dataType.minWidth }} className="px-6 py-4 text-left text-xs font-bold text-slate-700 uppercase tracking-wider relative group">
                      Data Type
                      <div 
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group-hover:bg-blue-300"
                        onMouseDown={(e) => handleResizeStart(e, 'dataType')}
                      />
                    </th>
                  )}
                  {columnConfig.valuePreview.visible && (
                    <th style={{ width: columnConfig.valuePreview.width || columnConfig.valuePreview.minWidth }} className="px-6 py-4 text-left text-xs font-bold text-slate-700 uppercase tracking-wider relative group">
                      Value Preview
                      <div 
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group-hover:bg-blue-300"
                        onMouseDown={(e) => handleResizeStart(e, 'valuePreview')}
                      />
                    </th>
                  )}
                  {columnConfig.statistics.visible && (
                    <th style={{ width: columnConfig.statistics.width || columnConfig.statistics.minWidth }} className="px-6 py-4 text-left text-xs font-bold text-slate-700 uppercase tracking-wider relative group">
                      Statistics
                      <div 
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group-hover:bg-blue-300"
                        onMouseDown={(e) => handleResizeStart(e, 'statistics')}
                      />
                    </th>
                  )}
                  {columnConfig.uniqueValues.visible && (
                    <th style={{ width: columnConfig.uniqueValues.width || columnConfig.uniqueValues.minWidth }} className="px-6 py-4 text-left text-xs font-bold text-slate-700 uppercase tracking-wider relative group">
                      Unique Values
                      <div 
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group-hover:bg-blue-300"
                        onMouseDown={(e) => handleResizeStart(e, 'uniqueValues')}
                      />
                    </th>
                  )}
                  {columnConfig.nulls.visible && (
                    <th style={{ width: columnConfig.nulls.width || columnConfig.nulls.minWidth }} className="px-6 py-4 text-left text-xs font-bold text-slate-700 uppercase tracking-wider relative group">
                      Nulls
                      <div 
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group-hover:bg-blue-300"
                        onMouseDown={(e) => handleResizeStart(e, 'nulls')}
                      />
                    </th>
                  )}
                  {columnConfig.completeness.visible && (
                    <th style={{ width: columnConfig.completeness.width || columnConfig.completeness.minWidth }} className="px-6 py-4 text-left text-xs font-bold text-slate-700 uppercase tracking-wider relative group">
                      Completeness
                      <div 
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group-hover:bg-blue-300"
                        onMouseDown={(e) => handleResizeStart(e, 'completeness')}
                      />
                    </th>
                  )}
                  {columnConfig.quality.visible && (
                    <th style={{ width: columnConfig.quality.width || columnConfig.quality.minWidth }} className="px-6 py-4 text-left text-xs font-bold text-slate-700 uppercase tracking-wider relative group">
                      Quality
                      <div 
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group-hover:bg-blue-300"
                        onMouseDown={(e) => handleResizeStart(e, 'quality')}
                      />
                    </th>
                  )}
                  {columnConfig.actions.visible && (
                    <th style={{ width: columnConfig.actions.width || columnConfig.actions.minWidth }} className="px-6 py-4 text-left text-xs font-bold text-slate-700 uppercase tracking-wider relative group">
                      Actions
                      <div 
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 group-hover:bg-blue-300"
                        onMouseDown={(e) => handleResizeStart(e, 'actions')}
                      />
                    </th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredColumns.map((col, idx) => {
                  const qualityScore = getQualityScore(col);
                  return (
                    <tr key={idx} className="hover:bg-blue-50 transition-colors">
                      {columnConfig.name.visible && (
                      <td style={{ width: columnConfig.name.width || columnConfig.name.minWidth, maxWidth: columnConfig.name.width || columnConfig.name.minWidth, overflow: 'hidden' }} className="px-6 py-4">
                        <div className="flex items-center gap-2 flex-wrap">
                            {getTypeIcon(col.inferredType)}
                          <span className="font-semibold text-slate-900 break-words" style={{ wordBreak: 'break-word', overflowWrap: 'break-word', maxWidth: '100%' }}>{col.name}</span>
                          {col.nullPct > 50 && (
                            <span className="px-2 py-0.5 bg-red-100 text-red-700 text-xs rounded-full font-medium">
                              High Nulls
                            </span>
                          )}
                          {col.nullPct > 0 && col.nullPct <= 50 && (
                            <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded-full font-medium">
                              Has Nulls
                            </span>
                          )}
                          {col.uniquePct > 95 && (
                            <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded-full font-medium">
                              High Cardinality
                            </span>
                          )}
                        </div>
                      </td>
                      )}
                      {columnConfig.dataType.visible && (
                      <td style={{ width: columnConfig.dataType.width || columnConfig.dataType.minWidth }} className="px-6 py-4">
                        <div className="text-sm">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-semibold text-blue-700 break-words">{col.inferredType}</span>
                            <span className="text-xs text-slate-500">({col.inferredPct}%)</span>
                          </div>
                          <div className="text-xs text-slate-500 mt-0.5 break-words">Schema: {col.documentedType}</div>
                        </div>
                      </td>
                      )}
                      {columnConfig.valuePreview.visible && (
                      <td style={{ width: columnConfig.valuePreview.width || columnConfig.valuePreview.minWidth }} className="px-6 py-4">
                          {/* Inline Value Distribution Mini-Chart */}
                          <div className="space-y-1">
                            {col.frequency.top3.slice(0, 3).map((item, i) => {
                              const pct = (item.count / profileData.totalRows * 100);
                              return (
                                <div key={i} className="flex items-center gap-1">
                                  <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                                    <div 
                                      className="bg-gradient-to-r from-purple-400 to-purple-500 h-full rounded-full"
                                      style={{ width: `${Math.min(100, pct * 2)}%` }}
                            />
                          </div>
                                  <span className="text-xs text-slate-600 truncate flex-1" title={String(item.value)}>
                                    {String(item.value).substring(0, 12)}{String(item.value).length > 12 ? '...' : ''}
                                  </span>
                                </div>
                              );
                            })}
                            {col.uniqueValues > 3 && (
                              <div className="text-xs text-slate-400 italic">
                                +{col.uniqueValues - 3} more...
                              </div>
                            )}
                        </div>
                      </td>
                      )}
                      {columnConfig.statistics.visible && (
                      <td style={{ width: columnConfig.statistics.width || columnConfig.statistics.minWidth }} className="px-6 py-4">
                        {/* Statistics Summary - Numeric vs String */}
                        {(() => {
                          const isNumeric = col.inferredType.toUpperCase().includes('LONG') || 
                                          col.inferredType.toUpperCase().includes('INT') ||
                                          col.inferredType.toUpperCase().includes('DECIMAL') ||
                                          col.inferredType.toUpperCase().includes('DOUBLE');
                          const isString = col.inferredType.toUpperCase().includes('STRING');
                          
                          if (isNumeric && (col.minValue || col.maxValue || col.mean)) {
                            return (
                              <div className="text-xs space-y-1">
                                <div className="flex justify-between gap-2">
                                  <span className="text-slate-600">Min:</span>
                                  <span className="font-semibold text-slate-900">{col.minValue || 'N/A'}</span>
                          </div>
                                <div className="flex justify-between gap-2">
                                  <span className="text-slate-600">Max:</span>
                                  <span className="font-semibold text-slate-900">{col.maxValue || 'N/A'}</span>
                        </div>
                                <div className="flex justify-between gap-2">
                                  <span className="text-slate-600">Mean:</span>
                                  <span className="font-semibold text-slate-900">
                                    {col.mean ? Number(col.mean).toFixed(2) : 'N/A'}
                                  </span>
                                </div>
                              </div>
                            );
                          } else if (isString && col.avgLength) {
                            return (
                              <div className="text-xs space-y-1">
                                <div className="flex justify-between gap-2">
                                  <span className="text-slate-600">Avg Length:</span>
                                  <span className="font-semibold text-slate-900">{Number(col.avgLength).toFixed(1)} chars</span>
                                </div>
                                <div className="flex justify-between gap-2">
                                  <span className="text-slate-600">Top Value:</span>
                                  <span className="font-semibold text-slate-900 truncate" title={col.frequency.top3[0]?.value}>
                                    {col.frequency.top3[0]?.value.substring(0, 10)}
                                  </span>
                                </div>
                              </div>
                            );
                          } else {
                            return (
                              <div className="text-xs text-slate-400 italic">
                                No stats
                              </div>
                            );
                          }
                        })()}
                      </td>
                      )}
                      {columnConfig.uniqueValues.visible && (
                        <td style={{ width: columnConfig.uniqueValues.width || columnConfig.uniqueValues.minWidth }} className="px-6 py-4">
                        <div className="text-sm">
                            <span className="font-bold text-slate-900 break-words">{col.uniqueValues.toLocaleString()}</span>
                            <div className="text-xs text-slate-500 mt-0.5 break-words">of {profileData.totalRows.toLocaleString()}</div>
                          </div>
                        </td>
                      )}
                      {columnConfig.nulls.visible && (
                      <td style={{ width: columnConfig.nulls.width || columnConfig.nulls.minWidth }} className="px-6 py-4">
                        <div className="text-sm">
                          <span className={`font-bold break-words ${col.nullPct > 0 ? 'text-red-600' : 'text-green-600'}`}>
                            {col.nulls.toLocaleString()}
                          </span>
                          <div className="text-xs text-slate-500 mt-0.5 break-words">({col.nullPct.toFixed(2)}%)</div>
                        </div>
                      </td>
                      )}
                      {columnConfig.completeness.visible && (
                      <td style={{ width: columnConfig.completeness.width || columnConfig.completeness.minWidth }} className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-slate-200 rounded-full h-2.5 overflow-hidden">
                            <div 
                              className={`h-full rounded-full transition-all duration-500 ${
                                (100 - col.nullPct) >= 99 ? 'bg-gradient-to-r from-green-500 to-green-600' :
                                (100 - col.nullPct) >= 90 ? 'bg-gradient-to-r from-yellow-500 to-yellow-600' :
                                'bg-gradient-to-r from-red-500 to-red-600'
                              }`}
                              style={{ width: `${100 - col.nullPct}%` }}
                            />
                          </div>
                          <span className="text-sm font-semibold text-slate-700 w-14 break-words">{(100 - col.nullPct).toFixed(2)}%</span>
                        </div>
                      </td>
                      )}
                      {columnConfig.quality.visible && (
                      <td style={{ width: columnConfig.quality.width || columnConfig.quality.minWidth }} className="px-6 py-4">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-2xl font-bold break-words ${getQualityColor(qualityScore)}`}>
                            {qualityScore}
                          </span>
                          <div className="text-xs text-slate-500">/100</div>
                        </div>
                      </td>
                      )}
                      {columnConfig.actions.visible && (
                      <td style={{ width: columnConfig.actions.width || columnConfig.actions.minWidth }} className="px-6 py-4">
                        <button
                          onClick={() => setSelectedColumn(col)}
                          className="flex items-center gap-1 text-blue-600 hover:text-blue-800 text-sm font-semibold hover:underline transition-colors flex-wrap"
                        >
                          <Eye className="w-4 h-4" />
                          Details
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          
          {filteredColumns.length === 0 && (
            <div className="text-center py-12">
              <Search className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 font-medium">No columns found matching your filters</p>
            </div>
          )}
        </div>
      </div>

      {/* Detailed Column Modal */}
      {selectedColumn && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50 backdrop-blur-sm" onClick={() => setSelectedColumn(null)}>
          <div className="bg-white rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto shadow-2xl" onClick={(e) => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 p-6 border-b border-blue-500 z-10">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                    <Database className="w-7 h-7" />
                    {selectedColumn.name}
                  </h2>
                  <p className="text-blue-100 text-sm mt-1">Detailed Column Analysis</p>
                </div>
                <button
                  onClick={() => setSelectedColumn(null)}
                  className="text-white hover:bg-white hover:bg-opacity-20 rounded-full p-2 transition-colors"
                >
                  <span className="text-2xl">×</span>
                </button>
              </div>
            </div>
            
            {/* Modal Content */}
            <div className="p-6">
              {/* Tabs */}
              <div className="flex gap-2 mb-6 border-b border-slate-200 overflow-x-auto">
                {[
                  { id: 'overview', label: 'Overview' },
                  { id: 'statistics', label: 'Statistics' },
                  { id: 'visualizations', label: 'Visualizations' },
                  { id: 'ai-insights', label: 'AI Insights' },
                  { id: 'extremes', label: 'Extreme Values' },
                  { id: 'samples', label: 'Samples' },
                  { id: 'patterns', label: 'Patterns' },
                  { id: 'quality', label: 'Quality' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-4 py-2 font-semibold transition-colors whitespace-nowrap ${
                      activeTab === tab.id
                        ? 'text-blue-600 border-b-2 border-blue-600'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Overview Tab */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-5 rounded-xl border border-blue-200">
                      <p className="text-sm text-blue-700 font-semibold mb-2 flex items-center gap-2">
                        <Type className="w-4 h-4" />
                        Inferred Type
                      </p>
                      <p className="text-xl font-bold text-blue-900">{selectedColumn.inferredType}</p>
                      <p className="text-sm text-blue-600 mt-1">{selectedColumn.inferredPct}% confidence</p>
                    </div>
                    <div className="bg-gradient-to-br from-slate-50 to-slate-100 p-5 rounded-xl border border-slate-200">
                      <p className="text-sm text-slate-700 font-semibold mb-2 flex items-center gap-2">
                        <FileText className="w-4 h-4" />
                        Documented Type
                      </p>
                      <p className="text-xl font-bold text-slate-900">{selectedColumn.documentedType}</p>
                      <p className="text-sm text-slate-600 mt-1">Schema definition</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-white p-5 rounded-xl border-2 border-slate-200 shadow-sm">
                      <p className="text-sm text-slate-600 font-semibold mb-2">Unique Values</p>
                      <p className="text-3xl font-bold text-slate-900">{selectedColumn.uniqueValues.toLocaleString()}</p>
                      <p className="text-sm text-slate-500 mt-1">{selectedColumn.uniquePct.toFixed(2)}% unique</p>
                    </div>
                    <div className="bg-white p-5 rounded-xl border-2 border-slate-200 shadow-sm">
                      <p className="text-sm text-slate-600 font-semibold mb-2">Null Values</p>
                      <p className="text-3xl font-bold text-slate-900">{selectedColumn.nulls.toLocaleString()}</p>
                      <p className="text-sm text-slate-500 mt-1">{selectedColumn.nullPct.toFixed(2)}% null</p>
                    </div>
                    <div className="bg-white p-5 rounded-xl border-2 border-slate-200 shadow-sm">
                      <p className="text-sm text-slate-600 font-semibold mb-2">
                        {selectedColumn.inferredType.toUpperCase().includes('STRING') ? 'Length Analysis' : 'Avg Length'}
                      </p>
                      {selectedColumn.inferredType.toUpperCase().includes('STRING') && selectedColumn.minLength !== undefined ? (
                        <div className="space-y-1 mt-2">
                          <div className="flex justify-between text-xs">
                            <span className="text-slate-600">Min:</span>
                            <span className="font-semibold">{Number(selectedColumn.minLength).toFixed(0)}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-slate-600">Median:</span>
                            <span className="font-semibold">{selectedColumn.medianLength ? Number(selectedColumn.medianLength).toFixed(1) : 'N/A'}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-slate-600">Mean:</span>
                            <span className="font-semibold">{Number(selectedColumn.avgLength).toFixed(1)}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-slate-600">Max:</span>
                            <span className="font-semibold">{Number(selectedColumn.maxLength).toFixed(0)}</span>
                          </div>
                          <p className="text-xs text-slate-500 mt-1 italic">characters</p>
                        </div>
                      ) : (
                        <>
                          <p className="text-3xl font-bold text-slate-900">{Number(selectedColumn.avgLength).toFixed(1)}</p>
                      <p className="text-sm text-slate-500 mt-1">characters</p>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-slate-50 to-slate-100 p-6 rounded-xl border border-slate-200">
                    <p className="text-sm text-slate-700 font-bold mb-4 flex items-center gap-2">
                      <BarChart3 className="w-5 h-5" />
                      Value Range
                    </p>
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <p className="text-xs text-slate-500 font-semibold mb-2 uppercase">Minimum Value</p>
                        <div className="bg-white p-4 rounded-lg border border-slate-300">
                          <p className="text-sm font-mono font-bold text-slate-900 break-all">{selectedColumn.minValue || '(Empty)'}</p>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 font-semibold mb-2 uppercase">Maximum Value</p>
                        <div className="bg-white p-4 rounded-lg border border-slate-300">
                          <p className="text-sm font-mono font-bold text-slate-900 break-all">{selectedColumn.maxValue || '(Empty)'}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Statistics Tab */}
              {activeTab === 'statistics' && (
                <div className="space-y-6">
                  <div className="bg-white p-6 rounded-xl border-2 border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-blue-600" />
                      Cardinality Analysis
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-slate-600 mb-1">Total Rows</p>
                        <p className="text-2xl font-bold text-slate-900">{profileData.totalRows.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600 mb-1">Unique Values</p>
                        <p className="text-2xl font-bold text-slate-900">{selectedColumn.uniqueValues.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600 mb-1">Duplicate Rows</p>
                        <p className="text-2xl font-bold text-slate-900">
                          {(profileData.totalRows - selectedColumn.uniqueValues).toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600 mb-1">Uniqueness</p>
                        <p className="text-2xl font-bold text-slate-900">{selectedColumn.uniquePct.toFixed(4)}%</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-xl border-2 border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <Percent className="w-5 h-5 text-green-600" />
                      Completeness Metrics
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm font-semibold text-slate-700">Populated</span>
                          <span className="text-sm font-bold text-green-600">
                            {(profileData.totalRows - selectedColumn.nulls).toLocaleString()} ({(100 - selectedColumn.nullPct).toFixed(4)}%)
                          </span>
                        </div>
                        <div className="w-full bg-slate-200 rounded-full h-4 overflow-hidden">
                          <div 
                            className="bg-gradient-to-r from-green-500 to-green-600 h-full rounded-full"
                            style={{ width: `${100 - selectedColumn.nullPct}%` }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm font-semibold text-slate-700">Null</span>
                          <span className="text-sm font-bold text-red-600">
                            {selectedColumn.nulls.toLocaleString()} ({selectedColumn.nullPct.toFixed(4)}%)
                          </span>
                        </div>
                        <div className="w-full bg-slate-200 rounded-full h-4 overflow-hidden">
                          <div 
                            className="bg-gradient-to-r from-red-500 to-red-600 h-full rounded-full"
                            style={{ width: `${selectedColumn.nullPct}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Numerical Statistics (if available) */}
                  {selectedColumn.mean !== undefined && (
                    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl border-2 border-blue-200">
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <Activity className="w-5 h-5 text-indigo-600" />
                        Statistical Distribution
                      </h3>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                          <p className="text-xs text-slate-600 mb-1">Mean</p>
                          <p className="text-xl font-bold text-slate-900">{selectedColumn.mean?.toFixed(2)}</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                          <p className="text-xs text-slate-600 mb-1">Median</p>
                          <p className="text-xl font-bold text-slate-900">{selectedColumn.median ? Number(selectedColumn.median).toFixed(2) : 'N/A'}</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                          <p className="text-xs text-slate-600 mb-1">Std Dev</p>
                          <p className="text-xl font-bold text-slate-900">{selectedColumn.stddev ? Number(selectedColumn.stddev).toFixed(2) : 'N/A'}</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                          <p className="text-xs text-slate-600 mb-1">25th Percentile</p>
                          <p className="text-xl font-bold text-slate-900">{selectedColumn.p25 ? Number(selectedColumn.p25).toFixed(2) : 'N/A'}</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                          <p className="text-xs text-slate-600 mb-1">75th Percentile</p>
                          <p className="text-xl font-bold text-slate-900">{selectedColumn.p75 ? Number(selectedColumn.p75).toFixed(2) : 'N/A'}</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                          <p className="text-xs text-slate-600 mb-1">95th Percentile</p>
                          <p className="text-xl font-bold text-slate-900">{selectedColumn.p95 ? Number(selectedColumn.p95).toFixed(2) : 'N/A'}</p>
                        </div>
                      </div>
                      <div className="mt-4 bg-white p-4 rounded-lg shadow-sm">
                        <p className="text-sm text-slate-600 mb-2">Value Distribution</p>
                        <div className="flex items-center gap-2 text-xs">
                          <span className="font-mono">Min: {selectedColumn.minValue}</span>
                          <span className="flex-1 border-t border-dashed border-slate-300"></span>
                          <span className="font-mono">Median: {selectedColumn.median ? Number(selectedColumn.median).toFixed(2) : 'N/A'}</span>
                          <span className="flex-1 border-t border-dashed border-slate-300"></span>
                          <span className="font-mono">Max: {selectedColumn.maxValue}</span>
                        </div>
                      </div>
                      {selectedColumn.p99 && (
                        <div className="mt-3 bg-amber-50 border border-amber-200 p-3 rounded-lg">
                          <p className="text-xs text-amber-800 font-semibold">
                            <Info className="w-3 h-3 inline mr-1" />
                            99th Percentile: {Number(selectedColumn.p99).toFixed(2)} - Values above this may be outliers
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Special Values Analysis (for numeric fields) */}
                  {selectedColumn.mean !== undefined && (selectedColumn.zerosCount !== undefined || selectedColumn.negativesCount !== undefined || selectedColumn.infiniteCount !== undefined) && (
                    <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl border-2 border-purple-200">
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <AlertCircle className="w-5 h-5 text-purple-600" />
                        Special Values Analysis
                      </h3>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="bg-white p-5 rounded-lg shadow-sm border-2 border-slate-200">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-2xl">0️⃣</span>
                            <p className="text-sm text-slate-600 font-semibold">Zeros</p>
                          </div>
                          <p className="text-2xl font-bold text-slate-900">{selectedColumn.zerosCount?.toLocaleString() || 0}</p>
                          <p className="text-xs text-slate-500 mt-1">
                            {profileData.totalRows > 0 ? ((selectedColumn.zerosCount || 0) / profileData.totalRows * 100).toFixed(2) : '0.00'}% of total
                          </p>
                        </div>
                        <div className="bg-white p-5 rounded-lg shadow-sm border-2 border-slate-200">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-2xl">➖</span>
                            <p className="text-sm text-slate-600 font-semibold">Negatives</p>
                          </div>
                          <p className="text-2xl font-bold text-slate-900">{selectedColumn.negativesCount?.toLocaleString() || 0}</p>
                          <p className="text-xs text-slate-500 mt-1">
                            {profileData.totalRows > 0 ? ((selectedColumn.negativesCount || 0) / profileData.totalRows * 100).toFixed(2) : '0.00'}% of total
                          </p>
                        </div>
                        <div className="bg-white p-5 rounded-lg shadow-sm border-2 border-slate-200">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-2xl">∞</span>
                            <p className="text-sm text-slate-600 font-semibold">Infinites/NaN</p>
                          </div>
                          <p className="text-2xl font-bold text-slate-900">{selectedColumn.infiniteCount?.toLocaleString() || 0}</p>
                          <p className="text-xs text-slate-500 mt-1">
                            {profileData.totalRows > 0 ? ((selectedColumn.infiniteCount || 0) / profileData.totalRows * 100).toFixed(2) : '0.00'}% of total
                          </p>
                        </div>
                      </div>
                      {((selectedColumn.zerosCount || 0) + (selectedColumn.negativesCount || 0) + (selectedColumn.infiniteCount || 0)) > 0 && (
                        <div className="mt-4 bg-blue-50 border border-blue-200 p-3 rounded-lg">
                          <p className="text-xs text-blue-800">
                            <Info className="w-3 h-3 inline mr-1" />
                            <strong>Data Quality Note:</strong> {((selectedColumn.zerosCount || 0) + (selectedColumn.negativesCount || 0) + (selectedColumn.infiniteCount || 0)).toLocaleString()} special values detected. 
                            Consider if these are valid for your use case.
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Categorical Value Distribution (if available) */}
                  {selectedColumn.isCategorical && selectedColumn.frequency.all && (
                    <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl border-2 border-green-200">
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <PieChart className="w-5 h-5 text-green-600" />
                        Complete Value Distribution (Categorical Field)
                      </h3>
                      <p className="text-sm text-slate-600 mb-4">
                        This field has {selectedColumn.uniqueValues.toLocaleString()} distinct values ({selectedColumn.cardinalityPct?.toFixed(4)}% cardinality)
                      </p>
                      {selectedColumn.frequency.all.length >= 100000 && (
                        <div className="mb-4 bg-amber-50 border border-amber-200 p-3 rounded-lg">
                          <p className="text-xs text-amber-800 font-semibold">
                            <Info className="w-3 h-3 inline mr-1" />
                            Showing top 100,000 most frequent values. This field has very high cardinality.
                          </p>
                        </div>
                      )}
                      <div className="space-y-2 max-h-80 overflow-y-auto">
                        {selectedColumn.frequency.all.map((item, idx) => (
                          <div key={idx} className="bg-white p-3 rounded-lg flex items-center justify-between hover:shadow-md transition-shadow">
                            <span className="font-mono text-sm font-semibold text-slate-900">{item.value}</span>
                            <div className="flex items-center gap-3">
                              <span className="text-xs text-slate-600">
                                {item.count.toLocaleString()} ({(item.percentage || 0).toFixed(2)}%)
                              </span>
                              <div className="w-24 bg-slate-200 rounded-full h-2">
                                <div 
                                  className="bg-gradient-to-r from-green-500 to-green-600 h-full rounded-full"
                                  style={{ width: `${Math.min(item.percentage || 0, 100)}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Value Distribution Chart */}
                  <div className="bg-white p-6 rounded-xl border-2 border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-purple-600" />
                      Value Distribution
                      {selectedColumn.isCategorical && selectedColumn.allValues && (
                        <span className="text-sm font-normal text-slate-600">
                          ({selectedColumn.allValues.length} distinct values)
                        </span>
                      )}
                    </h3>
                    
                    {/* Chart Visualization - Smart orientation based on data type */}
                    {(() => {
                      // Get chart data from available sources
                      const chartData = (selectedColumn.allValues && selectedColumn.allValues.length > 0) 
                        ? selectedColumn.allValues 
                        : (selectedColumn.topValues && selectedColumn.topValues.length > 0)
                        ? selectedColumn.topValues
                        : selectedColumn.frequency.top3 || [];
                      
                      // Check if this is a numeric field by looking at the type
                      const isNumericField = selectedColumn.inferredType.toUpperCase().includes('LONG') || 
                                            selectedColumn.inferredType.toUpperCase().includes('INT') ||
                                            selectedColumn.inferredType.toUpperCase().includes('DECIMAL') ||
                                            selectedColumn.inferredType.toUpperCase().includes('DOUBLE') ||
                                            selectedColumn.inferredType.toUpperCase().includes('FLOAT');
                      
                      // For numeric fields, sort by value (ascending) and use vertical bars
                      // For categorical fields, sort by frequency (descending) and use horizontal bars
                      let displayData;
                      if (isNumericField) {
                        displayData = chartData
                          .map(item => ({
                            name: String(item.value),
                            numericValue: parseFloat(String(item.value)) || 0,
                            count: item.count,
                            percentage: item.frequency_pct || (item.count / profileData.totalRows * 100)
                          }))
                          .sort((a, b) => a.numericValue - b.numericValue)
                          .slice(0, 25); // Show up to 25 values for numeric
                      } else {
                        displayData = chartData
                          .map(item => ({
                            name: String(item.value),
                            count: item.count,
                            percentage: item.frequency_pct || (item.count / profileData.totalRows * 100)
                          }))
                          .sort((a, b) => b.count - a.count)
                          .slice(0, 20); // Show top 20 for categorical
                      }

                      console.log('Chart data:', { 
                        allValues: selectedColumn.allValues?.length,
                        topValues: selectedColumn.topValues?.length,
                        top3: selectedColumn.frequency.top3?.length,
                        displayData: displayData.length,
                        isNumericField
                      });

                      if (displayData.length === 0) {
                        return (
                          <div className="mb-6 p-8 bg-slate-50 rounded-lg border-2 border-dashed border-slate-300 text-center">
                            <p className="text-slate-500">No value distribution data available</p>
                          </div>
                        );
                      }

                      // Numeric fields: Vertical bar chart (histogram-style)
                      if (isNumericField) {
                        return (
                          <div className="mb-6">
                            <div className="mb-2 text-sm text-slate-600 italic">
                              Histogram showing frequency distribution across numeric values
                            </div>
                            <ResponsiveContainer width="100%" height={400}>
                              <BarChart
                                data={displayData}
                                margin={{ top: 5, right: 30, left: 50, bottom: 60 }}
                              >
                                <CartesianGrid strokeDasharray="3 3" vertical={false} horizontal={true} />
                                <XAxis 
                                  dataKey="name" 
                                  angle={-45}
                                  textAnchor="end"
                                  height={80}
                                  tick={{ fontSize: 11 }}
                                  label={{ value: 'Value', position: 'insideBottom', offset: -50 }}
                                />
                                <YAxis 
                                  label={{ value: 'Frequency', angle: -90, position: 'insideLeft' }}
                                />
                                <Tooltip 
                                  formatter={(value: number | undefined) => {
                                    if (!value) return ['0', 'Frequency'];
                                    return [value.toLocaleString(), 'Frequency'];
                                  }}
                                  labelFormatter={(label) => `Value: ${label}`}
                                  contentStyle={{ backgroundColor: 'white', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                                />
                                <Bar dataKey="count" fill="#8b5cf6" radius={[4, 4, 0, 0]}>
                                  {displayData.map((_item, index) => (
                                    <Cell key={`cell-${index}`} fill={`hsl(${250 - index * 3}, 70%, ${50 + index}%)`} />
                                  ))}
                                </Bar>
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        );
                      }

                      // Categorical fields: Horizontal bar chart
                      return (
                        <div className="mb-6">
                          <div className="mb-2 text-sm text-slate-600 italic">
                            Top {displayData.length} most frequent values
                          </div>
                          <ResponsiveContainer width="100%" height={Math.max(300, Math.min(600, displayData.length * 30))}>
                            <BarChart
                              data={displayData}
                              layout="vertical"
                              margin={{ top: 5, right: 30, left: 100, bottom: 5 }}
                            >
                          <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                          <XAxis type="number" label={{ value: 'Frequency', position: 'insideBottom', offset: -5 }} />
                          <YAxis 
                            dataKey="name" 
                            type="category" 
                            width={90}
                            tick={{ fontSize: 12 }}
                          />
                          <Tooltip 
                            formatter={(value: number | undefined, name: string | undefined) => {
                              if (!value) return ['0', name || ''];
                              if (name === 'count') {
                                return [value.toLocaleString(), 'Count'];
                              }
                              return [value, name || ''];
                            }}
                            labelFormatter={(label) => `Value: ${label}`}
                            contentStyle={{ backgroundColor: 'white', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                          />
                          <Bar dataKey="count" fill="#8b5cf6" radius={[0, 4, 4, 0]}>
                            {displayData.map((_item, index) => (
                              <Cell key={`cell-${index}`} fill={`hsl(${250 - index * 5}, 70%, ${50 + index * 2}%)`} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  );
                })()}

                    {/* Top Values Summary */}
                    <h4 className="text-md font-semibold text-slate-700 mb-3">
                      Top {selectedColumn.isCategorical ? 'Values' : 'Frequent Values'}
                    </h4>
                    <div className="space-y-3">
                      {selectedColumn.frequency.top3.map((item, idx) => {
                        const percentage = (item.count / profileData.totalRows * 100).toFixed(2);
                        return (
                          <div key={idx} className="bg-slate-50 p-4 rounded-lg">
                            <div className="flex justify-between items-center mb-2">
                              <span className="font-mono font-semibold text-slate-900">{item.value}</span>
                              <span className="text-sm text-slate-600">
                                {item.count.toLocaleString()} ({percentage}%)
                              </span>
                            </div>
                            <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                              <div 
                                className="bg-gradient-to-r from-purple-500 to-purple-600 h-full rounded-full"
                                style={{ width: `${Math.min(100, parseFloat(percentage))}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Visualizations Tab */}
              {activeTab === 'visualizations' && (
                <div className="space-y-6">
                  {/* Box Plot for Numeric Columns */}
                  {selectedColumn.mean !== undefined && selectedColumn.minValue && selectedColumn.maxValue && (
                    <BoxPlot
                      data={{
                        min: Number(selectedColumn.minValue),
                        q25: selectedColumn.p25 || Number(selectedColumn.minValue),
                        median: selectedColumn.median || selectedColumn.mean,
                        q75: selectedColumn.p75 || Number(selectedColumn.maxValue),
                        max: Number(selectedColumn.maxValue),
                        mean: selectedColumn.mean,
                        outliers: selectedColumn.largestValues 
                          ? selectedColumn.largestValues.map(v => Number(v)).filter(v => !isNaN(v)) 
                          : []
                      }}
                      columnName={selectedColumn.name}
                    />
                  )}

                  {/* Word Cloud for Text Columns */}
                  {selectedColumn.inferredType.toUpperCase().includes('STRING') && 
                   selectedColumn.allValues && selectedColumn.allValues.length > 0 && (
                    <WordCloudVisualization
                      values={selectedColumn.allValues}
                      columnName={selectedColumn.name}
                    />
                  )}

                  {/* Time Series for Temporal Columns */}
                  {(selectedColumn.inferredType.toUpperCase().includes('DATE') || 
                    selectedColumn.inferredType.toUpperCase().includes('TIMESTAMP')) &&
                   selectedColumn.allValues && selectedColumn.allValues.length > 0 && (() => {
                    // Use the column's own catalog/schema/table properties (these come from ColumnProfile interface)
                    const catalog = selectedColumn.catalog;
                    const schema = selectedColumn.schema;
                    const table = selectedColumn.table;
                    // Extract just the column name (without catalog/schema/table prefix if present)
                    const columnName = selectedColumn.name.includes('.') 
                      ? selectedColumn.name.split('.').pop() || selectedColumn.name
                      : selectedColumn.name;
                    
                    // Verify we have all required information
                    if (!catalog || !schema || !table) {
                      console.warn('Missing catalog/schema/table for temporal analysis:', {
                        columnName: selectedColumn.name,
                        catalog: catalog || 'missing',
                        schema: schema || 'missing',
                        table: table || 'missing'
                      });
                      return (
                        <div className="bg-yellow-50 p-6 rounded-xl border border-yellow-200 text-center">
                          <Calendar className="w-12 h-12 mx-auto text-yellow-600 mb-3" />
                          <p className="text-yellow-800 font-semibold">Temporal Analysis Unavailable</p>
                          <p className="text-sm text-yellow-700 mt-2">
                            Unable to determine table source for temporal pattern analysis.
                          </p>
                        </div>
                      );
                    }
                    
                    return (
                      <TimeSeriesChart
                        data={selectedColumn.allValues.map(v => ({
                          date: String(v.value),
                          count: v.count
                        }))}
                        columnName={columnName}
                        catalog={catalog}
                        schema={schema}
                        table={table}
                      />
                    );
                  })()}

                  {/* Fallback message if no visualizations available */}
                  {!(
                    (selectedColumn.mean !== undefined && selectedColumn.minValue && selectedColumn.maxValue) ||
                    (selectedColumn.inferredType.toUpperCase().includes('STRING') && selectedColumn.allValues && selectedColumn.allValues.length > 0) ||
                    ((selectedColumn.inferredType.toUpperCase().includes('DATE') || selectedColumn.inferredType.toUpperCase().includes('TIMESTAMP')) && selectedColumn.allValues && selectedColumn.allValues.length > 0)
                  ) && (
                    <div className="bg-slate-50 p-12 rounded-xl border border-slate-200 text-center">
                      <BarChart3 className="w-16 h-16 mx-auto text-slate-400 mb-4" />
                      <h3 className="text-lg font-semibold text-slate-700 mb-2">
                        No Advanced Visualizations Available
                      </h3>
                      <p className="text-slate-600 max-w-md mx-auto">
                        Advanced visualizations are available for numeric, text, and temporal columns with sufficient data.
                      </p>
                      <div className="mt-4 text-sm text-slate-500">
                        <p>✓ Box plots for numeric columns</p>
                        <p>✓ Word clouds for short text values</p>
                        <p>✓ Time series for date/timestamp columns</p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* AI Insights Tab */}
              {activeTab === 'ai-insights' && (
                <div>
                  <AIInsights columnData={{ 
                    ...selectedColumn, 
                    totalRows: profileData.totalRows,
                    quality: getQualityScore(selectedColumn),
                    completeness: 100 - selectedColumn.nullPct
                  }} />
                </div>
              )}

              {/* Extreme Values Tab */}
              {activeTab === 'extremes' && (
                <div className="space-y-6">
                  {selectedColumn.mean !== undefined && (selectedColumn.smallestValues || selectedColumn.largestValues) ? (
                    <>
                      {/* Smallest Values */}
                      {selectedColumn.smallestValues && selectedColumn.smallestValues.length > 0 && (
                        <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl border-2 border-green-200">
                          <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                            <TrendingDown className="w-5 h-5 text-green-600" />
                            Smallest Values (Bottom 5)
                          </h3>
                          <div className="space-y-3">
                            {selectedColumn.smallestValues.map((value, idx) => (
                              <div key={idx} className="bg-white p-4 rounded-lg shadow-sm border-2 border-slate-200 flex items-center justify-between">
                                <span className="text-sm text-slate-600 font-semibold">#{idx + 1}</span>
                                <span className="text-2xl font-bold text-slate-900 font-mono">{value}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Largest Values */}
                      {selectedColumn.largestValues && selectedColumn.largestValues.length > 0 && (
                        <div className="bg-gradient-to-br from-red-50 to-rose-50 p-6 rounded-xl border-2 border-red-200">
                          <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-red-600" />
                            Largest Values (Top 5)
                          </h3>
                          <div className="space-y-3">
                            {selectedColumn.largestValues.map((value, idx) => (
                              <div key={idx} className="bg-white p-4 rounded-lg shadow-sm border-2 border-slate-200 flex items-center justify-between">
                                <span className="text-sm text-slate-600 font-semibold">#{idx + 1}</span>
                                <span className="text-2xl font-bold text-slate-900 font-mono">{value}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Outliers Alert (if p99 exists) */}
                      {selectedColumn.p99 && selectedColumn.largestValues && selectedColumn.largestValues.some(v => v > (selectedColumn.p99 || 0)) && (
                        <div className="bg-amber-50 border-2 border-amber-200 p-4 rounded-xl">
                          <h3 className="text-sm font-bold text-amber-900 mb-2 flex items-center gap-2">
                            <AlertCircle className="w-4 h-4" />
                            Potential Outliers Detected
                          </h3>
                          <p className="text-xs text-amber-800">
                            Some of the largest values exceed the 99th percentile ({Number(selectedColumn.p99).toFixed(2)}).
                            These may be outliers that could impact your analysis.
                          </p>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="bg-slate-50 border-2 border-slate-200 p-8 rounded-xl text-center">
                      <p className="text-slate-600">
                        <Info className="w-6 h-6 inline mr-2" />
                        Extreme values analysis is only available for numeric fields.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Samples Tab */}
              {activeTab === 'samples' && (
                <div className="space-y-6">
                  {/* First Samples */}
                  {selectedColumn.firstSamples && selectedColumn.firstSamples.length > 0 && (
                    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl border-2 border-blue-200">
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <FileText className="w-5 h-5 text-blue-600" />
                        First 10 Values (As They Appear in Table)
                      </h3>
                      <div className="space-y-2">
                        {selectedColumn.firstSamples.map((value, idx) => (
                          <div key={idx} className="bg-white p-3 rounded-lg shadow-sm border border-slate-200 flex items-center gap-3">
                            <span className="text-xs text-slate-500 font-semibold w-8">#{idx + 1}</span>
                            <span className="text-sm text-slate-900 font-mono flex-1 break-all">{value}</span>
                          </div>
                        ))}
                      </div>
                      <p className="text-xs text-slate-600 mt-3 italic">
                        <Info className="w-3 h-3 inline mr-1" />
                        These are the first 10 non-null values as they appear in the table (original order).
                      </p>
                    </div>
                  )}

                  {/* Random Samples */}
                  {selectedColumn.randomSamples && selectedColumn.randomSamples.length > 0 && (
                    <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl border-2 border-purple-200">
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <Shuffle className="w-5 h-5 text-purple-600" />
                        Random Sample (10 Values)
                      </h3>
                      <div className="space-y-2">
                        {selectedColumn.randomSamples.map((value, idx) => (
                          <div key={idx} className="bg-white p-3 rounded-lg shadow-sm border border-slate-200 flex items-center gap-3">
                            <span className="text-xs text-slate-500 font-semibold w-8">#{idx + 1}</span>
                            <span className="text-sm text-slate-900 font-mono flex-1 break-all">{value}</span>
                          </div>
                        ))}
                      </div>
                      <p className="text-xs text-slate-600 mt-3 italic">
                        <Info className="w-3 h-3 inline mr-1" />
                        These are 10 randomly selected non-null values, giving you a representative sample of the data distribution.
                      </p>
                    </div>
                  )}

                  {(!selectedColumn.firstSamples && !selectedColumn.randomSamples) && (
                    <div className="bg-slate-50 border-2 border-slate-200 p-8 rounded-xl text-center">
                      <p className="text-slate-600">
                        <Info className="w-6 h-6 inline mr-2" />
                        No sample values available for this column.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Patterns Tab */}
              {activeTab === 'patterns' && (
                <div className="space-y-6">
                  <div className="bg-white p-6 rounded-xl border-2 border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <Activity className="w-5 h-5 text-blue-600" />
                      Detected Patterns
                      {selectedColumn.patterns && selectedColumn.patterns.length > 0 && (
                        <span className="text-sm font-normal text-slate-600">
                          ({selectedColumn.patterns.length} patterns)
                        </span>
                      )}
                    </h3>
                    <div className="space-y-3">
                      {selectedColumn.patterns && selectedColumn.patterns.length > 0 ? (
                        selectedColumn.patterns.map((pattern, idx) => {
                          // Pattern explanations
                          const patternExplanations: Record<string, string> = {
                            'MIXED': 'Contains mixed alphanumeric characters (letters + numbers + symbols)',
                            'ALPHA_ONLY': 'Contains only alphabetic characters (letters)',
                            'NUMERIC_STRING': 'Numbers stored as text (e.g., "123")',
                            'ALPHANUMERIC': 'Mix of letters and numbers',
                            'EMAIL_PATTERN': 'Email address format detected',
                            'URL_PATTERN': 'URL/web address format detected',
                            'DATE_PATTERN': 'Date format detected in string',
                            'EMPTY': 'Empty/blank values present',
                            'NULL': 'NULL values present'
                          };
                          
                          return (
                        <div key={idx} className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                              <div className="flex items-start gap-3">
                          <code className="text-lg font-mono font-bold text-blue-900">{pattern}</code>
                                {patternExplanations[pattern] && (
                                  <span className="text-sm text-blue-700 italic flex-1">
                                    — {patternExplanations[pattern]}
                                  </span>
                                )}
                        </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="p-8 bg-slate-50 rounded-lg border-2 border-dashed border-slate-300 text-center">
                          <Activity className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                          <p className="text-slate-600 font-medium">No patterns detected</p>
                          <p className="text-sm text-slate-500 mt-1">
                            {selectedColumn.inferredType.toUpperCase().includes('STRING') 
                              ? 'String values may not follow a consistent pattern'
                              : 'Pattern analysis is only available for string fields'}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                    <h3 className="text-lg font-bold text-purple-900 mb-2 flex items-center gap-2">
                      <Info className="w-5 h-5" />
                      Pattern Legend
                    </h3>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center gap-2">
                        <code className="bg-white px-2 py-1 rounded font-mono font-bold text-purple-900">#</code>
                        <span className="text-purple-800">Numeric digit</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <code className="bg-white px-2 py-1 rounded font-mono font-bold text-purple-900">A</code>
                        <span className="text-purple-800">Alphabetic character</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <code className="bg-white px-2 py-1 rounded font-mono font-bold text-purple-900">_</code>
                        <span className="text-purple-800">Underscore/separator</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <code className="bg-white px-2 py-1 rounded font-mono font-bold text-purple-900">/:-</code>
                        <span className="text-purple-800">Special characters</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Quality Tab */}
              {activeTab === 'quality' && (
                <div className="space-y-6">
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border-2 border-blue-200">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-bold text-blue-900 flex items-center gap-2">
                        <CheckCircle className="w-6 h-6" />
                        Overall Quality Score
                      </h3>
                      <div className="text-right">
                        <p className={`text-5xl font-bold ${getQualityColor(getQualityScore(selectedColumn))}`}>
                          {getQualityScore(selectedColumn)}
                        </p>
                        <p className="text-sm text-blue-700 font-semibold">/100</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-xl border-2 border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-4">Quality Factors</h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="font-semibold text-slate-700">Completeness</span>
                          <span className={`font-bold ${(100 - selectedColumn.nullPct) >= 99 ? 'text-green-600' : (100 - selectedColumn.nullPct) >= 90 ? 'text-yellow-600' : 'text-red-600'}`}>
                            {(100 - selectedColumn.nullPct).toFixed(2)}%
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="flex-1 bg-slate-200 rounded-full h-3 overflow-hidden">
                            <div 
                              className={`h-full rounded-full ${(100 - selectedColumn.nullPct) >= 99 ? 'bg-green-500' : (100 - selectedColumn.nullPct) >= 90 ? 'bg-yellow-500' : 'bg-red-500'}`}
                              style={{ width: `${100 - selectedColumn.nullPct}%` }}
                            />
                          </div>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          {selectedColumn.nullPct === 0 ? 'No null values detected' : `${selectedColumn.nulls.toLocaleString()} null values found`}
                        </p>
                      </div>

                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="font-semibold text-slate-700">Type Consistency</span>
                          <span className="font-bold text-green-600">{selectedColumn.inferredPct}%</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="flex-1 bg-slate-200 rounded-full h-3 overflow-hidden">
                            <div 
                              className="bg-green-500 h-full rounded-full"
                              style={{ width: `${selectedColumn.inferredPct}%` }}
                            />
                          </div>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">Values match the inferred type</p>
                      </div>

                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="font-semibold text-slate-700">Schema Alignment</span>
                          <span className={`font-bold ${selectedColumn.inferredType === selectedColumn.documentedType ? 'text-green-600' : 'text-amber-600'}`}>
                            {selectedColumn.inferredType === selectedColumn.documentedType ? 'Aligned' : 'Mismatch'}
                          </span>
                        </div>
                        {selectedColumn.inferredType !== selectedColumn.documentedType && (
                          <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg">
                            <p className="text-sm text-amber-800">
                              <strong>Inferred:</strong> {selectedColumn.inferredType}<br/>
                              <strong>Documented:</strong> {selectedColumn.documentedType}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-5">
                    <div className="flex gap-3">
                      <Info className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-bold text-blue-900 mb-2">Quality Assessment</p>
                        <p className="text-sm text-blue-800 leading-relaxed">
                          {getQualityScore(selectedColumn) >= 95 && 
                            "This column has excellent quality with minimal issues. It meets all quality standards."}
                          {getQualityScore(selectedColumn) >= 80 && getQualityScore(selectedColumn) < 95 && 
                            "This column has good quality but has some areas for improvement. Review the completeness and type consistency metrics."}
                          {getQualityScore(selectedColumn) < 80 && 
                            "This column needs attention. Significant data quality issues detected that may impact analytics and reporting."}
                          {selectedColumn.nullPct > 0 && ` Contains ${selectedColumn.nullPct.toFixed(2)}% null values.`}
                          {selectedColumn.uniquePct < 50 && selectedColumn.uniqueValues > 10 && 
                            ` Low uniqueness (${selectedColumn.uniquePct.toFixed(2)}%) suggests this may be an enumerated or categorical field.`}
                          {selectedColumn.uniquePct > 95 && 
                            ` High cardinality (${selectedColumn.uniquePct.toFixed(2)}%) indicates this may be a unique identifier or highly variable field.`}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DataProfilingDashboard;