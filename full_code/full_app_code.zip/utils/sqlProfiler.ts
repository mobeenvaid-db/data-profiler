/**
 * SQL Profiler Utilities
 * Generates optimized SQL queries for data profiling in Databricks
 */

export interface FieldSelection {
  catalog: string;
  schema: string;
  table: string;
  field: string;
  dataType: string;
}

export interface ProfilingQuery {
  fieldKey: string;
  query: string;
  description: string;
}

/**
 * Generates optimized profiling queries for selected fields
 * Uses window functions and CTEs for performance
 */
export function generateProfilingQueries(selections: FieldSelection[]): ProfilingQuery[] {
  const queries: ProfilingQuery[] = [];

  // Group fields by table for efficiency
  const fieldsByTable = new Map<string, FieldSelection[]>();
  selections.forEach(sel => {
    const tableKey = `${sel.catalog}.${sel.schema}.${sel.table}`;
    if (!fieldsByTable.has(tableKey)) {
      fieldsByTable.set(tableKey, []);
    }
    fieldsByTable.get(tableKey)!.push(sel);
  });

  // Generate queries for each table
  fieldsByTable.forEach((fields, tableKey) => {
    const [catalog, schema, table] = tableKey.split('.');
    
    fields.forEach(field => {
      const fieldKey = `${tableKey}.${field.field}`;
      const query = generateSingleFieldProfilingQuery(catalog, schema, table, field.field, field.dataType);
      
      queries.push({
        fieldKey,
        query,
        description: `Profiling ${field.field} from ${tableKey}`
      });
    });
  });

  return queries;
}

/**
 * Generates a comprehensive profiling query for a single field
 * Optimized for Databricks SQL with parallel execution
 * 
 * PROFILING STRATEGY:
 * 
 * 1. CATEGORICAL fields (low cardinality < 1% or < 100 distinct values):
 *    - Get ALL distinct values with frequencies and percentages
 *    - Focus on value distribution, nulls, invalid values
 *    - Examples: gender (M/F), status (Active/Inactive), category, state
 * 
 * 2. NUMERICAL MEASURES (int, bigint, decimal, float, double):
 *    - Statistical distribution: mean, median, std dev
 *    - Percentiles: p25, p50, p75, p95, p99 for outlier detection
 *    - Range: min, max
 *    - Top frequent values for mode detection
 *    - Examples: age, price, quantity, score, revenue
 * 
 * 3. MEDIUM-CARDINALITY fields (hundreds to thousands of distinct values):
 *    - ALL distinct values captured (up to 100,000)
 *    - Complete value distribution for profiling
 *    - Examples: product_codes, postal_codes, SKUs
 * 
 * 4. HIGH-CARDINALITY/ID fields (> 1% distinct, thousands to millions):
 *    - Top 100,000 most frequent values
 *    - Focus on uniqueness and completeness
 *    - Examples: customer_id, email, phone, transaction_id
 * 
 * 5. DATE/TIMESTAMP fields:
 *    - Min/max date range
 *    - All distinct dates (for date distributions)
 *    - Pattern analysis (if stored as string)
 * 
 * VALUE CAPTURE LIMIT: 100,000 distinct values maximum
 * - Covers complete profiling for most real-world columns
 * - For extreme cardinality (millions), captures top 100k most frequent
 */
function generateSingleFieldProfilingQuery(
  catalog: string,
  schema: string,
  table: string,
  field: string,
  dataType: string
): string {
  const fullTableName = `${catalog}.${schema}.${table}`;
  const isNumeric = ['bigint', 'int', 'integer', 'smallint', 'tinyint', 'long', 'decimal', 'double', 'float'].some(t => 
    dataType.toLowerCase().includes(t)
  );
  const isDate = ['date', 'timestamp'].some(t => dataType.toLowerCase().includes(t));
  const isString = dataType.toLowerCase().includes('string') || dataType.toLowerCase().includes('varchar');

  return `
WITH base_stats AS (
  SELECT
    COUNT(*) as total_rows,
    COUNT(${field}) as non_null_count,
    COUNT(*) - COUNT(${field}) as null_count,
    COUNT(DISTINCT ${field}) as unique_count,
    ROUND((COUNT(DISTINCT ${field}) * 100.0) / NULLIF(COUNT(*), 0), 2) as cardinality_pct
    ${isString ? `
    , AVG(LENGTH(CAST(${field} AS STRING))) as avg_length
    , MIN(LENGTH(CAST(${field} AS STRING))) as min_length
    , MAX(LENGTH(CAST(${field} AS STRING))) as max_length
    , PERCENTILE(LENGTH(CAST(${field} AS STRING)), 0.50) as median_length
    ` : ''}
    ${isNumeric ? `
    , MIN(${field}) as min_value
    , MAX(${field}) as max_value
    , AVG(${field}) as mean_value
    , STDDEV(${field}) as stddev_value
    , PERCENTILE(${field}, 0.25) as p25_value
    , PERCENTILE(${field}, 0.50) as median_value
    , PERCENTILE(${field}, 0.75) as p75_value
    , PERCENTILE(${field}, 0.95) as p95_value
    , PERCENTILE(${field}, 0.99) as p99_value
    , SUM(CASE WHEN ${field} = 0 THEN 1 ELSE 0 END) as zeros_count
    , SUM(CASE WHEN ${field} < 0 THEN 1 ELSE 0 END) as negatives_count
    , SUM(CASE WHEN ${field} IS NOT NULL AND (${field} = DOUBLE('Infinity') OR ${field} = DOUBLE('-Infinity') OR ${field} != ${field}) THEN 1 ELSE 0 END) as infinite_count
    ` : ''}
    ${isDate ? `, MIN(${field}) as min_date, MAX(${field}) as max_date` : ''}
  FROM ${fullTableName}
),
value_frequencies AS (
  -- Get ALL distinct values with their frequencies
  -- No artificial limit - capture complete value distribution for profiling
  -- Ordered by frequency to prioritize most common values in case of very high cardinality
  SELECT
    ${field} as field_value,
    COUNT(*) as frequency,
    ROUND((COUNT(*) * 100.0) / (SELECT non_null_count FROM base_stats), 4) as frequency_pct,
    ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) as rank
  FROM ${fullTableName}
  WHERE ${field} IS NOT NULL
  GROUP BY ${field}
  ORDER BY frequency DESC
  LIMIT 100000
),
categorical_stats AS (
  -- Determine if field is likely categorical (useful for UI display)
  SELECT
    CASE 
      WHEN (SELECT cardinality_pct FROM base_stats) < 1 THEN true
      WHEN (SELECT unique_count FROM base_stats) < 100 THEN true
      ELSE false
    END as is_categorical,
    (SELECT COUNT(*) FROM value_frequencies) as captured_values_count
),
${isString ? `
pattern_analysis AS (
  SELECT
    CAST(${field} AS STRING) as field_str,
    CASE
      WHEN ${field} IS NULL THEN 'NULL'
      WHEN CAST(${field} AS STRING) = '' THEN 'EMPTY'
      WHEN REGEXP_LIKE(CAST(${field} AS STRING), '^[0-9]+$') THEN 'NUMERIC_STRING'
      WHEN REGEXP_LIKE(CAST(${field} AS STRING), '^[A-Za-z]+$') THEN 'ALPHA_ONLY'
      WHEN REGEXP_LIKE(CAST(${field} AS STRING), '^[A-Za-z0-9]+$') THEN 'ALPHANUMERIC'
      WHEN REGEXP_LIKE(CAST(${field} AS STRING), '^[0-9]{4}-[0-9]{2}-[0-9]{2}') THEN 'DATE_PATTERN'
      WHEN REGEXP_LIKE(CAST(${field} AS STRING), '.+@.+\\..+') THEN 'EMAIL_PATTERN'
      ELSE 'MIXED'
    END as pattern_type,
    LENGTH(CAST(${field} AS STRING)) as value_length
  FROM ${fullTableName}
  WHERE ${field} IS NOT NULL
  LIMIT 10000
),
pattern_summary AS (
  SELECT
    pattern_type,
    COUNT(*) as pattern_count,
    AVG(value_length) as avg_pattern_length,
    MIN(value_length) as min_pattern_length,
    MAX(value_length) as max_pattern_length
  FROM pattern_analysis
  GROUP BY pattern_type
  ORDER BY pattern_count DESC
),
` : ''}
type_inference AS (
  SELECT
    CASE
      ${isString ? `
      WHEN REGEXP_LIKE(${field}, '^-?[0-9]+$') THEN 'INTEGER'
      WHEN REGEXP_LIKE(${field}, '^-?[0-9]+\\.[0-9]+$') THEN 'DECIMAL'
      WHEN REGEXP_LIKE(${field}, '^[0-9]{4}-[0-9]{2}-[0-9]{2}') THEN 'DATE'
      WHEN REGEXP_LIKE(${field}, '(?i)^(true|false)$') THEN 'BOOLEAN'
      WHEN ${field} IS NULL THEN 'NULL'
      ELSE 'STRING'
      ` : `
      WHEN ${field} IS NULL THEN 'NULL'
      ELSE '${dataType.toUpperCase()}'
      `}
    END as inferred_type,
    COUNT(*) as type_count
  FROM ${fullTableName}
  WHERE ${field} IS NOT NULL
  GROUP BY 1
  ORDER BY type_count DESC
  LIMIT 1
),
extreme_values AS (
  -- Capture smallest and largest values for numeric fields
  ${isNumeric ? `
  SELECT 
    'smallest' as value_type,
    ${field} as value,
    ROW_NUMBER() OVER (ORDER BY ${field} ASC) as rn
  FROM ${fullTableName}
  WHERE ${field} IS NOT NULL
  QUALIFY rn <= 5
  UNION ALL
  SELECT 
    'largest' as value_type,
    ${field} as value,
    ROW_NUMBER() OVER (ORDER BY ${field} DESC) as rn
  FROM ${fullTableName}
  WHERE ${field} IS NOT NULL
  QUALIFY rn <= 5
  ` : `SELECT NULL as value_type, NULL as value, NULL as rn WHERE 1=0`}
),
sample_values AS (
  -- Capture first 10 and random 10 sample values
  SELECT 
    ${field} as sample_value,
    'first' as sample_type,
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) as sample_rn
  FROM ${fullTableName}
  WHERE ${field} IS NOT NULL
  QUALIFY sample_rn <= 10
  UNION ALL
  SELECT 
    ${field} as sample_value,
    'random' as sample_type,
    ROW_NUMBER() OVER (ORDER BY RAND()) as sample_rn
  FROM ${fullTableName}
  WHERE ${field} IS NOT NULL
  QUALIFY sample_rn <= 10
)
SELECT
  '${catalog}' as catalog_name,
  '${schema}' as schema_name,
  '${table}' as table_name,
  '${field}' as column_name,
  '${dataType}' as documented_type,
  bs.total_rows,
  bs.non_null_count,
  bs.null_count,
  ROUND((bs.null_count * 100.0) / NULLIF(bs.total_rows, 0), 4) as null_percentage,
  bs.unique_count,
  bs.cardinality_pct,
  ROUND((bs.unique_count * 100.0) / NULLIF(bs.total_rows, 0), 4) as unique_percentage,
  ROUND(((bs.non_null_count - bs.unique_count) * 100.0) / NULLIF(bs.non_null_count, 0), 4) as duplicate_percentage,
  cs.is_categorical,
  cs.captured_values_count
  ${isString ? `
  , bs.avg_length
  , bs.min_length
  , bs.max_length
  , bs.median_length
  ` : ''}
  ${isNumeric ? `
  , bs.min_value
  , bs.max_value
  , bs.mean_value
  , bs.stddev_value
  , bs.median_value
  , bs.p25_value
  , bs.p75_value
  , bs.p95_value
  , bs.p99_value
  , bs.zeros_count
  , bs.negatives_count
  , bs.infinite_count
  ` : ''}
  ${isDate ? `, bs.min_date, bs.max_date` : ''}
  ,ti.inferred_type,
  ROUND((ti.type_count * 100.0) / NULLIF(bs.non_null_count, 0), 2) as type_confidence_pct,
  (SELECT COLLECT_LIST(STRUCT(field_value, frequency, frequency_pct)) FROM value_frequencies WHERE rank <= 20) as top_values,
  (SELECT COLLECT_LIST(STRUCT(field_value, frequency, frequency_pct)) FROM value_frequencies) as all_values
  ${isString ? `, (SELECT COLLECT_LIST(STRUCT(pattern_type, pattern_count, avg_pattern_length)) FROM pattern_summary) as patterns` : ', CAST(NULL AS ARRAY<STRUCT<pattern_type: STRING, pattern_count: BIGINT, avg_pattern_length: DOUBLE>>) as patterns'}
  ${isNumeric ? `, 
    (SELECT COLLECT_LIST(STRUCT(value, rn)) FROM extreme_values WHERE value_type = 'smallest') as smallest_values,
    (SELECT COLLECT_LIST(STRUCT(value, rn)) FROM extreme_values WHERE value_type = 'largest') as largest_values
  ` : ', CAST(NULL AS ARRAY<STRUCT<value: DOUBLE, rn: BIGINT>>) as smallest_values, CAST(NULL AS ARRAY<STRUCT<value: DOUBLE, rn: BIGINT>>) as largest_values'}
  , (SELECT COLLECT_LIST(STRUCT(sample_value, sample_rn)) FROM sample_values WHERE sample_type = 'first') as first_samples
  , (SELECT COLLECT_LIST(STRUCT(sample_value, sample_rn)) FROM sample_values WHERE sample_type = 'random') as random_samples
FROM base_stats bs
CROSS JOIN type_inference ti
CROSS JOIN categorical_stats cs
`;
}

/**
 * Generates a bulk profiling query for multiple fields in the same table
 * More efficient when profiling many fields from one table
 */
export function generateBulkTableProfilingQuery(
  catalog: string,
  schema: string,
  table: string,
  fields: { name: string; type: string }[]
): string {
  const fullTableName = `${catalog}.${schema}.${table}`;
  
  const fieldStats = fields.map(field => {
    const isString = field.type.toLowerCase().includes('string') || field.type.toLowerCase().includes('varchar');
    
    return `
    -- Stats for ${field.name}
    COUNT(${field.name}) as ${field.name}_non_null,
    COUNT(*) - COUNT(${field.name}) as ${field.name}_null,
    COUNT(DISTINCT ${field.name}) as ${field.name}_unique
    ${isString ? `, AVG(LENGTH(CAST(${field.name} AS STRING))) as ${field.name}_avg_len` : ''}
    `;
  }).join(',');

  return `
WITH base_stats AS (
  SELECT
    COUNT(*) as total_rows,
    ${fieldStats}
  FROM ${fullTableName}
)
SELECT
  '${catalog}' as catalog_name,
  '${schema}' as schema_name,
  '${table}' as table_name,
  total_rows,
  ${fields.map(f => `
  STRUCT(
    '${f.name}' as column_name,
    '${f.type}' as documented_type,
    ${f.name}_non_null as non_null_count,
    ${f.name}_null as null_count,
    ${f.name}_unique as unique_count,
    ROUND((${f.name}_null * 100.0) / NULLIF(total_rows, 0), 4) as null_pct,
    ROUND((${f.name}_unique * 100.0) / NULLIF(total_rows, 0), 4) as unique_pct
    ${f.type.toLowerCase().includes('string') ? `, ${f.name}_avg_len as avg_length` : ''}
  ) as ${f.name}_stats`).join(',\n  ')}
FROM base_stats
`;
}

/**
 * Generates an optimized query that profiles ALL fields in a table at once
 * Best for full table profiling
 */
export function generateFullTableProfilingQuery(
  catalog: string,
  schema: string,
  table: string
): string {
  return `
-- Full table profiling query
-- This query will be dynamically generated based on table schema
SELECT
  '${catalog}' as catalog_name,
  '${schema}' as schema_name,
  '${table}' as table_name,
  column_name,
  data_type,
  COUNT(*) as total_rows,
  COUNT(column_value) as non_null_count,
  COUNT(*) - COUNT(column_value) as null_count,
  COUNT(DISTINCT column_value) as unique_count,
  ROUND((COUNT(*) - COUNT(column_value)) * 100.0 / COUNT(*), 4) as null_pct,
  ROUND(COUNT(DISTINCT column_value) * 100.0 / COUNT(*), 4) as unique_pct
FROM ${catalog}.${schema}.${table}
LATERAL VIEW EXPLODE(
  ARRAY(${/* This would be dynamically built from DESCRIBE TABLE */''})
) t AS column_name, column_value
GROUP BY column_name, data_type
`;
}

/**
 * Generates query to get table schema information
 */
export function generateSchemaQuery(catalog: string, schema: string, table: string): string {
  return `DESCRIBE TABLE ${catalog}.${schema}.${table}`;
}

/**
 * Generates query to list all catalogs
 */
export function generateListCatalogsQuery(): string {
  return `SHOW CATALOGS`;
}

/**
 * Generates query to list schemas in a catalog
 */
export function generateListSchemasQuery(catalog: string): string {
  return `SHOW SCHEMAS IN ${catalog}`;
}

/**
 * Generates query to list tables in a schema
 */
export function generateListTablesQuery(catalog: string, schema: string): string {
  return `SHOW TABLES IN ${catalog}.${schema}`;
}

/**
 * Calculates a quality score based on profiling metrics
 */
export function calculateQualityScore(metrics: {
  nullPct: number;
  uniquePct: number;
  uniqueCount: number;
  typeConsistency: number;
  schemaMatch: boolean;
}): number {
  let score = 100;
  
  // Completeness penalty (up to -40 points)
  if (metrics.nullPct > 0) {
    score -= Math.min(metrics.nullPct * 0.4, 40);
  }
  
  // Low uniqueness penalty for high cardinality expectations (up to -15 points)
  if (metrics.uniquePct < 1 && metrics.uniqueCount > 10) {
    score -= Math.min((100 - metrics.uniquePct) * 0.15, 15);
  }
  
  // Type consistency penalty (up to -25 points)
  if (metrics.typeConsistency < 100) {
    score -= Math.min((100 - metrics.typeConsistency) * 0.25, 25);
  }
  
  // Schema mismatch penalty (-20 points)
  if (!metrics.schemaMatch) {
    score -= 20;
  }
  
  return Math.max(0, Math.round(score));
}

/**
 * Infers data type from sample values and patterns
 */
/**
 * Normalize data type names for consistent comparison
 * Converts database types to display-friendly format
 */
function normalizeDataType(type: string): string {
  const normalized = type.toUpperCase();
  
  // Map SQL types to display types
  const typeMap: Record<string, string> = {
    'STRING': 'STRING',
    'VARCHAR': 'STRING',
    'TEXT': 'STRING',
    'LONG': 'LONG',
    'BIGINT': 'LONG',
    'INT': 'INT',
    'INTEGER': 'INT',
    'SMALLINT': 'INT',
    'TINYINT': 'INT',
    'DECIMAL': 'DECIMAL',
    'DOUBLE': 'DOUBLE',
    'FLOAT': 'FLOAT',
    'DATE': 'DATE',
    'TIMESTAMP': 'TIMESTAMP',
    'DATETIME': 'TIMESTAMP',
    'BOOLEAN': 'BOOLEAN',
    'BOOL': 'BOOLEAN'
  };
  
  return typeMap[normalized] || normalized;
}

export function inferDataType(
  documentedType: string,
  patterns: { pattern_type: string; pattern_count: number }[]
): { inferredType: string; confidence: number } {
  // Normalize the documented type first
  const normalizedDocType = normalizeDataType(documentedType);
  
  if (!patterns || patterns.length === 0) {
    return { inferredType: normalizedDocType, confidence: 100 };
  }

  const topPattern = patterns[0];
  const totalSamples = patterns.reduce((sum, p) => sum + p.pattern_count, 0);
  const confidence = Math.round((topPattern.pattern_count / totalSamples) * 100);

  const typeMapping: Record<string, string> = {
    'NUMERIC_STRING': 'INT',
    'ALPHA_ONLY': 'STRING',
    'ALPHANUMERIC': 'STRING',
    'MIXED': 'STRING',
    'DATE_PATTERN': 'DATE',
    'EMAIL_PATTERN': 'STRING',
    'URL_PATTERN': 'STRING',
    'NULL': 'NULL',
    'EMPTY': 'STRING'
  };

  return {
    inferredType: typeMapping[topPattern.pattern_type] || normalizedDocType,
    confidence
  };
}

/**
 * Formats pattern for display
 */
export function formatPattern(value: string): string {
  if (!value) return 'Empty';
  
  return value
    .split('')
    .map(char => {
      if (/[0-9]/.test(char)) return '#';
      if (/[A-Z]/.test(char)) return 'A';
      if (/[a-z]/.test(char)) return 'a';
      return char;
    })
    .join('');
}

