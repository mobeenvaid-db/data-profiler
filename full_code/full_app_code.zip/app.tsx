import React, { useState } from 'react';
import DataSelector, { SelectedFields } from './components/DataSelector';
import DataProfilingDashboard from './data_profiling_ui';
import { executeProfilingQueries, downloadMultiSheetExport, exportToExcel, type ProfileResult, type ProgressUpdate } from './services/profilingService';
import { Loader2, AlertCircle, ArrowLeft, CheckCircle } from 'lucide-react';

type AppState = 'selection' | 'profiling' | 'results';

const DataProfilerApp: React.FC = () => {
  const [appState, setAppState] = useState<AppState>('selection');
  const [selectedFields, setSelectedFields] = useState<SelectedFields[]>([]);
  const [profileResult, setProfileResult] = useState<ProfileResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [progress, setProgress] = useState<ProgressUpdate | null>(null);

  const handleSelectionChange = (selection: SelectedFields[]) => {
    setSelectedFields(selection);
  };

  const handleStartProfiling = async () => {
    if (selectedFields.length === 0) {
      setError('Please select at least one field to profile');
      return;
    }

    setIsLoading(true);
    setError('');
    setProgress(null);
    setAppState('profiling');

    try {
      // Execute profiling queries with progress callback
      const result = await executeProfilingQueries(selectedFields, (progressUpdate) => {
        setProgress(progressUpdate);
      });
      setProfileResult(result);
      setAppState('results');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred during profiling');
      setAppState('selection');
    } finally {
      setIsLoading(false);
      setProgress(null);
    }
  };

  const handleBackToSelection = () => {
    setAppState('selection');
    setError('');
  };

  const handleExport = async () => {
    if (profileResult) {
      try {
        await exportToExcel(profileResult);
      } catch (error) {
        console.error('Failed to export to Excel:', error);
        // Fallback to CSV if Excel export fails
        downloadMultiSheetExport(profileResult);
      }
    }
  };

  const handleReProfile = async () => {
    await handleStartProfiling();
  };

  if (appState === 'selection') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-slate-900 mb-2">
              Databricks Data Profiler
            </h1>
            <p className="text-lg text-slate-600">
              Comprehensive data quality analysis and profiling for your Databricks tables
            </p>
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <p className="text-red-800 font-medium">{error}</p>
            </div>
          )}

          <DataSelector
            onSelectionChange={handleSelectionChange}
            onProfile={handleStartProfiling}
            isLoading={isLoading}
          />

          {selectedFields.length > 0 && (
            <div className="mt-6 bg-white rounded-xl shadow-md border border-slate-200 p-6">
              <h3 className="text-lg font-bold text-slate-900 mb-4">Selected Fields Summary</h3>
              <div className="space-y-3">
                {selectedFields.map((sel, idx) => (
                  <div key={idx} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                    <div className="font-semibold text-slate-900 mb-2">
                      {sel.catalog}.{sel.schema}.{sel.table}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {sel.fields.map(field => (
                        <span
                          key={field.name}
                          className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
                        >
                          {field.name} <span className="text-blue-600 text-xs">({field.type})</span>
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (appState === 'profiling') {
    const totalFields = selectedFields.reduce((sum, sel) => sum + sel.fields.length, 0);
    const percentage = progress?.percentage || 0;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-2xl p-10 max-w-2xl w-full">
          <div className="flex flex-col items-center">
            <Loader2 className="w-16 h-16 text-blue-600 animate-spin mb-6" />
            <h2 className="text-2xl font-bold text-slate-900 mb-3">Profiling Data...</h2>
            
            {progress ? (
              <>
                <div className="w-full mb-6">
                  <div className="flex justify-between items-center mb-2">
                    <p className="text-sm font-medium text-slate-700">
                      Processing: <span className="font-bold text-blue-600">{progress.fieldKey}</span>
                    </p>
                    <p className="text-sm font-bold text-slate-900">
                      {progress.current} / {progress.total}
                    </p>
                  </div>
                  
                  <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-blue-600 h-full rounded-full transition-all duration-300 ease-out"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  
                  <div className="flex justify-between items-center mt-2">
                    <p className="text-xs text-slate-500">{progress.description}</p>
                    <p className="text-xs font-semibold text-blue-600">{percentage.toFixed(1)}%</p>
                  </div>
                </div>

                <div className="w-full bg-slate-50 rounded-lg p-4 border border-slate-200">
                  <h3 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Completed Fields ({progress.current - 1})
                  </h3>
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {Array.from({ length: progress.current - 1 }, (_, i) => (
                      <div key={i} className="text-xs text-slate-600 flex items-center gap-2">
                        <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />
                        <span>Field {i + 1}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <>
                <p className="text-slate-600 text-center mb-6">
                  Analyzing {totalFields} fields across {selectedFields.length} table(s)
                </p>
                <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                  <div className="bg-blue-600 h-full rounded-full animate-pulse" style={{ width: '30%' }} />
                </div>
              </>
            )}
            
            <p className="text-xs text-slate-500 mt-6 text-center">
              ⏱️ Processing {totalFields} SQL queries sequentially<br/>
              This may take a few moments depending on data volume...
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (appState === 'results' && profileResult) {
    return (
      <div>
        <div className="bg-white border-b border-slate-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <button
              onClick={handleBackToSelection}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-800 font-semibold transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Selection
            </button>
          </div>
        </div>
        <DataProfilingDashboard
          profileData={{
            profileName: profileResult.profileName,
            filterName: profileResult.filterName,
            samplingPolicy: profileResult.samplingPolicy,
            sourceName: profileResult.sourceName,
            totalRows: profileResult.totalRows,
            profileDate: profileResult.profileDate,
            dataSource: profileResult.dataSource,
            schema: profileResult.schema
          }}
          columns={profileResult.columns}
          onExport={handleExport}
          onReProfile={handleReProfile}
        />
      </div>
    );
  }

  return null;
};

export default DataProfilerApp;

