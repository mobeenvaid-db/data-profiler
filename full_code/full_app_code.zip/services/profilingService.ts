/**
 * Data Profiling Service
 * Handles execution of profiling queries and data transformation
 */

import {
  generateProfilingQueries,
  calculateQualityScore,
  inferDataType,
  formatPattern,
  type FieldSelection
} from '../utils/sqlProfiler';

export interface ColumnProfile {
  name: string;
  uniqueValues: number;
  uniquePct: number;
  nulls: number;
  nullPct: number;
  inferredType: string;
  inferredPct: number;
  documentedType: string;
  minValue: string;
  maxValue: string;
  avgLength: number;
  // String-specific length analysis (ydata-profiling style)
  minLength?: number;
  maxLength?: number;
  medianLength?: number;
  patterns: string[];
  frequency: {
    top3: Array<{ value: string; count: number; percentage?: number }>;
    all?: Array<{ value: string; count: number; percentage?: number }>; // For categorical fields
  };
  catalog: string;
  schema: string;
  table: string;
  // Categorical field indicators
  isCategorical?: boolean;
  cardinalityPct?: number;
  // Numerical statistics
  mean?: number;
  median?: number;
  stddev?: number;
  p25?: number;
  p75?: number;
  p95?: number;
  p99?: number;
  // Special value counts for numeric fields
  zerosCount?: number;
  negativesCount?: number;
  infiniteCount?: number;
  // Extreme values (Phase 3)
  smallestValues?: number[];
  largestValues?: number[];
  // Sample values (Phase 3)
  firstSamples?: string[];
  randomSamples?: string[];
  // Value arrays for charts (flattened from frequency for easier access)
  allValues?: Array<{ value: string; count: number; frequency_pct?: number }>;
  topValues?: Array<{ value: string; count: number; frequency_pct?: number }>;
  isNumeric?: boolean;
  isDate?: boolean;
  isString?: boolean;
}

export interface ProfileResult {
  profileName: string;
  filterName: string;
  samplingPolicy: string;
  sourceName: string;
  totalRows: number;
  profileDate: string;
  dataSource: string;
  schema: string;
  columns: ColumnProfile[];
}

/**
 * Execute profiling on selected fields
 * In production, this would connect to Databricks SQL
 */
export interface ProgressUpdate {
  current: number;
  total: number;
  fieldKey: string;
  description: string;
  percentage: number;
}

export async function executeProfilingQueries(
  selections: { catalog: string; schema: string; table: string; fields: Array<{name: string; type: string}> }[],
  onProgress?: (progress: ProgressUpdate) => void
): Promise<ProfileResult> {
  // Flatten selections into FieldSelection array
  const fieldSelections: FieldSelection[] = [];
  
  for (const sel of selections) {
    for (const fieldInfo of sel.fields) {
      fieldSelections.push({
        catalog: sel.catalog,
        schema: sel.schema,
        table: sel.table,
        field: fieldInfo.name,
        dataType: fieldInfo.type
      });
    }
  }

  // Generate queries
  const queries = generateProfilingQueries(fieldSelections);

  // Execute queries with streaming progress if callback provided
  const results = onProgress 
    ? await executeDatabricksQueriesStreaming(queries, onProgress)
    : await executeDatabricksQueries(queries);
  
  // Transform results into profile format
  const columns = transformQueryResults(results, fieldSelections);

  // Build dataSource as fully qualified table name(s)
  const dataSourceValue = selections.length === 1
    ? `${selections[0].catalog}.${selections[0].schema}.${selections[0].table}`
    : selections.map(s => `${s.catalog}.${s.schema}.${s.table}`).join(', ');
  
  return {
    profileName: `Profile_${selections[0]?.table || 'Multi_Table'}`,
    filterName: 'ALL',
    samplingPolicy: 'Full Scan',
    sourceName: selections.map(s => `${s.catalog}.${s.schema}.${s.table}`).join(', '),
    // Get actual total_rows from first query result (all columns have same row count)
    totalRows: columns.length > 0 && results[0]?.total_rows ? results[0].total_rows : 0,
    profileDate: new Date().toISOString().split('T')[0],
    dataSource: dataSourceValue,
    schema: selections[0]?.schema || 'default',
    columns
  };
}

/**
 * Execute queries against Databricks SQL
 * Uses Databricks Apps /api prefix pattern
 */
async function executeDatabricksQueries(queries: any[]): Promise<any[]> {
  try {
    // Databricks Apps pattern: all API calls use /api prefix
    const response = await fetch('/api/databricks/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ queries })
    });
    
    if (!response.ok) {
      console.warn('API not available, using mock data');
      return generateMockResults(queries);
    }
    
    const data = await response.json();
    return data.results.map((r: any) => r.data);
  } catch (error) {
    console.error('Error executing queries, using mock data:', error);
    // Fallback to mock results for development
    return generateMockResults(queries);
  }
}

/**
 * Execute queries with streaming progress updates
 * Uses Server-Sent Events to receive real-time progress
 */
async function executeDatabricksQueriesStreaming(
  queries: any[],
  onProgress: (progress: ProgressUpdate) => void
): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const results: any[] = [];
    
    fetch('/api/databricks/execute-stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ queries })
    }).then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      if (!response.body) {
        throw new Error('No response body');
      }
      
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      
      function processStream() {
        reader.read().then(({ done, value }) => {
          if (done) {
            return;
          }
          
          buffer += decoder.decode(value, { stream: true });
          
          // Process complete messages (ending with \n\n)
          const messages = buffer.split('\n\n');
          buffer = messages.pop() || ''; // Keep incomplete message in buffer
          
          for (const message of messages) {
            if (!message.trim()) continue;
            
            // SSE format: "data: {json}\n"
            const dataMatch = message.match(/^data: (.+)$/m);
            if (dataMatch) {
              try {
                const event = JSON.parse(dataMatch[1]);
                
                if (event.type === 'progress') {
                  // Send progress update to callback
                  onProgress({
                    current: event.current,
                    total: event.total,
                    fieldKey: event.fieldKey,
                    description: event.description,
                    percentage: event.percentage
                  });
                } else if (event.type === 'result') {
                  // Collect result
                  results.push(event.result.data);
                } else if (event.type === 'complete') {
                  // All done
                  resolve(results);
                  return;
                } else if (event.type === 'error') {
                  reject(new Error(event.error));
                  return;
                }
              } catch (e) {
                console.error('Error parsing SSE message:', e, message);
              }
            }
          }
          
          // Continue reading
          processStream();
        }).catch(error => {
          console.error('Stream reading error:', error);
          reject(error);
        });
      }
      
      processStream();
    }).catch(error => {
      console.error('Error starting stream:', error);
      reject(error);
    });
  });
}

/**
 * Transform query results into ColumnProfile objects
 * Maps enhanced SQL profiling data (categorical, numerical, patterns) to UI format
 */
function transformQueryResults(results: any[], selections: FieldSelection[]): ColumnProfile[] {
  return results.map((result, idx) => {
    const selection = selections[idx];
    
    // Extract patterns - always return an array
    const patterns = result.patterns?.map((p: any) => p.pattern_type).filter((p: string) => p) || 
                    (result.sample_value ? [formatPattern(result.sample_value)] : []);
    
    // Extract top 3 values with percentages
    // Extract top values (keep all for charts, will slice later for top3)
    const topValues = result.top_values?.map((v: any) => ({
      value: String(v.field_value || v.value || ''),
      count: v.frequency || v.count || 0,
      percentage: v.frequency_pct || 0
    })) || [];
    
    // Extract ALL values for categorical fields
    const allValues = result.all_values?.map((v: any) => ({
      value: String(v.field_value || v.value || ''),
      count: v.frequency || v.count || 0,
      percentage: v.frequency_pct || 0
    })) || [];
    
    // Debug logging
    console.log(`Backend data for ${result.column_name}:`, {
      top_values_count: result.top_values?.length || 0,
      all_values_count: result.all_values?.length || 0,
      topValues_transformed: topValues.length,
      allValues_transformed: allValues.length,
      is_categorical: result.is_categorical
    });
    
    // Infer type
    const { inferredType, confidence } = inferDataType(
      result.documented_type || selection.dataType,
      result.patterns || []
    );

    // Build base profile
    const profile: ColumnProfile = {
      name: result.column_name || selection.field,
      uniqueValues: result.unique_count || 0,
      uniquePct: result.unique_percentage || 0,
      cardinalityPct: result.cardinality_pct || 0,
      nulls: result.null_count || 0,
      nullPct: result.null_percentage || 0,
      inferredType: inferredType,
      inferredPct: confidence,
      documentedType: result.documented_type || selection.dataType,
      minValue: String(result.min_value || result.min_date || ''),
      maxValue: String(result.max_value || result.max_date || ''),
      avgLength: result.avg_length || 0,
      minLength: result.min_length,
      maxLength: result.max_length,
      medianLength: result.median_length,
      patterns: Array.isArray(patterns) ? patterns.filter((p: string) => p && p !== 'NULL') : [],
      frequency: {
        top3: Array.isArray(topValues) && topValues.length > 0 ? topValues.slice(0, 3) : [],
        all: allValues.length > 0 ? allValues : undefined
      },
      catalog: result.catalog_name || selection.catalog,
      schema: result.schema_name || selection.schema,
      table: result.table_name || selection.table,
      isCategorical: result.is_categorical || false,
      // Add top-level arrays for UI chart consumption
      allValues: allValues.length > 0 ? allValues.map((v: any) => ({
        value: v.value,
        count: v.count,
        frequency_pct: v.percentage
      })) : undefined,
      topValues: topValues.length > 0 ? topValues.map((v: any) => ({
        value: v.value,
        count: v.count,
        frequency_pct: v.percentage
      })) : undefined
    };

    // Add numerical statistics if present
    if (result.mean_value !== undefined) {
      profile.mean = result.mean_value;
      profile.median = result.median_value;
      profile.stddev = result.stddev_value;
      profile.p25 = result.p25_value;
      profile.p75 = result.p75_value;
      profile.p95 = result.p95_value;
      profile.p99 = result.p99_value;
      profile.zerosCount = result.zeros_count;
      profile.negativesCount = result.negatives_count;
      profile.infiniteCount = result.infinite_count;
    }

    // Add extreme values if present
    if (result.smallest_values) {
      profile.smallestValues = result.smallest_values;
    }
    if (result.largest_values) {
      profile.largestValues = result.largest_values;
    }

    // Add sample values if present
    if (result.first_samples) {
      profile.firstSamples = result.first_samples;
    }
    if (result.random_samples) {
      profile.randomSamples = result.random_samples;
    }

    // Debug logging for numeric fields
    console.log(`Stats for ${result.column_name} (${result.documented_type}):`, {
      min_value: result.min_value,
      max_value: result.max_value,
      mean_value: result.mean_value,
      minValue: profile.minValue,
      maxValue: profile.maxValue,
      mean: profile.mean
    });

    return profile;
  });
}

/**
 * Generate mock results for development
 * Simulates realistic profiling data for categorical, numerical, and high-cardinality fields
 */
function generateMockResults(queries: any[]): any[] {
  return queries.map((query, idx) => {
    const fieldName = query.fieldKey.split('.').pop() || `field_${idx}`;
    const lowerName = fieldName.toLowerCase();
    
    // Detect field type from name
    const isDate = lowerName.includes('date') || lowerName.includes('dt') || lowerName.includes('time');
    const isId = lowerName.includes('id') || lowerName.includes('key') || lowerName.includes('sk');
    const isCategorical = lowerName.includes('status') || lowerName.includes('type') || 
                         lowerName.includes('category') || lowerName.includes('gender') ||
                         lowerName.includes('state') || lowerName.includes('code');
    const isNumeric = lowerName.includes('amount') || lowerName.includes('price') || 
                     lowerName.includes('quantity') || lowerName.includes('age') ||
                     lowerName.includes('score') || lowerName.includes('count');
    
    const totalRows = 30678394;
    
    // Determine cardinality based on field type
    let uniqueCount;
    let cardinalityPct;
    if (isCategorical) {
      uniqueCount = Math.floor(Math.random() * 10) + 2; // 2-12 values
      cardinalityPct = (uniqueCount / totalRows) * 100;
    } else if (isId) {
      uniqueCount = Math.floor(totalRows * 0.95); // High cardinality
      cardinalityPct = 95;
    } else if (isNumeric) {
      uniqueCount = Math.floor(totalRows * 0.3); // Medium cardinality
      cardinalityPct = 30;
    } else if (isDate) {
      uniqueCount = Math.floor(Math.random() * 50000) + 1000;
      cardinalityPct = (uniqueCount / totalRows) * 100;
    } else {
      uniqueCount = Math.floor(Math.random() * 100) + 1;
      cardinalityPct = (uniqueCount / totalRows) * 100;
    }
    
    const nullCount = Math.random() < 0.3 ? Math.floor(Math.random() * totalRows * 0.1) : 0;
    const nonNullCount = totalRows - nullCount;
    
    // Generate mock data based on type
    const mockData: any = {
      column_name: fieldName,
      documented_type: isDate ? 'timestamp' : isNumeric || isId ? 'bigint' : 'string',
      total_rows: totalRows,
      non_null_count: nonNullCount,
      null_count: nullCount,
      null_percentage: (nullCount / totalRows) * 100,
      unique_count: uniqueCount,
      cardinality_pct: cardinalityPct,
      unique_percentage: (uniqueCount / totalRows) * 100,
      duplicate_percentage: ((nonNullCount - uniqueCount) / nonNullCount) * 100,
      is_categorical: isCategorical || cardinalityPct < 1,
      captured_values_count: isCategorical ? uniqueCount : 20,
      inferred_type: isDate ? 'Date Time' : isNumeric || isId ? 'Integer' : 'String',
      type_confidence_pct: 99.5
    };

    // Add numerical statistics for numeric fields
    if (isNumeric) {
      mockData.mean_value = 1250.50;
      mockData.median_value = 980.00;
      mockData.stddev_value = 445.75;
      mockData.min_value = 10;
      mockData.max_value = 9999;
      mockData.p25_value = 550.00;
      mockData.p75_value = 1800.00;
      mockData.p95_value = 3500.00;
      mockData.p99_value = 5200.00;
    } else if (isId) {
      mockData.min_value = '10000001';
      mockData.max_value = '99999999';
      mockData.avg_length = 8;
    } else if (isDate) {
      mockData.min_date = '2020-01-01';
      mockData.max_date = '2024-12-31';
    } else {
      mockData.avg_length = Math.floor(Math.random() * 30) + 5;
      mockData.min_value = 'A';
      mockData.max_value = 'Z';
    }

    // Generate top values with percentages
    if (isCategorical) {
      mockData.top_values = [
        { field_value: 'Active', frequency: Math.floor(nonNullCount * 0.65), frequency_pct: 65.0 },
        { field_value: 'Inactive', frequency: Math.floor(nonNullCount * 0.30), frequency_pct: 30.0 },
        { field_value: 'Pending', frequency: Math.floor(nonNullCount * 0.05), frequency_pct: 5.0 }
      ];
      // For categorical, provide ALL values
      mockData.all_values = mockData.top_values;
    } else if (isId) {
      mockData.top_values = [
        { field_value: 'Unique', frequency: 1, frequency_pct: 0.0 }
      ];
    } else {
      mockData.top_values = [
        { field_value: 'Value 1', frequency: Math.floor(nonNullCount * 0.3), frequency_pct: 30.0 },
        { field_value: 'Value 2', frequency: Math.floor(nonNullCount * 0.2), frequency_pct: 20.0 },
        { field_value: 'Value 3', frequency: Math.floor(nonNullCount * 0.1), frequency_pct: 10.0 }
      ];
    }

    // Add patterns for string fields
    if (!isNumeric && !isId) {
      mockData.patterns = isDate ?
        [{ pattern_type: 'DATE_PATTERN', pattern_count: 1000, avg_pattern_length: 19 }] :
        isCategorical ?
        [{ pattern_type: 'ALPHA_ONLY', pattern_count: 1000, avg_pattern_length: 10 }] :
        [{ pattern_type: 'ALPHA_ONLY', pattern_count: 800, avg_pattern_length: 12 }, 
         { pattern_type: 'MIXED', pattern_count: 200, avg_pattern_length: 15 }];
    } else if (isId) {
      mockData.patterns = [{ pattern_type: 'NUMERIC_STRING', pattern_count: 1000, avg_pattern_length: 8 }];
    }

    return mockData;
  });
}

/**
 * Export profiling results to CSV format
 */
export function exportToCSV(profile: ProfileResult): string {
  const headers = [
    'Catalog',
    'Schema',
    'Table',
    'Column Name',
    'Documented Type',
    'Inferred Type',
    'Type Confidence %',
    'Total Rows',
    'Unique Values',
    'Unique %',
    'Null Count',
    'Null %',
    'Completeness %',
    'Avg Length',
    'Min Length',
    'Max Length',
    'Median Length',
    'Min Value',
    'Max Value',
    'Mean',
    'Median',
    'Std Dev',
    'P25',
    'P75',
    'P95',
    'P99',
    'Zeros Count',
    'Negatives Count',
    'Infinites Count',
    'Smallest Value 1',
    'Smallest Value 2',
    'Smallest Value 3',
    'Smallest Value 4',
    'Smallest Value 5',
    'Largest Value 1',
    'Largest Value 2',
    'Largest Value 3',
    'Largest Value 4',
    'Largest Value 5',
    'First Sample 1',
    'First Sample 2',
    'First Sample 3',
    'Random Sample 1',
    'Random Sample 2',
    'Random Sample 3',
    'Quality Score',
    'Top Value 1',
    'Top Count 1',
    'Top Value 2',
    'Top Count 2',
    'Top Value 3',
    'Top Count 3',
    'Patterns'
  ];

  const rows = profile.columns.map(col => {
    const qualityScore = calculateQualityScore({
      nullPct: col.nullPct,
      uniquePct: col.uniquePct,
      uniqueCount: col.uniqueValues,
      typeConsistency: col.inferredPct,
      schemaMatch: col.inferredType === col.documentedType
    });

    const top3 = col.frequency.top3 || [];
    const smallest = col.smallestValues || [];
    const largest = col.largestValues || [];
    const firstSamples = col.firstSamples || [];
    const randomSamples = col.randomSamples || [];
    
    return [
      col.catalog,
      col.schema,
      col.table,
      col.name,
      col.documentedType,
      col.inferredType,
      col.inferredPct.toFixed(2),
      profile.totalRows,
      col.uniqueValues,
      col.uniquePct.toFixed(4),
      col.nulls,
      col.nullPct.toFixed(4),
      (100 - col.nullPct).toFixed(4),
      col.avgLength ? col.avgLength.toFixed(2) : '',
      col.minLength ? col.minLength.toFixed(0) : '',
      col.maxLength ? col.maxLength.toFixed(0) : '',
      col.medianLength ? col.medianLength.toFixed(1) : '',
      escapeCSVValue(col.minValue),
      escapeCSVValue(col.maxValue),
      col.mean ? col.mean.toFixed(2) : '',
      col.median ? col.median.toFixed(2) : '',
      col.stddev ? col.stddev.toFixed(2) : '',
      col.p25 ? col.p25.toFixed(2) : '',
      col.p75 ? col.p75.toFixed(2) : '',
      col.p95 ? col.p95.toFixed(2) : '',
      col.p99 ? col.p99.toFixed(2) : '',
      col.zerosCount || '',
      col.negativesCount || '',
      col.infiniteCount || '',
      smallest[0] || '',
      smallest[1] || '',
      smallest[2] || '',
      smallest[3] || '',
      smallest[4] || '',
      largest[0] || '',
      largest[1] || '',
      largest[2] || '',
      largest[3] || '',
      largest[4] || '',
      escapeCSVValue(firstSamples[0] || ''),
      escapeCSVValue(firstSamples[1] || ''),
      escapeCSVValue(firstSamples[2] || ''),
      escapeCSVValue(randomSamples[0] || ''),
      escapeCSVValue(randomSamples[1] || ''),
      escapeCSVValue(randomSamples[2] || ''),
      qualityScore,
      escapeCSVValue(top3[0]?.value || ''),
      top3[0]?.count || '',
      escapeCSVValue(top3[1]?.value || ''),
      top3[1]?.count || '',
      escapeCSVValue(top3[2]?.value || ''),
      top3[2]?.count || '',
      col.patterns.join('; ')
    ].map(v => String(v));
  });

  const csvLines = [
    headers.join(','),
    ...rows.map(row => row.join(','))
  ];

  return csvLines.join('\n');
}

/**
 * Export profiling results to Excel-compatible CSV with multiple "sheets"
 */
export function exportToMultiSheetCSV(profile: ProfileResult): {
  summary: string;
  detailed: string;
  patterns: string;
  quality: string;
} {
  // Summary Sheet
  const summaryHeaders = ['Metric', 'Value'];
  const summaryRows = [
    ['Profile Name', profile.profileName],
    ['Source', profile.sourceName],
    ['Schema', profile.schema],
    ['Data Source', profile.dataSource],
    ['Profile Date', profile.profileDate],
    ['Sampling Policy', profile.samplingPolicy],
    ['Total Rows', profile.totalRows],
    ['Total Columns', profile.columns.length],
    ['Date Columns', profile.columns.filter(c => c.inferredType.includes('Date')).length],
    ['Numeric Columns', profile.columns.filter(c => c.inferredType.includes('Integer')).length],
    ['String Columns', profile.columns.filter(c => c.inferredType.includes('String')).length],
    ['Columns with Nulls', profile.columns.filter(c => c.nullPct > 0).length],
    ['High Cardinality Columns', profile.columns.filter(c => c.uniquePct > 95).length],
    ['Average Completeness %', (profile.columns.reduce((sum, c) => sum + (100 - c.nullPct), 0) / profile.columns.length).toFixed(2)],
    ['Average Quality Score', (profile.columns.reduce((sum, c) => sum + calculateQualityScore({
      nullPct: c.nullPct,
      uniquePct: c.uniquePct,
      uniqueCount: c.uniqueValues,
      typeConsistency: c.inferredPct,
      schemaMatch: c.inferredType === c.documentedType
    }), 0) / profile.columns.length).toFixed(2)]
  ];
  
  const summary = [summaryHeaders.join(','), ...summaryRows.map(r => r.join(','))].join('\n');

  // Detailed Sheet (main profiling data)
  const detailed = exportToCSV(profile);

  // Patterns Sheet
  const patternsHeaders = ['Catalog', 'Schema', 'Table', 'Column', 'Pattern', 'Sample Values'];
  const patternsRows = profile.columns.flatMap(col =>
    col.patterns.map(pattern => [
      col.catalog,
      col.schema,
      col.table,
      col.name,
      pattern,
      col.frequency.top3.slice(0, 1).map(v => v.value).join('; ')
    ])
  );
  const patterns = [patternsHeaders.join(','), ...patternsRows.map(r => r.join(','))].join('\n');

  // Quality Sheet
  const qualityHeaders = ['Catalog', 'Schema', 'Table', 'Column', 'Quality Score', 'Completeness %', 'Type Match', 'Issues'];
  const qualityRows = profile.columns.map(col => {
    const qualityScore = calculateQualityScore({
      nullPct: col.nullPct,
      uniquePct: col.uniquePct,
      uniqueCount: col.uniqueValues,
      typeConsistency: col.inferredPct,
      schemaMatch: col.inferredType === col.documentedType
    });
    
    const issues = [];
    if (col.nullPct > 50) issues.push('High Nulls');
    else if (col.nullPct > 0) issues.push('Has Nulls');
    if (col.inferredType !== col.documentedType) issues.push('Type Mismatch');
    if (col.uniquePct > 95) issues.push('High Cardinality');
    
    return [
      col.catalog,
      col.schema,
      col.table,
      col.name,
      qualityScore,
      (100 - col.nullPct).toFixed(2),
      col.inferredType === col.documentedType ? 'Yes' : 'No',
      issues.join('; ')
    ];
  });
  const quality = [qualityHeaders.join(','), ...qualityRows.map(r => r.join(','))].join('\n');

  return { summary, detailed, patterns, quality };
}

/**
 * Helper to escape CSV values
 */
function escapeCSVValue(value: string | number): string {
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Download CSV file
 */
export function downloadCSV(content: string, filename: string): void {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

/**
 * Download multiple CSV files as ZIP (simplified version)
 */
export function downloadMultiSheetExport(profile: ProfileResult): void {
  const sheets = exportToMultiSheetCSV(profile);
  const timestamp = new Date().toISOString().split('T')[0];
  
  // Download each sheet separately
  downloadCSV(sheets.summary, `${profile.profileName}_Summary_${timestamp}.csv`);
  downloadCSV(sheets.detailed, `${profile.profileName}_Detailed_${timestamp}.csv`);
  downloadCSV(sheets.patterns, `${profile.profileName}_Patterns_${timestamp}.csv`);
  downloadCSV(sheets.quality, `${profile.profileName}_Quality_${timestamp}.csv`);
}

/**
 * Export profiling results to Excel file with multiple sheets
 */
export async function exportToExcel(profile: ProfileResult): Promise<void> {
  try {
    const response = await fetch('/api/export/excel', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        totalColumns: profile.columns.length,
        totalRows: profile.totalRows,
        issuesFound: profile.columns.filter(c => c.nullPct > 0).length,
        completeness: `${(100 - (profile.columns.reduce((sum, c) => sum + c.nullPct, 0) / profile.columns.length)).toFixed(2)}%`,
        qualityScore: `${(profile.columns.reduce((sum, c) => sum + calculateQualityScore({
          nullPct: c.nullPct,
          uniquePct: c.uniquePct,
          uniqueCount: c.uniqueValues,
          typeConsistency: c.inferredPct,
          schemaMatch: c.inferredType === c.documentedType
        }), 0) / profile.columns.length).toFixed(2)}%`,
        highCardinalityCount: profile.columns.filter(c => c.uniquePct > 95).length,
        dateColumns: profile.columns.filter(c => c.inferredType.includes('Date') || c.inferredType.includes('TIMESTAMP')).length,
        emptyColumns: profile.columns.filter(c => c.nullPct === 100).length,
        columns: profile.columns
      })
    });

    if (!response.ok) {
      throw new Error('Failed to generate Excel file');
    }

    // Download the file
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const timestamp = new Date().toISOString().split('T')[0];
    link.download = `data_profiling_report_${timestamp}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Error exporting to Excel:', error);
    throw error;
  }
}

