# Deployment Guide

This guide covers deploying the Databricks Data Profiler to production environments.

## Deployment Options

### Option 1: Docker Deployment (Recommended)

#### Create Dockerfile for Backend

```dockerfile
# backend/Dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY api.py .

EXPOSE 8000

CMD ["uvicorn", "api:app", "--host", "0.0.0.0", "--port", "8000"]
```

#### Create Dockerfile for Frontend

```dockerfile
# Dockerfile
FROM node:18-alpine as build

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
```

#### Docker Compose

```yaml
# docker-compose.yml
version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - DATABRICKS_HOST=${DATABRICKS_HOST}
      - DATABRICKS_HTTP_PATH=${DATABRICKS_HTTP_PATH}
      - DATABRICKS_TOKEN=${DATABRICKS_TOKEN}
    restart: unless-stopped

  frontend:
    build: .
    ports:
      - "80:80"
    depends_on:
      - backend
    restart: unless-stopped
```

#### Deploy with Docker Compose

```bash
# Set environment variables
export DATABRICKS_HOST=your-workspace.cloud.databricks.com
export DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/your-id
export DATABRICKS_TOKEN=your-token

# Build and start
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

### Option 2: Kubernetes Deployment

#### Backend Deployment

```yaml
# k8s/backend-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: profiler-backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: profiler-backend
  template:
    metadata:
      labels:
        app: profiler-backend
    spec:
      containers:
      - name: backend
        image: your-registry/profiler-backend:latest
        ports:
        - containerPort: 8000
        env:
        - name: DATABRICKS_HOST
          valueFrom:
            secretKeyRef:
              name: databricks-secret
              key: host
        - name: DATABRICKS_HTTP_PATH
          valueFrom:
            secretKeyRef:
              name: databricks-secret
              key: http-path
        - name: DATABRICKS_TOKEN
          valueFrom:
            secretKeyRef:
              name: databricks-secret
              key: token
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: profiler-backend
spec:
  selector:
    app: profiler-backend
  ports:
  - port: 8000
    targetPort: 8000
  type: ClusterIP
```

#### Frontend Deployment

```yaml
# k8s/frontend-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: profiler-frontend
spec:
  replicas: 2
  selector:
    matchLabels:
      app: profiler-frontend
  template:
    metadata:
      labels:
        app: profiler-frontend
    spec:
      containers:
      - name: frontend
        image: your-registry/profiler-frontend:latest
        ports:
        - containerPort: 80
        resources:
          requests:
            memory: "128Mi"
            cpu: "100m"
          limits:
            memory: "256Mi"
            cpu: "200m"
---
apiVersion: v1
kind: Service
metadata:
  name: profiler-frontend
spec:
  selector:
    app: profiler-frontend
  ports:
  - port: 80
    targetPort: 80
  type: LoadBalancer
```

#### Secrets

```yaml
# k8s/secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: databricks-secret
type: Opaque
stringData:
  host: your-workspace.cloud.databricks.com
  http-path: /sql/1.0/warehouses/your-id
  token: your-databricks-token
```

#### Deploy to Kubernetes

```bash
# Create secrets
kubectl apply -f k8s/secrets.yaml

# Deploy backend
kubectl apply -f k8s/backend-deployment.yaml

# Deploy frontend
kubectl apply -f k8s/frontend-deployment.yaml

# Get external IP
kubectl get services profiler-frontend
```

### Option 3: AWS Deployment

#### Frontend (S3 + CloudFront)

```bash
# Build frontend
npm run build

# Create S3 bucket
aws s3 mb s3://profiler-frontend

# Configure bucket for static hosting
aws s3 website s3://profiler-frontend \
  --index-document index.html

# Upload files
aws s3 sync dist/ s3://profiler-frontend

# Create CloudFront distribution
aws cloudfront create-distribution \
  --origin-domain-name profiler-frontend.s3.amazonaws.com
```

#### Backend (ECS Fargate)

```bash
# Build and push Docker image
docker build -t profiler-backend backend/
docker tag profiler-backend:latest \
  your-account.dkr.ecr.us-east-1.amazonaws.com/profiler-backend:latest
docker push your-account.dkr.ecr.us-east-1.amazonaws.com/profiler-backend:latest

# Create ECS task definition, service, etc.
# (Use AWS Console or CloudFormation)
```

### Option 4: Azure Deployment

#### Frontend (Azure Static Web Apps)

```bash
# Install Azure CLI
az login

# Create resource group
az group create --name profiler-rg --location eastus

# Create static web app
az staticwebapp create \
  --name profiler-frontend \
  --resource-group profiler-rg \
  --source . \
  --location eastus \
  --branch main \
  --app-location "/" \
  --output-location "dist"
```

#### Backend (Azure Container Instances)

```bash
# Create container registry
az acr create --resource-group profiler-rg \
  --name profilerbackend --sku Basic

# Build and push image
az acr build --registry profilerbackend \
  --image profiler-backend:latest \
  backend/

# Deploy container
az container create \
  --resource-group profiler-rg \
  --name profiler-backend \
  --image profilerbackend.azurecr.io/profiler-backend:latest \
  --dns-name-label profiler-backend \
  --ports 8000 \
  --environment-variables \
    DATABRICKS_HOST=$DATABRICKS_HOST \
    DATABRICKS_HTTP_PATH=$DATABRICKS_HTTP_PATH \
  --secure-environment-variables \
    DATABRICKS_TOKEN=$DATABRICKS_TOKEN
```

## Production Configuration

### Environment Variables

```env
# Production .env
NODE_ENV=production
VITE_API_BASE_URL=https://api.yourcompany.com

DATABRICKS_HOST=prod-workspace.cloud.databricks.com
DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/prod-warehouse
DATABRICKS_TOKEN=use-vault-or-secret-manager

# Optional
ENABLE_MONITORING=true
LOG_LEVEL=info
MAX_CONCURRENT_QUERIES=10
QUERY_TIMEOUT_MS=300000
```

### Nginx Configuration

```nginx
# nginx.conf
server {
    listen 80;
    server_name profiler.yourcompany.com;

    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name profiler.yourcompany.com;

    ssl_certificate /etc/ssl/certs/profiler.crt;
    ssl_certificate_key /etc/ssl/private/profiler.key;

    # Frontend
    location / {
        root /usr/share/nginx/html;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api/ {
        proxy_pass http://backend:8000/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Increase timeout for long queries
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
}
```

## Security Hardening

### 1. API Authentication

Add authentication middleware to backend:

```python
# backend/auth.py
from fastapi import Security, HTTPException
from fastapi.security.api_key import APIKeyHeader

API_KEY_NAME = "X-API-Key"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

async def verify_api_key(api_key: str = Security(api_key_header)):
    if api_key != os.getenv("API_KEY"):
        raise HTTPException(status_code=403, detail="Invalid API Key")
    return api_key

# Use in routes
@app.get("/api/catalog-tree", dependencies=[Depends(verify_api_key)])
```

### 2. Rate Limiting

```python
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

@app.post("/api/databricks/execute")
@limiter.limit("10/minute")
async def execute_queries(request: Request, query_request: QueryRequest):
    ...
```

### 3. Input Validation

```python
from pydantic import BaseModel, validator

class ProfilingQuery(BaseModel):
    fieldKey: str
    query: str
    description: str
    
    @validator('query')
    def validate_query(cls, v):
        # Prevent SQL injection
        dangerous_keywords = ['DROP', 'DELETE', 'TRUNCATE', 'ALTER']
        if any(keyword in v.upper() for keyword in dangerous_keywords):
            raise ValueError('Query contains dangerous keywords')
        return v
```

### 4. HTTPS Enforcement

```python
from fastapi.middleware.httpsredirect import HTTPSRedirectMiddleware

if os.getenv("ENFORCE_HTTPS") == "true":
    app.add_middleware(HTTPSRedirectMiddleware)
```

## Monitoring

### Health Checks

```python
@app.get("/health")
async def health_check():
    try:
        # Test Databricks connection
        conn = get_databricks_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        conn.close()
        return {"status": "healthy", "databricks": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
```

### Logging

```python
import logging
from logging.handlers import RotatingFileHandler

# Configure logging
handler = RotatingFileHandler(
    'profiler.log',
    maxBytes=10485760,  # 10MB
    backupCount=5
)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[handler]
)

logger = logging.getLogger(__name__)
```

### Metrics (Prometheus)

```python
from prometheus_client import Counter, Histogram, generate_latest

query_counter = Counter('profiling_queries_total', 'Total queries executed')
query_duration = Histogram('profiling_query_duration_seconds', 'Query duration')

@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type="text/plain")
```

## Performance Optimization

### Backend Caching

```python
from functools import lru_cache
import asyncio

@lru_cache(maxsize=100)
def get_catalog_tree_cached():
    return get_catalog_tree()

# Refresh cache every hour
async def refresh_cache_periodically():
    while True:
        await asyncio.sleep(3600)
        get_catalog_tree_cached.cache_clear()
```

### Connection Pooling

```python
from databricks import sql
from queue import Queue

class ConnectionPool:
    def __init__(self, size=5):
        self.pool = Queue(maxsize=size)
        for _ in range(size):
            self.pool.put(self._create_connection())
    
    def _create_connection(self):
        return sql.connect(...)
    
    def get_connection(self):
        return self.pool.get()
    
    def return_connection(self, conn):
        self.pool.put(conn)
```

## Backup and Recovery

### Export Historical Data

```bash
# Backup script
#!/bin/bash
DATE=$(date +%Y%m%d)
mkdir -p backups/$DATE

# Export all profiling results
curl -X GET http://localhost:8000/api/exports > backups/$DATE/profiles.json

# Compress
tar -czf backups/profiles_$DATE.tar.gz backups/$DATE
rm -rf backups/$DATE
```

## Troubleshooting Production Issues

### Common Issues

1. **High Memory Usage**
   - Solution: Implement query result streaming
   - Solution: Add memory limits to containers

2. **Slow Queries**
   - Solution: Enable sampling for large tables
   - Solution: Increase SQL Warehouse size

3. **Connection Timeouts**
   - Solution: Increase proxy timeouts
   - Solution: Implement connection retry logic

4. **API Rate Limiting**
   - Solution: Implement request queuing
   - Solution: Add caching layer

### Debug Mode

```python
# Enable debug logging
if os.getenv("DEBUG") == "true":
    logging.basicConfig(level=logging.DEBUG)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Only in debug
    )
```

## Rollback Strategy

```bash
# Tag current version
git tag -a v1.0.0 -m "Production release"

# If issues arise, rollback
kubectl rollout undo deployment/profiler-backend
kubectl rollout undo deployment/profiler-frontend

# Or with Docker Compose
docker-compose down
git checkout v0.9.0
docker-compose up -d
```

---

For more information, see the [README](README.md) and [ARCHITECTURE](ARCHITECTURE.md) documentation.

